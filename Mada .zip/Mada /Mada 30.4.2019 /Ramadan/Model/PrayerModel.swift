//
//  PrayerModel.swift
//  Ramadan
//
//  Created by Fratello Software Group on 3/14/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import Foundation
import Alamofire

/// Prayer model response json tag
private enum PrayerModelResponseJsonTag: String {
    case data    = "data"
}

/// Prayer model
class PrayerModel {
    
    /**
     Get month prayer calendar days
     - Pramater date: tuple containing 2 values year, month
     - Parameter location: location tuple containing two values longtitude, latitude
     - Pramater timeZone: timezone string value
     */
    class func getMonthPrayerCalendarDays(date: (year: String, month: String), location: (latitude: Double, longitude: Double), completion: @escaping ([CalendarDay]?, Error?) -> ()) {
        
        let parameters: Parameters = ["latitude": location.latitude, "longitude": location.longitude, "method": 4, "month": date.month, "year": date.year]
       
        // Request data
        SessionManager.default.request(PrayerRouter.getMonthPrayerTime(parameters: parameters)).responseJSON(completionHandler: {
            response in
            
            // Switch result
            switch response.result {
                
            // Success
            case .success(let response):
                if let responseDictionary = response as? NSDictionary, let daysDictionaryArray = responseDictionary.value(forKey: PrayerModelResponseJsonTag.data.rawValue) as? [NSDictionary] {
                    
                    // Build calendar days
                    var calendarDays: [CalendarDay] = []
                    
                    // build entities
                    for dict in daysDictionaryArray {
                        calendarDays.append(CalendarDay(dictionary: dict))
                    }
                    
                    completion(calendarDays, nil)
                    
                    // There is an error
                } else {
                    let error  = NSError()
                    completion(nil, error)
                }
                
            // Failure
            case .failure(let error):
                completion(nil, error)
            }
        })
    }
}
