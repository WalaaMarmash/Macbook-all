//
//  CalendarViewController.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit
import MessageUI

/// Calendar view controller
class CalendarViewController: UIViewController {
    
    /// Title label
    @IBOutlet private weak var titleLabel: UILabel!
    
    /// Table view
    @IBOutlet private weak var tableView: UITableView!
    
    /// Cells data
    private var cellsData: [CellData] = []
    
    /// Calendar days
    var calendarDays: [CalendarDay]!
    
    /**
     View did load
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set navigation bar title
        self.navigationItem.title = "امساكيه رمضان"
        
        // Add request tab bar item
        self.addRequestTabBarItem()
        
        // Build data
        self.buildData(days: self.calendarDays)
        
        // Set up table view
        self.setupTableView()
    }
    
    /**
     Add request tab bar item
     */
    private func addRequestTabBarItem() {
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.add, target: self, action: #selector(self.didRequestTabBarItem))
    }
    
    /**
     Did request tab bar item
     */
    @objc private func didRequestTabBarItem() {
        let alert = UIAlertController(title: "ارسال دعوه", message: "", preferredStyle: .actionSheet)
        
        // Add actions
        alert.addAction(UIAlertAction(title: "سحور", style: .default, handler: {_ in
            self.openSendMessageViewController(type: SendMessageViewControllerType.sohor)
        }))
        alert.addAction(UIAlertAction(title: "فطور", style: .default, handler: {_ in
            self.openSendMessageViewController(type: SendMessageViewControllerType.fotor)
        }))
        alert.addAction(UIAlertAction(title: "الغاء", style: .cancel, handler: {_ in
            self.openSendMessageViewController(type: SendMessageViewControllerType.fotor)
        }))
        
        // Present alert
        self.present(alert, animated: true)
    }
    
    /**
     Open send message view controller
     */
    private func openSendMessageViewController(type: SendMessageViewControllerType) {
        // Get storyBoard
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let senMessageViewController = storyboard.instantiateViewController(withIdentifier: "SendMessageViewController") as! SendMessageViewController
        senMessageViewController.type = type
        senMessageViewController.delegate = self
        
        // Create navigation cntroller
        let sendMessageNavigationController = UINavigationController(rootViewController: senMessageViewController)
        self.present(sendMessageNavigationController, animated: true)
    }
    
    /**
     Set up table view
     */
    private func setupTableView() {
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.bounces = false
        
        self.tableView.tableFooterView = UIView()
        
        // Set seperator style to none
        self.tableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        
        if #available(iOS 11.0, *) {
            self.tableView.contentInsetAdjustmentBehavior = .never
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
    }
    
    /**
     Build data
     - Parameter days: Calendar days
     */
    private func buildData(days: [CalendarDay]) {
        self.cellsData.removeAll()
        
        // Build data
        for (index, day) in days.enumerated() {
            
            // Days background color
            var backGroundColor = index % 2 == 0 ? UIColor(red: 220/255, green: 221/255, blue: 222/255, alpha: 1) : UIColor.white
            var textColor = UIColor.black
            
            if day.getWeekDay() == WeekDay.friday {
                backGroundColor = UIColor(red: 0, green: 196/255, blue: 243, alpha: 1)
                textColor = UIColor.white
            }
            
            let invitations = UserDefaultssUtils.getObjectValueForKey("messages") as? [Date] ?? []
            
            var isSelected = false
            if let date = day.date {
                isSelected = invitations.contains(Calendar.current.startOfDay(for: date))
            }
            
            // Build tile
            let titleData = CalendarDayTableViewCellData(day: day, backgroundColor: backGroundColor, isDateSelected: isSelected, textColor: textColor)
            self.cellsData.append(titleData)
        }
    }
}

//MARK: - UITableViewDelegate
extension CalendarViewController: UITableViewDelegate {
    
    /**
     Height for row at
     */
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if self.cellsData.count > indexPath.row {
            return self.cellsData[indexPath.row].cellHeight
        }
        return 0.0
    }
}

// MARK: - UITableViewDataSource
extension CalendarViewController: UITableViewDataSource {
    
    /**
     Number of rows
     */
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.cellsData.count
    }
    
    /**
     Cell for row at
     */
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Check row in in bounds
        if self.cellsData.count > indexPath.row {
            let cellData = self.cellsData[indexPath.row]
            
            /// Calendar day table view cell
            if let calendarDayTableViewCellData = cellData as? CalendarDayTableViewCellData {
                
                let cell = self.tableView.dequeueReusableCell(withIdentifier: CalendarDayTableViewCell.getReuseIdentifier()) as! CalendarDayTableViewCell
                cell.setup(data: calendarDayTableViewCellData)
                return cell
            }
        }
        return UITableViewCell()
    }
}

// MARK: - SendMessageViewControllerDelegate
extension CalendarViewController: SendMessageViewControllerDelegate {
    
    /**
     Did send message
     */
    func didSendMessage() {
        self.buildData(days: self.calendarDays)
        self.tableView.reloadData()
    }
}
