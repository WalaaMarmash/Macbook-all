//
//  CalendarDayTableViewCell.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Calendar day table view cell
class CalendarDayTableViewCell: UITableViewCell {
    
    /// Stack view
    @IBOutlet private weak var stackView: UIStackView!
    
    /// Today label
    @IBOutlet private weak var todayLabel: UILabel!
    
    /// Ramadan day label
    @IBOutlet private weak var ramadanDayLabel: UILabel!
    
    /// Month day label
    @IBOutlet private weak var monthDayLabel: UILabel!
    
    /// Fajer time label
    @IBOutlet private weak var fajerTimeLabel: UILabel!
    
    /// Sun time label
    @IBOutlet private weak var sunTimeLabel: UILabel!
    
    /// Dohor time label
    @IBOutlet private weak var dohorTimeLabel: UILabel!
    
    /// Aser time label
    @IBOutlet private weak var aserTimeLabel: UILabel!
    
    /// Maghreb time label
    @IBOutlet private weak var maghrebTimeLabel: UILabel!
    
    /// Ishaa time label
    @IBOutlet private weak var ishaaTimeLabel: UILabel!
    
    /// Labels array
    private var labelsArray: [UILabel] = []
    
    /**
     Awake from nib
     */
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.selectionStyle = UITableViewCell.SelectionStyle.none
        
        self.labelsArray = [self.todayLabel, self.ramadanDayLabel, self.monthDayLabel, self.fajerTimeLabel, self.sunTimeLabel, self.dohorTimeLabel, self.aserTimeLabel, self.maghrebTimeLabel, self.ishaaTimeLabel]
    }
    
    /**
     Layout subviews
     */
    override func layoutSubviews() {
        super.layoutSubviews()
        self.monthDayLabel.layer.cornerRadius =
            self.monthDayLabel.frame.width / 2
        self.monthDayLabel.clipsToBounds = true
    }
    
    /**
     Setup
     - Parameter data: Calendar Day Table View Cell Data
     */
    func setup(data: CalendarDayTableViewCellData) {
        
        // Set background color
        self.contentView.backgroundColor = data.backgroundColor
        
        // Set today label text
        self.todayLabel.text = data.day.getWeekDay().getTitle()
        self.todayLabel.textColor = data.textColor
        
        // Set month date
        self.ramadanDayLabel.text = data.day.ramadanDayNumber.description
        self.ramadanDayLabel.textColor = data.textColor
        
        // Set ramadan date
        self.monthDayLabel.text = self.getDateIndex(date: data.day.date!).description
        self.monthDayLabel.textColor = data.textColor
        
        // set prayers label
        for prayer in data.day.prayers {
            
            // Get prayer time
            let prayerTimeString = prayer.getPrayerTimeString()
            
            switch prayer.type {
                
            case .fajer:
                self.fajerTimeLabel.text = prayerTimeString
                self.fajerTimeLabel.textColor = data.textColor
            case .sunRise:
                self.sunTimeLabel.text = prayerTimeString
                self.sunTimeLabel.textColor = data.textColor
            case .dohor:
                self.dohorTimeLabel.text = prayerTimeString
                self.dohorTimeLabel.textColor = data.textColor
            case .aser:
                self.aserTimeLabel.text = prayerTimeString
                self.aserTimeLabel.textColor = data.textColor
            case .maghreb:
                self.maghrebTimeLabel.text = prayerTimeString
                self.maghrebTimeLabel.textColor = data.textColor
            case .ishaa:
                self.ishaaTimeLabel.text = prayerTimeString
                self.ishaaTimeLabel.textColor = data.textColor
            }
        }
        
        self.monthDayLabel.backgroundColor = data.isDateSelected ? UIColor(red: 1, green: 206/255, blue: 0, alpha: 1) : UIColor.clear
    }
    
    /**
     Get date index
     */
    private func getDateIndex(date: Date) -> Int {
        return Calendar.current.dateComponents([Calendar.Component.day], from: date).day!
    }
    
    // MARK: - Class methods
    
    /**
     Get reuse identifier
     - Returns: cell reuse identfier
     */
    class func getReuseIdentifier() -> String {
        return "CalendarDayTableViewCell"
    }
    
    /**
     Get cell height
     - Returns: Cell height
     */
    class func getCellHeight() -> CGFloat{
        return 54
    }
}
