//
//  CalendarDayTableViewCellData.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Calendar prayer table view cell data
class CalendarDayTableViewCellData: CellData {
    
    /// Cell identifier
    var cellIdentifier: String
    
    /// Cell height
    var cellHeight: CGFloat
    
    /// Left prayer
    private(set) var day: CalendarDay
    
    /// Background color
    private(set) var backgroundColor: UIColor
    
    /// Text color
    private(set) var textColor: UIColor
    
    /// Is date selected
    private(set) var isDateSelected: Bool
    
    /**
     Initilizer
     */
    init() {
        self.cellIdentifier = CalendarDayTableViewCell.getReuseIdentifier()
        self.cellHeight = CalendarDayTableViewCell.getCellHeight()
        self.day = CalendarDay()
        self.backgroundColor = UIColor.white
        self.textColor = UIColor.black
        self.isDateSelected = true
    }
    
    /**
     Initilizer
     - Parameter day: Calendar day
     - Parameter backgroundColor: Background color
     - Parameter isDateSelected: Boolean to indicate if date selected.
     - Parameter text color: text color
     */
    convenience init(day: CalendarDay, backgroundColor: UIColor = UIColor.white, isDateSelected: Bool, textColor: UIColor) {
        self.init()
        self.day = day
        self.backgroundColor = backgroundColor
        self.isDateSelected = isDateSelected
        self.textColor = textColor
    }
}
