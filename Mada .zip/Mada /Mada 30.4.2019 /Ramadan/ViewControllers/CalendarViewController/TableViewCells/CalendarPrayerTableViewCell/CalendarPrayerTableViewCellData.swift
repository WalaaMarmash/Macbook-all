//
//  CalendarPrayerTableViewCellData.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Calendar prayer table view cell data
class CalendarPrayerTableViewCellData: CellData {
    
    /// Cell identifier
    var cellIdentifier: String
    
    /// Cell height
    var cellHeight: CGFloat
    
    /// Left prayer
    private(set) var leftPrayer: Prayer
    
    /// Right prayer
    private(set) var rightPrayer: Prayer
    
    /// Middle prayer
    private(set) var middlePrayer: Prayer
    
    /// Background color
    private(set) var backgroundColor: UIColor
    
    /**
     Initilizer
     */
    init() {
        self.cellIdentifier = PrayersInfoTableViewCell.getReuseIdentifier()
        self.cellHeight = PrayersInfoTableViewCell.getCellHeight()
        self.leftPrayer = Prayer()
        self.rightPrayer = Prayer()
        self.middlePrayer = Prayer()
        self.backgroundColor = UIColor.white
    }
    
    /**
     Initilizer
     - Parameter leftPrayer: left prayer
     - Parameter rightPrayer: right prayer
     - Parameter middlePrayer: middle prayer
     - Parameter backgroundColor: Background color
     */
    convenience init(leftPrayer: Prayer, rightPrayer: Prayer, middlePrayer: Prayer, backgroundColor: UIColor = UIColor.white) {
        self.init()
        self.leftPrayer = leftPrayer
        self.rightPrayer = rightPrayer
        self.middlePrayer = middlePrayer
        self.backgroundColor = backgroundColor
    }
}
