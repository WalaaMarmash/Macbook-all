//
//  CalendarPrayerTableViewCell.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Calendar Prayer Table View Cell
class CalendarPrayerTableViewCell: UITableViewCell {
    
    @IBOutlet weak var leftContainerView: UIView!
    /// Left image view
    @IBOutlet weak var leftImageView: UIImageView!
    
    /// Left date label
    @IBOutlet weak var leftPrayerDateLabel: UILabel!
    
    /// Left title image view
    @IBOutlet weak var leftPrayerTitleLabel: UILabel!
    
    /// Right container view
    @IBOutlet weak var rightContainerView: UIView!
    
    /// Right image view
    @IBOutlet weak var rightImageView: UIImageView!
    
    /// Right date label
    @IBOutlet weak var rightPrayerDateLabel: UILabel!
    
    /// Right title label
    @IBOutlet weak var rightPrayerTitleLabel: UILabel!
    
    /// Middle image view
    @IBOutlet weak var middleImageView: UIImageView!
    
    /// Middle date label
    @IBOutlet weak var middlePrayerDateLabel: UILabel!
    
    /// Middle title label
    @IBOutlet weak var middlePrayerTitleLabel: UILabel!
    
    /**
     Awake from nib
     */
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Set selection style
        self.selectionStyle = UITableViewCell.SelectionStyle.none
        
        // Set up image views
        self.rightImageView.contentMode = UIView.ContentMode.scaleAspectFit
        self.middleImageView.contentMode = UIView.ContentMode.scaleAspectFit
        self.leftImageView.contentMode = UIView.ContentMode.scaleAspectFit
        
        // Set prayers name label
        self.rightPrayerTitleLabel.textAlignment = NSTextAlignment.center
        self.leftPrayerTitleLabel.textAlignment = NSTextAlignment.center
        self.middlePrayerTitleLabel.textAlignment = NSTextAlignment.center
        
        // Set prayers time label
        self.leftPrayerDateLabel.textAlignment = NSTextAlignment.center
        self.rightPrayerDateLabel.textAlignment = NSTextAlignment.center
        self.middlePrayerDateLabel.textAlignment = NSTextAlignment.center
    }
    
    /**
     Setup
     - Parameter leftPrayer: prayer to be displayed on left side of cell
     - Parameter rightPrayer: prayer to be displayed on right side of cell
     - Parameter middlePrayer: prayer to be displayed at the middle of the cell
     - Parameter backgroundColor: color to set at view background
     */
    func setup(data: CalendarPrayerTableViewCellData) {
        
        // Set up left prayer
        self.leftImageView.image = UIImage(named: data.leftPrayer.type.getPrayerImageName())
        self.leftPrayerTitleLabel.text = data.leftPrayer.type.getTitle()
        self.leftPrayerDateLabel.text = data.leftPrayer.getPrayerTimeString()
        
        // Set up right prayer
        self.rightImageView.image = UIImage(named: data.rightPrayer.type.getPrayerImageName())
        self.rightPrayerTitleLabel.text = data.rightPrayer.type.getTitle()
        self.rightPrayerDateLabel.text = data.rightPrayer.getPrayerTimeString()
        
        // Set up middle prayer
        self.middleImageView.image = UIImage(named: data.middlePrayer.type.getPrayerImageName())
        self.middlePrayerTitleLabel.text = data.middlePrayer.type.getTitle()
        self.middlePrayerDateLabel.text = data.middlePrayer.getPrayerTimeString()
        
        self.backgroundColor = data.backgroundColor
    }
    
    /**
     Get reuse identifier
     - Returns: cell reuse identfier
     */
    class func getReuseIdentifier() -> String {
        return "CalendarPrayerTimesTableViewCell"
    }
    
    /**
     Get cell height
     - Returns: Cell height
     */
    class func getCellHeight() -> CGFloat{
        return 118
    }
}
