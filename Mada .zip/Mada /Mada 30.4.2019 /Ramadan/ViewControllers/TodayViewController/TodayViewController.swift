//
//  TodayViewController.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Today View controller
class TodayViewController: UIViewController {

    /// Table view
    @IBOutlet weak var tableView: UITableView!
    
    /// Cells data
    private var cellsData: [CellData] = []
    
    /// Calendar day
    var calendarDay: CalendarDay!
    
    /// Map for todays doaa
    private var doaaPrayerMap: [Int: String] = [0:
        "اَلّهُمَّ اجْعَلْ صِيامي فيهِ صِيامَ الصّائِمينَ وَ قِيامي فيِهِ قِيامَ القائِمينَ ، وَ نَبِّهْني فيهِ عَن نَوْمَةِالغافِلينَ ، وَهَبْ لي جُرمي فيهِ يا اِلهَ العالمينَ ،وَاعْفُ عَنّي يا عافِياًعَنِ المُجرِمينَ"
        , 1:   "اَلّهُمَّ قَرِّبْني فيهِ اِلى مَرضاتِكَ ، وَجَنِّبْني فيهِ مِن سَخَطِكَ وَنَقِماتِكَ ، وَ وَفِّقني فيهِ لِقِرائَةِ اياتِِكَ ، بِرَحمَتِكَ ياأرحَمَ الرّاحمينَ ."
        , 2:     "اَلّهُمَّ ارْزُقني فيهِ الذِّهنَ وَالتَّنْبيهِ ، وَباعِدْني فيهِ مِنَ السَّفاهَةِ وَالتَّمْويهِ ، وَ اجْعَل لي نَصيباً مِن كُلِّ خَيْرٍ تُنْزِلُ فيهِ ، بِجودِكَ يا اَجوَدَ الأجْوَدينَ ."
        , 3: "اَلّهُمَّ قَوِّني فيهِ عَلى اِقامَةِ اَمرِكَ ، وَ اَذِقني فيهِ حَلاوَةِ ذِكْرِكَ ، وَ اَوْزِعْني فيهِ لِأداءِ شُكْرِكَ بِكَرَمِكَ ، وَاحْفَظْني فيهِ بِحِفظِكَ و َسَتْرِكَ يا اَبصَرَ النّاظِرينَ ."
        , 4: "اَلّهُمَّ اجعَلني فيهِ مِنَ المُستَغْفِرينَ ، وَ اجعَلني فيهِ مِن عِبادِكَ الصّالحينَ القانِتينَ ، وَ اجعَلني فيهِ مِن اَوْليائِكَ المُقَرَّبينَ ، بِرَأفَتِكَ يا اَرحَمَ الرّاحمينَ ."
        , 5: "اَلّهُمَّ لا تَخْذُلني فيهِ لِتَعَرُّضِ مَعصِيَتِكَ ، وَلاتَضرِبني بِسِياطِ نَقِمَتِكَ ، وَ زَحْزِحني فيهِ مِن موُجِبات سَخَطِكَ بِمَنِّكَ وَ اَياديكَ يا مُنتَهى رَغْبَةِ الرّاغِبينَ ."
        , 6: "اَلّهُمَّ اَعِنّي فيهِ عَلى صِيامِهِ وَ قِيامِهِ ، وَ جَنِّبني فيهِ مِن هَفَواتِهِ وَاثامِهِ ، وَ ارْزُقني فيهِ ذِكْرَكَ بِدَوامِهِ ،بِتَوْفيقِكَ يا هادِيَ المُضِّلينَ ."
        , 7: "اَلّهُمَّ ارْزُقْني فيهِ رَحمَةَ الأَيْتامِ وَ اِطعامَ الطَّعامِ وَاِفْشاءَ وَصُحْبَةَ الكِرامِ بِطَوْلِكَ يا مَلْجَاَ الأمِلينَ ."
        , 8: "اَلّهُمَّ اجْعَل لي فيهِ نَصيباً مِن رَحمَتِكَ الواسِعَةِ ، وَ اهْدِني فيهِ لِبَراهينِكَ السّاطِعَةِ ، وَ خُذْ بِناصِيَتي إلى مَرْضاتِكَ الجامِعَةِ بِمَحَبَّتِكَ يا اَمَلَ المُشتاقينَ ."
        , 9: "اَلّهُمَّ اجْعَلني فيهِ مِنَ المُتَوَكِلينَ عَلَيْكَ ، وَ اجْعَلني فيهِ مِنَ الفائِزينَ لَدَيْكَ ، وَ اجعَلني فيه مِنَ المُقَرَّبينَ اِليكَ بِاِحْسانِكَ يا غايَةَ الطّالبينَ ."
        , 10: "اَلّهُمَّ حَبِّبْ اِلَيَّ فيهِ الْإحسانَ ، وَ كَرِّهْ فيهِ الْفُسُوقَ وَ العِصيانَ وَ حَرِّمْ عَلَيَّ فيهِ السَخَطَ وَ النّيرانَ بعَوْنِكَ ياغياثَ المُستَغيثينَ ."
        , 11: "اَلّهُمَّ زَيِّنِّي فيهِ بالسِّترِ وَ الْعَفافِ ، وَاسْتُرني فيهِ بِلِِِباسِ الْقُنُوعِ و َالكَفافِ ، وَ احْمِلني فيهِ عَلَىالْعَدْلِ وَ الْإنصافِ ، وَ آمنِّي فيهِ مِنْ كُلِّ ما اَخافُ بِعِصْمَتِكَ ياعصمَةَ الْخائفينَ ."
        , 12: "اَلّهُمَّ طَهِّرْني فيهِ مِنَ الدَّنسِ وَ الْأقْذارِ ، وَ صَبِّرْني فيهِ عَلى كائِناتِ الْأَقدارِ ، وَ وَفِّقْني فيهِ لِلتُّقى وَ صُحْبَةِ الْأبرارِ بِعَوْنِكَ ياقُرَّةَ عَيْن الْمَساكينِ ."
        , 13: "اَلّهُمَّ لاتُؤاخِذْني فيهِ بالْعَثَراتِ ، وَ اَقِلْني فيهِ مِنَ الْخَطايا وَ الْهَفَواتِ ، وَ لا تَجْعَلْني فيهِ غَرَضاً لِلْبَلايا وَ الأفاتِ بِعزَّتِكَ ياعِزَّ المُسْلمينَ ."
        , 14: "اَلّهُمَّ ارْزُقْني فيهِ طاعةَ الخاشعينَ ، وَ اشْرَحْ فيهِ صَدري بِانابَةِ المُخْبِتينَ ، بِأمانِكَ ياأمانَ الخائفينَ ."
        , 15: "اَلّهُمَّ وَفِّقْني فيهِ لِمُوافَقَةِ الْأبرارِ ، وَجَنِّبْني فيهِ مُرافَقَةِ الأشرارِ ، وَآوني فيهِ برَحمَتِكَ إلى دارِ القَرارِبإلهيَّتِكَ يا إله العالمينَ ."
        , 16: "اَلّهُمَّ اهدِني فيهِ لِصالِحِ الأعْمالِ ، وَ اقضِ لي فيهِ الحوائِجَ وَالآمالِ يا مَنْ لا يَحتاجُ إلى التَّفسيرِ وَ السُّؤالِ ، يا عالِماً بِما في صُدُورِ العالمينَ صَلِّ عَلى مُحَمَّدٍ وَ آله الطّاهرينَ ."
        , 17: "اَلّهُمَّ نَبِّهني فيهِ لِبَرَكاتِ أسحارِهِ ، وَنوِّرْ قَلْبي بِضِياءِ أنوارِهِ ، وَ خُذْ بِكُلِّ أعْضائِي إلى اتِّباعِ آثارِهِ بِنُورِكَ يا مُنَوِّرَ قُلُوبِ العارفينَ ."
        , 18: "ألّهُمَّ وَفِّر فيهِ حَظّي مِن بَرَكاتِهِ ، وَ سَهِّلْ سَبيلي إلىخيْراتِهِ ، وَ لا تَحْرِمْني قَبُولَ حَسَناتِهِ يا هادِياً إلى الحَقِّ المُبينِ ."
        , 19: "ألّهُمَّ افْتَحْ لي فيهِ أبوابَ الجِنان ، وَ أغلِقْ عَنَّي فيهِ أبوابَ النِّيرانِ ، وَ وَفِّقْني فيهِ لِتِلاوَةِالقُرانِ يامُنْزِلَ السَّكينَةِ في قُلُوبِ المؤمنين ."
        , 20: "ألّهُمَّ اجْعَلْ لي فيهِ إلى مَرضاتكَ دَليلاً ، و لاتَجعَلْ لِلشَّيْطانِ فيهِ عَلَيَّ سَبيلاً ، وَ اجْعَلِ الجَنَّةَ لي مَنْزِلاً وَمَقيلاً ، يا قاضِيَ حَوائج الطالبينَ ."
        , 21: "ألّهُمَّ افْتَحْ لي فيهِ أبوابَ فَضْلِكَ ، وَ أنزِل عَلَيَّ فيهِ بَرَكاتِكَ ، وَ وَفِّقْني فيهِ لِمُوجِباتِ مَرضاتِكَ ، وَ أسْكِنِّي فيهِ بُحْبُوحاتِ جَنّاتَكَ ، يا مَجيبَ دَعوَةِ المُضْطَرِّينَ ."
        , 22: "ألّهُمَّ اغْسِلني فيهِ مِنَ الذُّنُوبِ ، وَطَهِّرْني فيهِ مِنَ العُيُوبِ ، وَ امْتَحِنْ قَلبي فيهِ بِتَقْوى القُلُوبِ ،يامُقيلَ عَثَراتِ المُذنبين ."
        , 23: "ألّهُمَّ إنِّي أسألُكَ فيهِ مايُرضيكَ ، وَ أعُوذُ بِكَ مِمّا يُؤذيكَ ،وَ أسألُكَ التَّوفيقَ فيهِ لِأَنْ اُطيعَكَ وَلا أعْصِيَكَ ، يا جواد السّائلينَ ."
        , 24: "ألّهُمَّ اجْعَلني فيهِ مُحِبّاً لِأوْليائكَ ، وَ مُعادِياً لِأعْدائِكَ ، مُسْتَنّاً بِسُنَّةِ خاتمِ أنبيائكَ ،يا عاصمَ قٌلٌوب النَّبيّينَ ."
        , 25: "ألّهُمَّ اجْعَلْ سَعْي فيهِ مَشكوراً ، وَ ذَنبي فيهِ مَغفُوراً ، وَعَمَلي فيهِ مَقبُولاً ، وَ عَيْبي فيهِ مَستوراً يا أسمَعَ السّامعينَ ."
        , 26: "ألّهُمَّ ارْزُقني فيهِ فَضْلَ لَيلَةِ القَدرِ ، وَ صَيِّرْ اُمُوري فيهِ مِنَ العُسرِ إلى اليُسرِ ، وَ اقبَلْ مَعاذيري وَ حُطَّ عَنِّي الذَّنب وَ الوِزْرَ ، يا رَؤُفاً بِعِبادِهِ الصّالحينَ ."
        , 27: "ألّهُمَّ وَفِّرْ حَظِّي فيهِ مِنَ النَّوافِلِ ، وَ أكْرِمني فيهِ بِإحضارِ المَسائِلِ ، وَ قَرِّبْ فيهِ وَسيلَتي إليكَ مِنْ بَيْنِ الوَسائِلِ ، يا مَن لا يَشْغَلُهُ إلحاحُ المُلِحِّينَ ."
        , 28: "ألّهُمَّ غَشِّني فيهِ بالرَّحْمَةِ ، وَ ارْزُقني فيهِ التَّوفيقَ وَ العِصْمَةَ ، وَ طَهِّر قَلبي مِن غياهِبِ التُّهمَةِ ، يارَحيماً بِعبادِهِ المُؤمنينَ ."
        , 29: "ألّهُمَّ اجْعَلْ صِيامي فيهِ بالشُّكرِ وَ القَبولِ عَلى ماتَرضاهُ وَ يَرضاهُ الرَّسولُ مُحكَمَةً فُرُوعُهُ بِالأُصُولِ ، بِحَقِّ سَيِّدِنامُحَمَّدٍ وَآلهِ الطّاهِرينَ ، وَ الحَمدُ للهِ رَبِّ العالمين"
]

    /**
     View did load
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set navigation title.
        self.navigationItem.title = "اوقات الصلاه"
        
        // Build data
        self.buildData()
        
        // Setup table view
        self.setupTableView()
    }
    
    /**
     Build data
     */
    private func buildData() {
        
        // Empty data
        self.cellsData.removeAll()
        
        // Build data
        self.buildCellData(prayers: self.calendarDay.prayers)
    }
    
    /**
     Set up table view
     */
    private func setupTableView() {
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.bounces = false
       
        self.tableView.tableFooterView = UIView()
        
        // Set seperator style to none
        self.tableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        
        if #available(iOS 11.0, *) {
            self.tableView.contentInsetAdjustmentBehavior = .never
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
    }
    
    /**
     Build cell data
     - Parameter prayers: list of prayers
     */
    func buildCellData(prayers: [Prayer]) {
        self.cellsData.removeAll()
        
        // nextPrayerTime
        var nextPrayer = self.getComingPrayerTime(prayers: prayers)
        
        // Set next prayer time to ishaa time
        if nextPrayer.dateTime == nil {
            nextPrayer.dateTime = prayers.last!.dateTime
        }
        
        // Prayer time table view cell data
        self.cellsData.append(PrayerTimeTableViewCellData(prayer: nextPrayer))
        
        self.cellsData.append(PrayersInfoTableViewCellData(prayers: prayers, selectedPrayer: nextPrayer))

        
        let maghrebSalatime = prayers.filter({$0.type == PrayerType.maghreb}).first?.dateTime ?? Date()
            
        // Maghreb prayer remianing time table view cell data
        self.cellsData.append(MaghrebPrayerRemainingTimeTableViewCellData(maghrebSalahDate: maghrebSalatime))
        
        // Doaa
       var doaa = self.doaaPrayerMap[0]!
        
        // Check if its in range
        if doaaPrayerMap.count > self.calendarDay.ramadanDayNumber {
            doaa = self.doaaPrayerMap[self.calendarDay.ramadanDayNumber]!
        }
        self.cellsData.append(TodayPrayerTableViewCellData(prayerString: doaa))
    }
    
    /**
     Get upcoming prayer time
     - Parameter prayers: Prayers array
     - Returns: Prayer object representing prayer
     */
    private func getComingPrayerTime(prayers: [Prayer]) -> Prayer {
        
        // Sort array decending
        let sortedPrayersArray = prayers.sorted { (prayer1, prayer2) -> Bool in
            return prayer2.dateTime! > prayer1.dateTime!
        }
        
        // Get coming prayer
        for prayer in sortedPrayersArray {
            
            if Date() < prayer.dateTime! {
                return prayer
            }
        }
        
        return sortedPrayersArray.last!
    }
}

//MARK: - UITableViewDelegate
extension TodayViewController: UITableViewDelegate {
    
    /**
     Height for row at
     */
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if self.cellsData.count > indexPath.row {
            return self.cellsData[indexPath.row].cellHeight
        }
        return 0.0
    }
    
    /**
     Estimated height for row
     */
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {

        if self.cellsData.count > indexPath.row {
           return self.cellsData[indexPath.row].cellHeight
        }
        return 0.0
    }
}

// MARK: - UITableViewDataSource
extension TodayViewController: UITableViewDataSource {
    
    /**
     Number of rows
     */
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.cellsData.count
    }
    
    /**
     Cell for row at
     */
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Check row in in bounds
        if self.cellsData.count > indexPath.row {
            let cellData = self.cellsData[indexPath.row]
            
            /// Prayer times cell data
            if let prayerTimeCellData = cellData as? PrayerTimeTableViewCellData {
                
                let cell = self.tableView.dequeueReusableCell(withIdentifier: PrayerTimeTableViewCell.getReuseIdentifier()) as! PrayerTimeTableViewCell
                cell.setup(prayer: prayerTimeCellData.prayer)
                return cell
            }
            
            // Prayers info table view cell data
            if let prayersInfoTableViewCellData = cellData as? PrayersInfoTableViewCellData {
                
                let cell = self.tableView.dequeueReusableCell(withIdentifier: PrayersInfoTableViewCell.getReuseIdentifier()) as! PrayersInfoTableViewCell
                cell.setup(data: prayersInfoTableViewCellData)
                return cell
            }
            
            // Remianig time table view cell date
            if let remainingtimeTableViewCellData = cellData as? MaghrebPrayerRemainingTimeTableViewCellData {
                
                let cell = self.tableView.dequeueReusableCell(withIdentifier: MaghrebPrayerRemainingTimeTableViewCell.getReuseIdentifier()) as! MaghrebPrayerRemainingTimeTableViewCell
                cell.setup(maghrebDate: remainingtimeTableViewCellData.maghrebSalahDate)
                return cell
            }
            
            // Todays prayer table view cell date
            if let todaysPrayerTableViewCellData = cellData as? TodayPrayerTableViewCellData {
                
                let cell = self.tableView.dequeueReusableCell(withIdentifier: TodayPrayerTableViewCell.getReuseIdentifier()) as! TodayPrayerTableViewCell
                cell.setup(prayerString: todaysPrayerTableViewCellData.prayerString)
                return cell
            }
            
        }
         return UITableViewCell()
    }
}
