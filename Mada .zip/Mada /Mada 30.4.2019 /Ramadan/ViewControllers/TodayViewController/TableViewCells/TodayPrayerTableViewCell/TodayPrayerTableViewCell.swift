//
//  TodayPrayerTableViewCell.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Today prayer table view cell
class TodayPrayerTableViewCell: UITableViewCell {

    /// Prayer label
    @IBOutlet private weak var prayerLabel: UITextView!
    
    /// Ttile label
    @IBOutlet private weak var titleLabel: UILabel!
    
    /**
     Awake from nib
     */
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Set selection style
        self.selectionStyle = UITableViewCell.SelectionStyle.none
        
        self.titleLabel.textAlignment = NSTextAlignment.right
        self.titleLabel.text = "دعاء اليوم"
        self.titleLabel.font = UIFont(name: "NeoSansArabic-Bold", size: 20)
        
        self.prayerLabel.textAlignment = NSTextAlignment.right
        self.prayerLabel.isScrollEnabled = false
        self.prayerLabel.font = UIFont(name: "NeoSansArabic", size: 13)
    }
    
    /**
     Setup
     - Parameter prayerString: prayer text.
     */
    func setup(prayerString: String) {
        self.prayerLabel.text = prayerString
    }
    
    // MARK: - Class methods
    
    /**
     Get reuse identifier
     - Returns: cell reuse identfier
     */
    class func getReuseIdentifier() -> String {
        return "TodayPrayerTableViewCell"
    }
    
    /**
     Get cell height
     - Returns: Cell height
     */
    class func getCellHeight() -> CGFloat{
        return UITableView.automaticDimension
    }
}
