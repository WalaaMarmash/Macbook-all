//
//  TodayPrayerTableViewCellData.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Todays prayer table view cell data
class TodayPrayerTableViewCellData: CellData {
    
    /// Cell identifier
    var cellIdentifier: String
    
    // Cell height
    var cellHeight: CGFloat
    
    /// Prayer string
    private(set) var prayerString: String
    
    /**
     Initilizer
     */
    init() {
        self.cellIdentifier = TodayPrayerTableViewCell.getReuseIdentifier()
        self.cellHeight = TodayPrayerTableViewCell.getCellHeight()
        self.prayerString = ""
    }
    
    /**
     Initilizer
     - Parameter prayerString: Prayer string
     */
    convenience init(prayerString: String) {
        self.init()
        self.prayerString = prayerString
    }
}
