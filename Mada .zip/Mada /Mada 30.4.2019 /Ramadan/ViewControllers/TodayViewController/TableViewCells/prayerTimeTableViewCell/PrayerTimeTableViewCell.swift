//
//  PrayerTimeTableViewCell.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Prayer time table View cell
class PrayerTimeTableViewCell: UITableViewCell {

    /// Prayer time label
    @IBOutlet weak var prayerTimeLabel: UILabel!
    
    /// Prayer name label
    @IBOutlet weak var prayerNameLabel: UILabel!
    
    /// Prayer date label
    @IBOutlet weak var dateLabel: UILabel!
    
    /// Prayer image view
    @IBOutlet weak var prayerImageView: UIImageView!
    
    /**
     Awake from nib
     */
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Set selection style
        self.selectionStyle = UITableViewCell.SelectionStyle.none
        
        // Set date label
        self.dateLabel.textAlignment = NSTextAlignment.center
        
        // Set date label text
        self.dateLabel.text = self.getTodaysDateString()
        
        // Set prayer name label
        self.prayerNameLabel.textAlignment = NSTextAlignment.right
        
        // Set prayer time label
        self.prayerTimeLabel.textAlignment = NSTextAlignment.left
    }
    
    /**
     Setup
     - Parameter prayerType: prayer type to display its info
     - Parameter prayerTime: Date representing prayer
     */
    func setup(prayer: Prayer) {
        
        // Set name
        self.prayerNameLabel.text = prayer.type.getTitle()
        
        // Set image
        self.prayerImageView.image = UIImage(named: prayer.type.getPrayerImageName())
        
        // Set time
        self.prayerTimeLabel.text = prayer.getPrayerTimeString()
    }
    
    /**
     Get todays date string
     - Returns: String value representing date.
     */
    private func getTodaysDateString() -> String {
        var text = ""
        
        // Formatter
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        
        // Create week day
        let dateString = formatter.string(from: Date())
            
            formatter.dateFormat = "EEEE"
            
        let weekdayString = formatter.string(from: Date())
        if let weekDay = WeekDay(rawValue: weekdayString) {
            text = weekDay.getTitle()
        }
        
        return text + " " + dateString
    }
    
    // MARK: - Class methods
    
    /**
     Get reuse identifier
     - Returns: cell reuse identfier
     */
    class func getReuseIdentifier() -> String {
        return "PrayerTimeTableViewCell"
    }
    
    /**
     Get cell height
     - Returns: Cell height
     */
    class func getCellHeight() -> CGFloat{
        return 138
    }
}
