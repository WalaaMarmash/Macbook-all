//
//  PrayerTimeTableViewCellData.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Prayer time table view cell data
class PrayerTimeTableViewCellData: CellData {
    
    /// Cell identifier
    var cellIdentifier: String
    
    // Cell height
    var cellHeight: CGFloat
    
    /// Prayer
    private(set) var prayer: Prayer
    
    /**
     Initilizer
     */
    init() {
        self.cellIdentifier = PrayerTimeTableViewCell.getReuseIdentifier()
        self.cellHeight = PrayerTimeTableViewCell.getCellHeight()
        self.prayer = Prayer()
    }
    
    /**
     Initilizer
     - Parameter prayer: Prayer
     */
    convenience init(prayer: Prayer) {
        self.init()
        self.prayer = prayer
    }
}
