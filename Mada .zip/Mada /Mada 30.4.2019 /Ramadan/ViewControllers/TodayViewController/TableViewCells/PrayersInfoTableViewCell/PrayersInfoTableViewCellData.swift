//
//  PrayersInfoTableViewCellData.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Prayers Info Table View Cell Date
class PrayersInfoTableViewCellData: CellData {
    
    /// Cell identifier
    var cellIdentifier: String
    
    // Cell height
    var cellHeight: CGFloat
    
    /// Prayers
    var prayers: [Prayer]
    
    /// Selected prayer
    var selectedPrayer: Prayer
    
    /**
     Initilizer
     */
    init() {
        self.cellIdentifier = PrayersInfoTableViewCell.getReuseIdentifier()
        self.cellHeight = PrayersInfoTableViewCell.getCellHeight()
        self.prayers = []
        self.selectedPrayer = Prayer()
    }
    
    /**
     Initilizer
     - Parameter prayers: list pf prayers
     - Parameter selectedPrayer: selected prayer index
     */
    convenience init(prayers: [Prayer], selectedPrayer: Prayer) {
        self.init()
        self.prayers = prayers
        self.selectedPrayer = selectedPrayer
    }
}
