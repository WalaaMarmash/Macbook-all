//
//  PrayersInfoTableViewCell.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Prayer view index
private enum PrayerViewIndex :Int {
    case ishaa    = 0
    case maghreb
    case aser
    case dohor
    case sun
    case fajer
}

/// Prayers info table view cell
class PrayersInfoTableViewCell: UITableViewCell {
    
    /// Prayers stack view
    @IBOutlet private weak var prayersStackView: UIStackView!
    
    /// Ishaa prayer time label
    @IBOutlet private weak var ishaaPrayerTimeLabel: UILabel!
    
    /// Maghreb prayer time label
    @IBOutlet private weak var maghrebPrayerTimeLabel: UILabel!
    
    /// Fajer prayer time label
    @IBOutlet private weak var fajerPrayerTimeLabel: UILabel!
    
    /// Sun rise prayer time label
    @IBOutlet private weak var sunRisePrayerTimeLabel: UILabel!
    
    /// Dohor prayer time label
    @IBOutlet private weak var dohorPrayerTimeLabel: UILabel!
    
    /// Aser prayer time label
    @IBOutlet private weak var aserPrayerTimeLabel: UILabel!
    
    /**
     Awake from nib
     */
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Set selection style
        self.selectionStyle = UITableViewCell.SelectionStyle.none
    }
    
    /**
     Setup
     - Parameter data: prayer info table view cell data
     */
    func setup(data: PrayersInfoTableViewCellData) {
        
        var viewTypeIndex = PrayerViewIndex.ishaa
        for prayer in data.prayers {
            
            let prayerTime = prayer.getPrayerTimeString()
            
            // Set label text
            switch prayer.type {
                
            case .fajer:
                self.fajerPrayerTimeLabel.text = prayerTime
                
                // Set background color for view
                if data.selectedPrayer.type == PrayerType.fajer {
                    viewTypeIndex = PrayerViewIndex.fajer
                }
                
            case .sunRise:
                self.sunRisePrayerTimeLabel.text = prayerTime
                
                // Set background color for view
                if data.selectedPrayer.type == PrayerType.sunRise {
                    viewTypeIndex = PrayerViewIndex.sun
                }
                
            case .dohor:
                self.dohorPrayerTimeLabel.text = prayerTime
                
                // Set background color for view
                if data.selectedPrayer.type == PrayerType.dohor {
                    viewTypeIndex = PrayerViewIndex.dohor
                }
                
            case .aser:
                self.aserPrayerTimeLabel.text = prayerTime
                
                // Set background color for view
                if data.selectedPrayer.type == PrayerType.aser {
                    viewTypeIndex = PrayerViewIndex.aser
                }
                
            case .maghreb:
                self.maghrebPrayerTimeLabel.text = prayerTime
                
                // Set background color for view
                if data.selectedPrayer.type == PrayerType.maghreb {
                    viewTypeIndex = PrayerViewIndex.maghreb
                }
                
            case .ishaa:
                self.ishaaPrayerTimeLabel.text = prayerTime
                
                // Set background color for view
                if data.selectedPrayer.type == PrayerType.ishaa {
                    viewTypeIndex = PrayerViewIndex.ishaa
                }
            }
        }
        
        for (index, view) in self.prayersStackView.subviews.enumerated() {
            if index  == viewTypeIndex.rawValue {
                view.backgroundColor = UIColor(red: 220/255, green: 221/255, blue: 222/255, alpha: 1)
            } else {
                view.backgroundColor = UIColor.white
            }
        }
    }
    
    // MARK: - Class methods
    
    /**
     Get reuse identifier
     - Returns: cell reuse identfier
     */
    class func getReuseIdentifier() -> String {
        return "PrayersInfoTableViewCell"
    }
    
    /**
     Get cell height
     - Returns: Cell height
     */
    class func getCellHeight() -> CGFloat{
        return 127
    }
}
