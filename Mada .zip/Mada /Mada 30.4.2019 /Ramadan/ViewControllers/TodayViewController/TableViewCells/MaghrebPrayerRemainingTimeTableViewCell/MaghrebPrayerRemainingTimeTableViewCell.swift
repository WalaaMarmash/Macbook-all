//
//  MaghrebPrayerRemainingTimeTableViewCell.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Maghreb Prayer Remaining Time Table View Cell
class MaghrebPrayerRemainingTimeTableViewCell: UITableViewCell {

    /// Remianing time label
    @IBOutlet private weak var remainingTimeLabel: UILabel!
    
    /// Ttile label
    @IBOutlet private weak var titleLabel: UILabel!
    
    /// Maghreb date
    private var maghrebDate: Date!
    
    /**
     Awake from nib
     */
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Set selection style
        self.selectionStyle = UITableViewCell.SelectionStyle.none
        
        // Set title Label
        self.titleLabel.text = "الوقت المتبقي"
        self.titleLabel.textAlignment = NSTextAlignment.right
        
        // Set remianing time label
        self.remainingTimeLabel.textAlignment = NSTextAlignment.right
    }
    
    /**
     Set up
     - Parameter maghrebDate: maghreb date
     */
    func setup(maghrebDate: Date) {
        self.remainingTimeLabel.text = self.getDifferenceTimeString(date: maghrebDate)
        self.maghrebDate = maghrebDate
        Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(self.updateTimer)), userInfo: nil, repeats: true)
    }
    
    /**
     Update timer
     */
    @objc private func updateTimer() {
        self.remainingTimeLabel.text = self.getDifferenceTimeString(date: self.maghrebDate)
    }
    
    /**
     Get difference time string
     - Parameter Date: date to be compared to
     - Returns: String representing difference
     */
    private func getDifferenceTimeString(date: Date) -> String {
        
        // Get the difference
        let delta = Calendar.current.dateComponents([.hour, .minute, .second], from: Date(), to: date)
        
        // Difference ended
        if delta.hour! <= 0 {
            return "00:00:00"
        }
        
        let numberFormatter = NumberFormatter()
        numberFormatter.minimumIntegerDigits = 2
        numberFormatter.maximumIntegerDigits = 2
        numberFormatter.maximumFractionDigits = 0
        numberFormatter.minimumFractionDigits = 0
        
        if let hour = numberFormatter.string(from: NSNumber(value: delta.hour ?? 0)), let minute = numberFormatter.string(from: NSNumber(value: delta.minute ?? 0)), let seconds = numberFormatter.string(from: NSNumber(value: delta.second ?? 0)) {
        
            return "- " + hour + ":" + minute + ":" + seconds
        }
        return "00:00:00"
    }

    // MARK: - Class methods
    
    /**
     Get reuse identifier
     - Returns: cell reuse identfier
     */
    class func getReuseIdentifier() -> String {
        return "MaghrebPrayerRemainingTimeTableViewCell"
    }
    
    /**
     Get cell height
     - Returns: Cell height
     */
    class func getCellHeight() -> CGFloat{
        return 90
    }
}
