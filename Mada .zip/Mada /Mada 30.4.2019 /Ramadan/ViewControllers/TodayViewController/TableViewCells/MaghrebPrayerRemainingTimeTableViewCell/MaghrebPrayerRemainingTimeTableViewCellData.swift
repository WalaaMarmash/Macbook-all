//
//  MaghrebPrayerRemainingTimeTableViewCellData.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Maghreb Prayer Remaining Time Table View Cell Data
class MaghrebPrayerRemainingTimeTableViewCellData: CellData {
    
    /// Cell identifier
    var cellIdentifier: String
    
    // Cell height
    var cellHeight: CGFloat
    
    /// Maghreb salah date
    private(set) var maghrebSalahDate: Date
    
    /**
     Initilizer
     */
    init() {
        self.cellIdentifier = MaghrebPrayerRemainingTimeTableViewCell.getReuseIdentifier()
        self.cellHeight = MaghrebPrayerRemainingTimeTableViewCell.getCellHeight()
        self.maghrebSalahDate = Date()
    }
    
    /**
     Initilizer
     - Parameter maghrebSalahDate: maghreb salah date
     */
    convenience init(maghrebSalahDate: Date) {
        self.init()
        self.maghrebSalahDate = maghrebSalahDate
    }
}
