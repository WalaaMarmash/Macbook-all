//
//  ReminderBeforTimeTableViewCell.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/11/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Reminder before time table view cell
class ReminderBeforeTimeTableViewCell: UITableViewCell {
    
    /// Picker view
    @IBOutlet private weak var pickerView: UIPickerView!
    
    /// Title label
    @IBOutlet private weak var titleLabel: UILabel!
    
    /// Index path
    private var indexPath: IndexPath!
    
    /// Data source
    private var dataSource: [PrayerReminderBeforeTime] = [PrayerReminderBeforeTime.before40Mins, PrayerReminderBeforeTime.before30Mins, PrayerReminderBeforeTime.before20Mins, PrayerReminderBeforeTime.before10Mins, PrayerReminderBeforeTime.onTime]
    
    /// Delegate
    weak var delegate: ReminderBeforeTimeTableViewCellDelegate?
    
    /**
     Awake from nib
     */
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Set selection style
        self.selectionStyle = UITableViewCell.SelectionStyle.none
        
        // Set title label
        self.titleLabel.textAlignment = NSTextAlignment.center
        self.titleLabel.text = "متى ترغب ان تستيقظ ؟"
        
        // Set picker view
        self.pickerView.dataSource = self
        self.pickerView.delegate = self
    }
    
    /**
     Setup
     - Parameter prayerReminderBeforeTime:
     */
    func setup(data: ReminderBeforeTimeTableViewCellData, indexPath: IndexPath) {
        self.indexPath = indexPath
        
        // Prayer index
        let prayerIndex = self.dataSource.firstIndex(where: {$0.rawValue == data.prayerReminderBeforeTime.rawValue})
        
        // Select row
        self.pickerView.selectRow(prayerIndex!, inComponent: 0, animated: false)
    }
    
    // MARK: - Class methods
    
    /**
     Get reuse identifier
     - Returns: cell reuse identfier
     */
    class func getReuseIdentifier() -> String {
        return "ReminderBeforeTimeTableViewCell"
    }
    
    /**
     Get cell height
     - Returns: Cell height
     */
    class func getCellHeight() -> CGFloat{
        return 200
    }
}

// MARK: - UIPickerViewDataSource
extension ReminderBeforeTimeTableViewCell: UIPickerViewDataSource {
    
    /**
     Number of components
     */
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    /**
     Number of rows in component
     */
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 5
    }
}

// MARK:- UIPickerViewDelegate
extension ReminderBeforeTimeTableViewCell: UIPickerViewDelegate {
    
    /**
     Title for row
     */
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        // Check if row is in data source bounds
        if self.dataSource.count > row {
            
            // Return title
            return self.dataSource[row].getTitle()
        }
        
        return ""
    }
    
    /**
     View for row
     */
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        // Picker label
        var pickerLabel = view as? UILabel
        
        // First time
        if (pickerLabel == nil)
        {
            pickerLabel = UILabel()
            pickerLabel?.font = UIFont(name: "NeoSansArabic-Bold", size: 15)
            pickerLabel?.textAlignment = NSTextAlignment.center
            
            pickerLabel?.text = self.dataSource.count > row ? self.dataSource[row].getTitle() : ""
        }
        
        return pickerLabel!
    }
    
    /**
     Did select row
     */
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        // Check if row is in data source bounds
        if self.dataSource.count > row {
            
            // Return selected prayer before time
            self.delegate?.reminderBeforeTimeTableViewCellDidSelecte(prayerReminderBeforeTime: self.dataSource[row], indexPath: self.indexPath)
        }
    }
}

/// Reminder Before Time Table View Cell Delegate
protocol  ReminderBeforeTimeTableViewCellDelegate: NSObjectProtocol{
    func reminderBeforeTimeTableViewCellDidSelecte(prayerReminderBeforeTime: PrayerReminderBeforeTime, indexPath: IndexPath)
}
