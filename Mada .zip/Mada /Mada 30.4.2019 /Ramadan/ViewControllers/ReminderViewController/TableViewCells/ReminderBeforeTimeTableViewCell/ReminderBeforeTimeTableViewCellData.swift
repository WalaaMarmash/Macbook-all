//
//  ReminderBeforeTimeTableViewCellData.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Reminder Before Time Table View Cell Data
class ReminderBeforeTimeTableViewCellData: CellData {
    
    /// Cell identifier
    var cellIdentifier: String
    
    // Cell height
    var cellHeight: CGFloat
    
    /// Prayer reminder before time
    private(set) var prayerReminderBeforeTime: PrayerReminderBeforeTime
    
    /**
     Initilizer
     */
    init() {
        self.cellIdentifier = ReminderBeforeTimeTableViewCell.getReuseIdentifier()
        self.cellHeight = ReminderBeforeTimeTableViewCell.getCellHeight()
        self.prayerReminderBeforeTime = PrayerReminderBeforeTime.before30Mins
    }
    
    /**
     Initilizer
     - Parameter prayerReminderBeforeTime: prayer reminder before time
     */
    convenience init(prayerReminderBeforeTime: PrayerReminderBeforeTime) {
        self.init()
        self.prayerReminderBeforeTime = prayerReminderBeforeTime
    }
}
