//
//  ReminderDaysTableViewCell.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/11/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Day index
private enum DayIndex: Int {
    case sat = 0
    case sun
    case mon
    case tue
    case wed
    case thu
    case fri
}

/// Reminder days table view cell
class ReminderDaysTableViewCell: UITableViewCell {
    
    /// Title label
    @IBOutlet private weak var titleLabel: UILabel!
    
    /// Tuesday button
    @IBOutlet private weak var tuesdayButton: UIButton!
    
    /// Monday button
    @IBOutlet private weak var mondayButton: UIButton!
    
    // Sunday button
    @IBOutlet private weak var sundayButton: UIButton!
    
    // Saturday button
    @IBOutlet private weak var saturdayButton: UIButton!
    
    // Friday button
    @IBOutlet private weak var fridayButton: UIButton!
    
    // Thursday button
    @IBOutlet private weak var thursdayButton: UIButton!
    
    /// Wednsday button
    @IBOutlet private weak var wednsdayButton: UIButton!
    
    /// indexPath
    private var indexPath: IndexPath!
    
    /// Delegate
    weak var delegate: ReminderDaysTableViewCellDelegate?
    
    /// Save button
    @IBOutlet private weak var saveButton: UIButton!
    
    /**
     Awake from nib
     */
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Set selection style
        self.selectionStyle = UITableViewCell.SelectionStyle.none
        
        // Setup title
        self.titleLabel.textAlignment = NSTextAlignment.center
        self.titleLabel.text = "ايام الاسبوع"
        
        self.saveButton.setTitle("حفظ", for: UIControl.State.normal)
        
        // Setup buttons
        self.setupButton(button: self.saturdayButton, weekDay: WeekDay.saturday, tag: DayIndex.sat.rawValue)
        
        self.setupButton(button: self.sundayButton, weekDay: WeekDay.sunday, tag: DayIndex.sun.rawValue)
        
        self.setupButton(button: self.mondayButton, weekDay: WeekDay.monday, tag: DayIndex.mon.rawValue)
        
        self.setupButton(button: self.tuesdayButton, weekDay: WeekDay.tuesday, tag: DayIndex.tue.rawValue)
        
        self.setupButton(button: self.wednsdayButton, weekDay: WeekDay.wedensday, tag: DayIndex.wed.rawValue)
        
        self.setupButton(button: self.thursdayButton, weekDay: WeekDay.thursday, tag: DayIndex.thu.rawValue)
        
        self.setupButton(button: self.fridayButton, weekDay: WeekDay.friday, tag: DayIndex.fri.rawValue)
        
        // Shadow and Radius
        self.saveButton.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        self.saveButton.layer.cornerRadius = 10
        self.saveButton.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        self.saveButton.layer.shadowOpacity = 1.0
    }
    
    /**
     Setup
     - Parameter data: reminder days table view cell data
     - Parameter indexPath: cell index path
     */
    func setup(data: ReminderDaysTableViewCellData, indexPath: IndexPath) {
        self.indexPath = indexPath
        
        // Set is set
        for (key, value) in data.daysMap {
            
            switch key {
                
            case .saturday:
                self.changeButtonBackgroundColor(button: self.saturdayButton, isSelected: value)
            case .sunday:
                self.changeButtonBackgroundColor(button: self.sundayButton, isSelected: value)
            case .monday:
                self.changeButtonBackgroundColor(button: self.mondayButton, isSelected: value)
            case .tuesday:
                self.changeButtonBackgroundColor(button: self.tuesdayButton, isSelected: value)
            case .wedensday:
                self.changeButtonBackgroundColor(button: self.wednsdayButton, isSelected: value)
            case .thursday:
                self.changeButtonBackgroundColor(button: self.thursdayButton, isSelected: value)
            case .friday:
                self.changeButtonBackgroundColor(button: self.fridayButton, isSelected: value)
            }
        }
    }
    
    /**
     Circle buttons
     - Parameter button: UIButton
     */
    private func circleButtons(button: UIButton) {
        button.clipsToBounds = true
        button.layer.cornerRadius = button.frame.width / 2
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        self.circleButtons(button: self.saturdayButton)
        self.circleButtons(button: self.sundayButton)
        self.circleButtons(button: self.mondayButton)
        self.circleButtons(button: self.tuesdayButton)
        self.circleButtons(button: self.wednsdayButton)
        self.circleButtons(button: self.thursdayButton)
        self.circleButtons(button: self.fridayButton)
    }
    
    /**
     Setup button
     - Parameter button: UIbutton to be set
     - Parameter isSelected: selection status of button
     */
    private func setupButton(button: UIButton, weekDay: WeekDay, tag: Int) {
        
        // Set tag
        button.tag = tag
        button.tintColor = UIColor.clear
        
        // Set button border
        button.layer.borderColor = UIColor.black.cgColor
        button.layer.borderWidth = 1
        
        // Title color
        button.setTitleColor(UIColor.black, for: UIControl.State.normal)
        button.setTitleColor(UIColor.white, for: UIControl.State.selected)
        button.setTitle(weekDay.getTitle(), for: UIControl.State.normal)
        
        button.titleLabel?.text = weekDay.getTitle()
    }
    
    /**
     Change button back ground color
     - Parameter button: UIbutton
     - Parameter isSelected: selection status of button
     */
    private func changeButtonBackgroundColor(button: UIButton, isSelected: Bool) {
        button.isSelected = isSelected
        button.layer.borderWidth = isSelected ? 0 : 1
        button.backgroundColor = isSelected ? UIColor(red: 93/255, green: 208/255, blue: 184/255, alpha: 1) : UIColor.white
    }
    
    /**
     Did click save button
     */
    @IBAction func didClickSaveButton(_ sender: Any) {
        self.delegate?.reminderDaysTableViewCellDidClickSaveButton(indexPath: self.indexPath)
    }
    
    /**
     Did click button
     */
    @IBAction func didClickButton(_ sender: UIButton) {
        
        // Change button background color
        self.changeButtonBackgroundColor(button: sender, isSelected: !sender.isSelected)
        
        var weekDay = WeekDay.saturday
        
        // Get day index
        if let dayIndex = DayIndex(rawValue: sender.tag) {
            switch dayIndex {
                
            case .sat:
                weekDay = WeekDay.saturday
            case .sun:
                weekDay = WeekDay.sunday
            case .mon:
                weekDay = WeekDay.monday
            case .tue:
                weekDay = WeekDay.tuesday
            case .wed:
                weekDay = WeekDay.wedensday
            case .thu:
                weekDay = WeekDay.thursday
            case .fri:
                weekDay = WeekDay.friday
            }
        }
        self.delegate?.reminderDaysTableViewCellDidSelect(weekDay: weekDay, indexPath: self.indexPath)
    }
    
    // MARK: - class methods
    
    /**
     Get reuse identifier
     - Returns: cell reuse identfier
     */
    class func getReuseIdentifier() -> String {
        return "ReminderDaysTableViewCell"
    }
    
    /**
     Get cell height
     - Returns: Cell height
     */
    class func getCellHeight() -> CGFloat{
        return 294
    }
}

/// Reminder Days Table View Cell Delegate
protocol ReminderDaysTableViewCellDelegate: NSObjectProtocol {
    
    /**
     Did select days
     - Parameter weekDay: week day
     - Parameter indexPath: cell index path
     */
    func reminderDaysTableViewCellDidSelect(weekDay: WeekDay, indexPath: IndexPath)
    
    /**
     Did click save button
     - Parameter indexPath: cell index path
     */
    func reminderDaysTableViewCellDidClickSaveButton(indexPath: IndexPath)
}
