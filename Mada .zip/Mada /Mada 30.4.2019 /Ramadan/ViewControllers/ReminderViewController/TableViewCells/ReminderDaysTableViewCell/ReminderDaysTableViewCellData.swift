//
//  ReminderDaysTableViewCellData.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Reminder Days Table View Cell Data
class ReminderDaysTableViewCellData: CellData {
    
    /// Cell identifier
    var cellIdentifier: String
    
    // Cell height
    var cellHeight: CGFloat
    
    /// Days map
    var daysMap: [WeekDay: Bool]
    
    /**
     Initilizer
     */
    init() {
        self.cellIdentifier = ReminderDaysTableViewCell.getReuseIdentifier()
        self.cellHeight = ReminderDaysTableViewCell.getCellHeight()
        self.daysMap = [:]
    }
    
    /**
     Initilizer
     - Parameter days: prayer reminder days
     */
    convenience init(reminder: PrayerReminder) {
        self.init()
        
        // Build key values.
        for (key, value) in reminder.reminderDaysMap {
            self.daysMap.updateValue(value.first?.isSet ?? false, forKey: key)
        }
    }
}
