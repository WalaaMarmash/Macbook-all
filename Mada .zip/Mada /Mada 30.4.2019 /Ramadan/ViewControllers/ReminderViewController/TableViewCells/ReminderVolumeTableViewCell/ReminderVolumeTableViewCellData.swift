//
//  ReminderVolumeTableViewCellData.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Reminder Volume Table View Cell Data
class ReminderVolumeTableViewCellData: CellData {
    
    /// Cell identifier
    var cellIdentifier: String
    
    // Cell height
    var cellHeight: CGFloat
    
    /// Prayer reminder before time
    private(set) var volume: Float
    
    /**
     Initilizer
     */
    init() {
        self.cellIdentifier = ReminderVolumeTableViewCell.getReuseIdentifier()
        self.cellHeight = ReminderVolumeTableViewCell.getCellHeight()
        self.volume = 50
    }
    
    /**
     Initilizer
     - Parameter volume: Volume
     */
    convenience init(volume: Float) {
        self.init()
        self.volume = volume
    }
}
