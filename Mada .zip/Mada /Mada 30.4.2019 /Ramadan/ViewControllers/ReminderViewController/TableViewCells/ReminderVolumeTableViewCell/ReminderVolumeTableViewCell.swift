//
//  ReminderVolumeTableViewCell.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/11/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit


/// Reminder volume table view cell
class ReminderVolumeTableViewCell: UITableViewCell {

    /// Title label
    @IBOutlet private weak var titleLabel: UILabel!
    
    /// Slider
    @IBOutlet private weak var slider: UISlider!
    
    /// Index path
    private var indexPath: IndexPath!
    
    /// Delegate
    weak var delegate: ReminderVolumeTableViewCellDelegate?
    
    /**
     Awake from nib
     */
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Set selection style
        self.selectionStyle = UITableViewCell.SelectionStyle.none
        
        // Setup title label
        self.titleLabel.textAlignment = NSTextAlignment.center
        self.titleLabel.text = "صوت المنبه"
        
        // Set up progress bar
        // TODO: - setup progress bar
    }
    
    /**
     Setup
     - Parameter data: Reminder Volume Table View Cell.
     */
    func setup(data: ReminderVolumeTableViewCellData, indexPath: IndexPath) {
        self.indexPath = indexPath
        self.slider.setValue(data.volume, animated: false)
    }
    
    /**
     Did change value
     */
    @IBAction private func didChangeValue(_ sender: Any) {
        self.delegate?.reminderVolumeTableViewCell(didChangeVolume: self.slider.value, forIndexPath: self.indexPath)
    }
    
    // MARK: - Class methods
    
    /**
     Get reuse identifier
     - Returns: cell reuse identfier
     */
    class func getReuseIdentifier() -> String {
        return "ReminderVolumeTableViewCell"
    }
    
    /**
     Get cell height
     - Returns: Cell height
     */
    class func getCellHeight() -> CGFloat{
        return 90
    }
}

/// Reminder Volume Table View Cell Delegate
protocol ReminderVolumeTableViewCellDelegate: NSObjectProtocol {
    
    /**
     Did change volume
     - Parameter volume: float
     - Parameter indexPath: cell index path
     */
    func reminderVolumeTableViewCell(didChangeVolume volume: Float, forIndexPath: IndexPath)
}
