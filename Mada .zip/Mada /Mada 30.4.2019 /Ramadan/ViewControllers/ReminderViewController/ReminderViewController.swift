//
//  ReminderViewController.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/11/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit
import EventKit
import UserNotifications

/// Reminder view controller
class ReminderViewController: UIViewController {
    
    /// Activity ndicator
    @IBOutlet private weak var activityIndicator: UIActivityIndicatorView!
    
    /// Loading view
    @IBOutlet private weak var loadingView: UIView!
    
    /// Title label
    @IBOutlet private weak var titleLabel: UILabel!
    
    /// Table view
    @IBOutlet private weak var tableView: UITableView!
    
    /// Sections data
    private var sectionsData: [ReminderTableViewSectionHeaderViewData] = []
    
    /// Reminders
    private var reminders: [PrayerReminder] = []
    
    /// Selected Reminders
    private var selectedReminders: [PrayerReminder] = []
    
    /// Calendar days
    var calendarDays: [CalendarDay]!
    
    /// Today calendar day
    var todayCalendarDay: CalendarDay!
    
    /// Fajer reminder
    var fajerReminder: PrayerReminder!
    
    /**
     View did load
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //  Set navigation controller
        self.navigationItem.title = "التنبيهات"
        
        // Get reminders from user defaults or create them if its first time.
        self.reminders = self.getReminders()
        
        // Build data
        self.buildData()
        
        // Set up table view
        self.setupTableView()
        
        // Set up loading view
        self.setupLoadingView()
    }
    
    // MARK: - Setup
    
    /**
     Set up loading view
     */
    private func setupLoadingView() {
        self.activityIndicator.startAnimating()
        self.showLoadingView(show: false)
    }
    
    /**
     Show loading view
     - Parameter show: Boolean to show view
     */
    private func showLoadingView(show: Bool) {
        self.loadingView.isHidden = !show
    }
    
    /**
     Set up table view
     */
    private func setupTableView() {
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        // Set seperator style to none
        self.tableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        
        // Register headeer view
        ReminderTableViewSectionHeaderView.registerHeaderView(in: self.tableView)
        
        if #available(iOS 11.0, *) {
            self.tableView.contentInsetAdjustmentBehavior = .never
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
    }
    
    // MARK: - Build data
    
    /**
     Build fajer section data
     - Parameter reminder: Prayer reminder
     - Returns: fajer cell data
     */
    func buildFajerSectionData(reminder: PrayerReminder) -> [CellData] {
        
        var cellsData: [CellData] = []
        
        // Create section cell data
        // Reminder before time data
        let reminderBeforeTimeData = ReminderBeforeTimeTableViewCellData(prayerReminderBeforeTime: reminder.reminderBeforeTime)
        cellsData.append(reminderBeforeTimeData)
        
        // Reminder volume data
        let reminderVolumeData = ReminderVolumeTableViewCellData(volume: reminder.reminderVolume)
        cellsData.append(reminderVolumeData)
        
        // Reminder days data
        let daysData = ReminderDaysTableViewCellData(reminder: reminder)
        cellsData.append(daysData)
        
        return cellsData
    }
    
    /**
     Build Data
     */
    private func buildData() {
        self.sectionsData.removeAll()
        
        for i in 0 ..< self.reminders.count {
            
            if let prayer = self.todayCalendarDay.prayers.first(where: {$0.type == self.reminders[i].prayer.type}) {
                self.reminders[i].prayer = prayer
            }
            
            // Create section
            let sectionData = ReminderTableViewSectionHeaderViewData(reminder: self.reminders[i])
            
            // Only fajer pryer is expandable
            if self.reminders[i].prayer.type == PrayerType.fajer {
                sectionData.isExpandable = true
                sectionData.cellsData = self.buildFajerSectionData(reminder: self.reminders[i])
                
            }
            
            // Append section
            self.sectionsData.append(sectionData)
        }
    }
    
    /**
     Get reminders
     - Returns: array of prayer reminders.
     */
    private func getReminders() -> [PrayerReminder] {
        
        // Get from user defaults (saved in app)
        if let reminders = self.getRemindersFromUserDefaults() {
            
            // Set fajer reminders
            self.fajerReminder = reminders.first(where: {$0.prayer.type == PrayerType.fajer})
            
            return reminders
        }
        
        // There is not saved data in user defaults, create data for the first time
        return self.buildReminders()
    }
    
    /**
     Build reminders
     - Returns: array of reminders
     */
    private func buildReminders() -> [PrayerReminder] {
        
        // Reminders
        var reminders: [PrayerReminder] = []
        
        // Fajer prayer reminder
        let fajerPrayer = Prayer(type: PrayerType.fajer, dateTime: Date())
        let fajerReminder = PrayerReminder(prayer: fajerPrayer, reminderVolume: 50, days: self.calendarDays, reminderBeforeTime: PrayerReminderBeforeTime.before30Mins, isReminderSet: false)
        
        self.fajerReminder = fajerReminder
        reminders.append(fajerReminder)
        
        // Sun rise prayer reminder
        let sunRisePrayer = Prayer(type: PrayerType.sunRise, dateTime: Date())
        let sunRiseReminder = PrayerReminder(prayer: sunRisePrayer, reminderVolume: 50, days: self.calendarDays, reminderBeforeTime: PrayerReminderBeforeTime.onTime, isReminderSet: false)
        reminders.append(sunRiseReminder)
        
        // Dohor prayer reminder
        let dohorPrayer = Prayer(type: PrayerType.dohor, dateTime: Date())
        let dohorReminder = PrayerReminder(prayer: dohorPrayer, reminderVolume: 50, days: self.calendarDays, reminderBeforeTime: PrayerReminderBeforeTime.onTime, isReminderSet: false)
        reminders.append(dohorReminder)
        
        // Aser prayer reminder
        let aserPrayer = Prayer(type: PrayerType.aser, dateTime: Date())
        let aserReminder = PrayerReminder(prayer: aserPrayer, reminderVolume: 50, days: self.calendarDays, reminderBeforeTime: PrayerReminderBeforeTime.onTime, isReminderSet: false)
        reminders.append(aserReminder)
        
        // Maghreb prayer reminder
        let maghrebPrayer = Prayer(type: PrayerType.maghreb, dateTime: Date())
        let maghrebReminder = PrayerReminder(prayer: maghrebPrayer, reminderVolume: 50, days: self.calendarDays, reminderBeforeTime: PrayerReminderBeforeTime.onTime, isReminderSet: false)
        reminders.append(maghrebReminder)
        
        // Ishaa prayer reminder
        let ishaaPrayer = Prayer(type: PrayerType.ishaa, dateTime: Date())
        let ishaaReminder = PrayerReminder(prayer: ishaaPrayer, reminderVolume: 50, days: self.calendarDays, reminderBeforeTime: PrayerReminderBeforeTime.onTime, isReminderSet: false)
        reminders.append(ishaaReminder)
        
        // Save data
        self.saveRemindersToUserDefaults(reminders: reminders)
        
        return reminders
    }
}

//MARK: - UITableViewDelegate
extension ReminderViewController: UITableViewDelegate {
    
    /**
     Height for row at
     */
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        // Make sure section  count is in section range
        if self.sectionsData.count > indexPath.section {
            let section = self.sectionsData[indexPath.section]
            
            // make sure row in in cells range
            if section.cellsData.count > indexPath.row {
                return section.cellsData[indexPath.row].cellHeight
            }
        }
        return 0.0
    }
    
    /**
     HEight for header in section
     */
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        // Make sure section  count is in section range
        if self.sectionsData.count > section {
            return self.sectionsData[section].sectionHeight
        }
        return 0.0
    }
}

// MARK: - UITableViewDataSource
extension ReminderViewController: UITableViewDataSource {
    
    /**
     Number of sections
     */
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.sectionsData.count
    }
    
    
    /**
     Number of rows
     */
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        // Make sure section is in section data count
        if self.sectionsData.count > section {
            
            // If is expanded return all cells
            if self.sectionsData[section].isExpanded {
                return self.sectionsData[section].cellsData.count
            }
        }
        return 0
    }
    
    /**
     Cell for row at
     */
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Make sure section data is in range
        if self.sectionsData.count > indexPath.section {
            
            // Get section data
            let sectionData = self.sectionsData[indexPath.section]
            
            // make sure row is in cell index range
            if sectionData.cellsData.count > indexPath.row {
                
                // Get data
                let cellData = sectionData.cellsData[indexPath.row]
                
                // Reminder before time data
                if let reminderBeforeTimeData = cellData as? ReminderBeforeTimeTableViewCellData {
                    
                    let cell = self.tableView.dequeueReusableCell(withIdentifier: ReminderBeforeTimeTableViewCell.getReuseIdentifier()) as! ReminderBeforeTimeTableViewCell
                    cell.setup(data: reminderBeforeTimeData, indexPath: indexPath)
                    cell.delegate = self
                    return cell
                }
                
                // Reminder before time data
                if let reminderBeforeTimeData = cellData as? ReminderVolumeTableViewCellData {
                    
                    let cell = self.tableView.dequeueReusableCell(withIdentifier: ReminderVolumeTableViewCell.getReuseIdentifier()) as! ReminderVolumeTableViewCell
                    cell.delegate = self
                    cell.setup(data: reminderBeforeTimeData, indexPath: indexPath)
                    return cell
                }
                
                // Reminder before time data
                if let reminderBeforeTimeData = cellData as? ReminderDaysTableViewCellData {
                    
                    let cell = self.tableView.dequeueReusableCell(withIdentifier: ReminderDaysTableViewCell.getReuseIdentifier()) as! ReminderDaysTableViewCell
                    cell.setup(data: reminderBeforeTimeData, indexPath: indexPath)
                    cell.delegate = self
                    return cell
                }
            }
        }
        return UITableViewCell()
    }
    
    /**
     View for header in section
     */
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        // Make sure section in section range
        if self.sectionsData.count > section {
            
            // Get reminder
            let sectionData = self.sectionsData[section]
            
            // Get header view
            let headerView = self.tableView.dequeueReusableHeaderFooterView(withIdentifier: ReminderTableViewSectionHeaderView.getReuseIdentifier()) as! ReminderTableViewSectionHeaderView
            headerView.setup(data: sectionData, section: section)
            headerView.delegate = self
            return headerView
        }
        return nil
    }
}

// MARK: - ReminderDaysTableViewCellDelegate
extension ReminderViewController: ReminderDaysTableViewCellDelegate {
    
    /**
     Did select days
     */
    func reminderDaysTableViewCellDidSelect(weekDay: WeekDay, indexPath: IndexPath) {
        
        // Change is set value
        if self.reminders.count > indexPath.section {
            self.fajerReminder.toggleIsSet(for: weekDay)
            self.sectionsData[0].reminder = self.fajerReminder
            self.sectionsData[0].cellsData = self.buildFajerSectionData(reminder: self.fajerReminder)
        }
    }
    
    /**
     Did select save
     */
    func reminderDaysTableViewCellDidClickSaveButton(indexPath: IndexPath) {
        
        if self.reminders.count > indexPath.section {
            self.reminders[indexPath.section] = self.fajerReminder
            self.showLoadingView(show: true)
            
            self.removeAlarms(for: indexPath.section, completion: {
                self.createAlarm(for: indexPath.section, completion: {
                    
                    DispatchQueue.main.async {
                        // Get reminders from user defaults or create them if its first time.
                        self.reminders = self.getReminders()
                        
                        // Build data
                        self.buildData()
                        
                        self.showLoadingView(show: false)
                        
                        self.tableView.reloadData()
                    }
                })
            })
        }
    }
}

// MARK: - ReminderVolumeTableViewCellDelegate
extension ReminderViewController: ReminderVolumeTableViewCellDelegate {
    
    /**
     Did change colume
     */
    func reminderVolumeTableViewCell(didChangeVolume volume: Float, forIndexPath: IndexPath) {
        if self.reminders.count > forIndexPath.section {
            self.fajerReminder.setVoulme(volume: volume)
            self.sectionsData[0].reminder = self.fajerReminder
            self.sectionsData[0].cellsData = self.buildFajerSectionData(reminder: self.fajerReminder)
        }
    }
}

// MARK: - ReminderBefore timeTableViewCell
extension ReminderViewController: ReminderBeforeTimeTableViewCellDelegate {
    
    /**
     Did select
     */
    func reminderBeforeTimeTableViewCellDidSelecte(prayerReminderBeforeTime: PrayerReminderBeforeTime, indexPath: IndexPath) {
        
        if self.reminders.count > indexPath.section {
            self.fajerReminder.setReminderBeforetime(beforeTime: prayerReminderBeforeTime)
            self.sectionsData[0].reminder = self.fajerReminder
            self.sectionsData[0].cellsData = self.buildFajerSectionData(reminder: self.fajerReminder)
        }
    }
}

// MARK: - ReminderTableViewSectionHeaderViewDelegate
extension ReminderViewController: ReminderTableViewSectionHeaderViewDelegate {
    
    /**
     Reminder table view section header did click reminder button
     */
    func reminderTableViewSectionHeaderDidClickReminderButton(section: Int) {
        
        if self.sectionsData.count > section {
            
            // fajer section
            if section == 0 {
                
                // Set fajer reminder
                self.reminders[section] = self.fajerReminder
            }
            
            self.showLoadingView(show: true)
            
            !self.reminders[section].isReminderSet ? self.createAlarm(for: section, completion: {
                
                DispatchQueue.main.async {
                    // Get reminders from user defaults or create them if its first time.
                    self.reminders = self.getReminders()
                    
                    // Build data
                    self.buildData()
                    
                    self.showLoadingView(show: false)
                    
                    self.tableView.reloadData()
                }
                
            }) : self.removeAlarms(for: section, completion: {
                
                DispatchQueue.main.async {
                    // Get reminders from user defaults or create them if its first time.
                    self.reminders = self.getReminders()
                    
                    // Build data
                    self.buildData()
                    
                    self.showLoadingView(show: false)
                    
                    self.tableView.reloadData()
                }
            })
        }
    }
    
    /**
     Did click on section
     */
    func reminderTableViewSectionHeaderViewDidClickOnSection(section: Int) {
        
        if self.sectionsData.count > section {
            
            // Check if section is expandable
            if self.sectionsData[section].isExpandable {
                
                self.sectionsData[section].isExpanded = !self.sectionsData[section].isExpanded
                
                self.tableView.reloadSections([section], with: UITableView.RowAnimation.automatic)
            } else {
                self.reminderTableViewSectionHeaderDidClickReminderButton(section: section)
            }
        }
    }
}

// MARK: - Alarms
extension ReminderViewController {
    
    /**
     Remove Alarms
     */
    func createAlarm(for section: Int, completion: @escaping () -> ()) {
        
        if #available(iOS 10.0, *) {
            //iOS 10.0 and greater
            UNUserNotificationCenter.current().delegate = self
            UNUserNotificationCenter.current().requestAuthorization(options: [.badge, .sound, .alert], completionHandler: { granted, error in
                DispatchQueue.main.async {
                    if granted {
                        UIApplication.shared.registerForRemoteNotifications()
                    }
                    else {
                        self.showNotificationSettingsAlert()
                        completion()
                    }
                }
            })
        }
        else {
            //iOS 9
            let type: UIUserNotificationType = [UIUserNotificationType.badge, UIUserNotificationType.alert, UIUserNotificationType.sound]
            let setting = UIUserNotificationSettings(types: type, categories: nil)
            UIApplication.shared.registerUserNotificationSettings(setting)
            UIApplication.shared.registerForRemoteNotifications()
        }
        
        let reminder = self.reminders[section]
        var newReminderWeekDaysMap: [WeekDay: [PrayerReminderDay]] = [:]
        
        // Go throuh week days and their list
        for (weekDay, reminderDaysList) in reminder.reminderDaysMap {
            var newReminderDaysList: [PrayerReminderDay] = []
            
            // Go through days
            for day in reminderDaysList {
                
                // Check that date is not set and date has no events tore ID, and date has a value
                
                if ((reminder.prayer.type != PrayerType.fajer && !day.isSet) || day.isSet), day.eventStoreID.isEmpty, let date = day.date?.addingTimeInterval( TimeInterval(-1 * self.reminders[section].reminderBeforeTime.rawValue)), date >= Date() {
                    
                    if #available(iOS 10.0, *) {
                        //iOS 10 or above version
                        let center = UNUserNotificationCenter.current()
                        let content = UNMutableNotificationContent()
                        content.title = "موعد الصلاه"
                        content.categoryIdentifier = "alarm"
                        content.sound = UNNotificationSound(named: UNNotificationSoundName("adan30.mp3"))
                        let calendar = Calendar.current
                        let dateComponents = calendar.dateComponents([.year, .month, .day, .hour, .minute, .second], from: date)
                        
                        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
                        
                        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
                        center.add(request)
                        
                        var prayerReminderDay = PrayerReminderDay(date: date, isSet: true)
                        prayerReminderDay.eventStoreID = request.identifier
                        newReminderDaysList.append(prayerReminderDay)
                    } else {
                        // ios 9
                        let notification = UILocalNotification()
                        notification.fireDate = date
                        notification.alertTitle = "موعد الصلاه"
                        let uuid = UUID().uuidString
                        notification.userInfo = ["identifier": uuid]
                        notification.soundName = "adan.mp3"
                        UIApplication.shared.scheduleLocalNotification(notification)
                        
                        var prayerReminderDay = PrayerReminderDay(date: date, isSet: true)
                        prayerReminderDay.eventStoreID = uuid
                        newReminderDaysList.append(prayerReminderDay)
                    }
                } else {
                    newReminderDaysList.append(day)
                }
            }
            
            // Add new week day
            newReminderWeekDaysMap.updateValue(newReminderDaysList, forKey: weekDay)
        }
        
        self.reminders[section].reminderDaysMap = newReminderWeekDaysMap
        self.reminders[section].setIsSet(isSet: true)
        self.saveRemindersToUserDefaults(reminders: self.reminders)
        completion()
        
        // Access not granted
    }
    
    /**
     Remove alarms
     - Parameter reminder: Prayer reminder
     */
    func removeAlarms(for section: Int, completion: @escaping () -> ()) {
        
        if #available(iOS 10.0, *) {
            //iOS 10.0 and greater
            UNUserNotificationCenter.current().delegate = self
            UNUserNotificationCenter.current().requestAuthorization(options: [.badge, .sound, .alert], completionHandler: { granted, error in
                DispatchQueue.main.async {
                    if granted {
                        UIApplication.shared.registerForRemoteNotifications()
                    }
                    else {
                        self.showNotificationSettingsAlert()
                        completion()
                    }
                }
            })
        }
        else {
            //iOS 9
            let type: UIUserNotificationType = [UIUserNotificationType.badge, UIUserNotificationType.alert, UIUserNotificationType.sound]
            let setting = UIUserNotificationSettings(types: type, categories: nil)
            UIApplication.shared.registerUserNotificationSettings(setting)
            UIApplication.shared.registerForRemoteNotifications()
        }
        
        let reminder = self.reminders[section]
        var newReminderWeekDaysMap: [WeekDay: [PrayerReminderDay]] = [:]
        
        // Go throuh week days and their list
        for (weekDay, reminderDaysList) in reminder.reminderDaysMap {
            var newReminderDaysList: [PrayerReminderDay] = []
            
            // Go through days
            for day in reminderDaysList {
                
                // Check that date is not set and date has no events tore ID, and date has a value
                if !day.eventStoreID.isEmpty {
                    
                    if #available(iOS 10.0, *) {
                        let center = UNUserNotificationCenter.current()
                        center.removePendingNotificationRequests(withIdentifiers: [day.eventStoreID])
                        var prayerReminderDay = PrayerReminderDay(date: day.date, isSet: false)
                        prayerReminderDay.eventStoreID = ""
                        newReminderDaysList.append(prayerReminderDay)
                    } else {
                        
                        let app: UIApplication = UIApplication.shared
                        
                        for oneEvent in app.scheduledLocalNotifications! {
                            
                            let notification = oneEvent as UILocalNotification
                            var identifier = ""
                            if let userInfoCurrent = notification.userInfo! as? [String: String], let uid = userInfoCurrent["identifier"] {
                                identifier = uid
                                
                                if identifier == day.eventStoreID {
                                    //Cancelling local notification
                                    app.cancelLocalNotification(notification)
                                    var prayerReminderDay = PrayerReminderDay(date: day.date, isSet: false)
                                    prayerReminderDay.eventStoreID = ""
                                    newReminderDaysList.append(prayerReminderDay)
                                    continue
                                } else {
                                    newReminderDaysList.append(day)
                                }
                            }
                        }
                    }
                } else {
                    newReminderDaysList.append(day)
                }
            }
            
            // Add new week day
            newReminderWeekDaysMap.updateValue(newReminderDaysList, forKey: weekDay)
        }
        
        self.reminders[section].reminderDaysMap = newReminderWeekDaysMap
        self.reminders[section].setIsSet(isSet: false)
        self.saveRemindersToUserDefaults(reminders: self.reminders)
        completion()
    }
}

// MARK: - Alerts

extension ReminderViewController {
    
    /**
     Show alert
     */
    private func showNotificationSettingsAlert() {
        
        // Create alert
        let alert = UIAlertController(title: "تفعيل التنبيهات", message: "يرجى تفعيل التنبيهات للاستمرار", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "الاعدادات", style: UIAlertAction.Style.default, handler: { (alert: UIAlertAction!) in
            
            self.goToNotificationSettings()
        }))
        
        // Show alert
        self.present(alert, animated: true)
    }
    
    /**
     Go to notification settings
     */
    func goToNotificationSettings() {
        
        // present an alert advising the user that they need to go to the settings menu to enable the permissions as they have previously denied it.
        // if the user presses Open Settings on the alert....
        if let url = URL(string: UIApplication.openSettingsURLString) {
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
}

// MARK: - Save data to user defaults
extension ReminderViewController {
    
    /**
     Save reminders to user defaults
     - Parameter reminders: list of prayer reminders
     */
    private func saveRemindersToUserDefaults(reminders: [PrayerReminder]) {
        
        // Encoder
        let jsonEncoder = JSONEncoder()
        
        do {
            
            // Encode data
            let jsonData = try jsonEncoder.encode(reminders)
            
            // Save data
            UserDefaultssUtils.setObjectValue(jsonData, forKey: "reminders")
        } catch(let error) {
            print("failed to encode reminders \(error.localizedDescription)")
        }
    }
    
    /**
     Get reminders from user defaults
     */
    private func getRemindersFromUserDefaults() -> [PrayerReminder]? {
        
        // Decoder
        let jsonDecoder = JSONDecoder()
        
        if let data = UserDefaultssUtils.getObjectValueForKey("reminders") as? Data {
            
            // Decode
            do {
                return try jsonDecoder.decode([PrayerReminder].self, from: data)
            } catch (let error) {
                print("failed to decode reminders \(error.localizedDescription)")
            }
        }
        return nil
    }
}

// MARK: - UNUserNotificationCenterDelegate
extension ReminderViewController: UNUserNotificationCenterDelegate {
    
}




