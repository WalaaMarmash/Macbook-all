//
//  ReminderTableViewSectionHeaderViewData.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Reminder Table View Section Header View Data
class ReminderTableViewSectionHeaderViewData: SectionData {
    
    /// Section height
    var sectionHeight: CGFloat
    
    /// Section identifier
    var sectionIdentifier: String
    
    /// is Expanded
    var isExpanded: Bool
    
    /// is Expandable
    var isExpandable: Bool
    
    /// Cells data
    var cellsData: [CellData]
    
    /// Reminder
    var reminder: PrayerReminder
    
    /**
     Initilizer
     */
    init() {
        self.sectionHeight = ReminderTableViewSectionHeaderView.getViewHeight()
        self.sectionIdentifier = ReminderTableViewSectionHeaderView.getReuseIdentifier()
        self.isExpanded = false
        self.isExpandable = false
        self.cellsData = []
        self.reminder = PrayerReminder()
    }
    
    /**
     Initilizer
     - Parameter reminder: prayer reminder
     */
    convenience init(reminder: PrayerReminder) {
        self.init()
        self.reminder = reminder
    }
}
