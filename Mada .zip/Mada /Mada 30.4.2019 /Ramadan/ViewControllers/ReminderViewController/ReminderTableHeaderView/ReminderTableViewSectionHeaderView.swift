//
//  ReminderTableViewSectionHeaderView.swift
//  Ramadan
//
//  Created by Fratello Software Group on 3/14/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Reminder Table View Section Header View
class ReminderTableViewSectionHeaderView: UITableViewHeaderFooterView {
    
    /// Prayer title label
    @IBOutlet private weak var prayerTitleLabel: UILabel!
    
    /// Prayer time label
    @IBOutlet private weak var prayerTimeLabel: UILabel!
    
    /// Prayer image view
    @IBOutlet private weak var prayerImageView: UIImageView!
    
    /// Reminder button
    @IBOutlet private weak var reminderButton: UIButton!
    
    /// index path
    private var section: Int!
    
    /// Delegate
    weak var delegate: ReminderTableViewSectionHeaderViewDelegate?
    
    /**
     Did click on reminder button
     */
    @IBAction func didClickOnReminderButton(_ sender: UIButton) {
        self.delegate?.reminderTableViewSectionHeaderDidClickReminderButton(section: section)
    }
    
    @IBAction func didClickOnButton(_ sender: Any) {
        self.delegate?.reminderTableViewSectionHeaderViewDidClickOnSection(section: self.section)
    }
    /**
     Awake From Nib
     */
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Set labels
        self.prayerTitleLabel.textAlignment = NSTextAlignment.center
        self.prayerTimeLabel.textAlignment = NSTextAlignment.center
    }
    
    /**
     Setup
     - Parameter data: reminder table view section header view data
     - Parameter section: section index
     */
    func setup(data: ReminderTableViewSectionHeaderViewData, section: Int) {
        
        // Set section
        self.section = section
        
        // Set values
        self.prayerTitleLabel.text = data.reminder.prayer.type.getTitle()
        self.prayerTimeLabel.text = data.reminder.prayer.getPrayerTimeString()
        self.prayerImageView.image = UIImage(named: data.reminder.prayer.type.getPrayerImageName())
        
        // Set remider
        let imageName = data.reminder.isReminderSet ? "alarm_black" : "alarm_white"
        self.reminderButton.setImage(UIImage(named: imageName), for: UIControl.State.normal)
    }
    
    /**
     Did click on header view
     */
    @IBAction func didClickOnHeaderView(_ sender: Any) {
        self.delegate?.reminderTableViewSectionHeaderViewDidClickOnSection(section: self.section)
    }
    
    // MARK: - Class methods
    
    /**
     Get view reuse identifier
     - Returns : View reuse identifier
     */
    class func getReuseIdentifier() -> String {
        return "ReminderTableViewSectionHeaderView"
    }
    
    /**
     Register header view class in the table
     - Parameter tableView : The table view to register the header view in it
     */
    class func registerHeaderView(in tableView: UITableView) {
        tableView.register(UINib(nibName: "ReminderTableViewSectionHeaderView", bundle: Bundle.main), forHeaderFooterViewReuseIdentifier: ReminderTableViewSectionHeaderView.getReuseIdentifier())
    }
    
    /**
     Get View height
     */
    class func getViewHeight() -> CGFloat {
        return 60
    }
}

/// Reminder Table View Section Header View Delegate
protocol ReminderTableViewSectionHeaderViewDelegate: NSObjectProtocol {
    
    /**
     Did click on section
     - Parameter section: Section.
     */
    func reminderTableViewSectionHeaderViewDidClickOnSection(section: Int)
    
    func reminderTableViewSectionHeaderDidClickReminderButton(section: Int)
}
