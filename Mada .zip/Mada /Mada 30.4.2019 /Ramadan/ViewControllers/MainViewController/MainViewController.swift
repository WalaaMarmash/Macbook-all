//
//  MainViewController.swift
//  Ramadan
//
//  Created by Fratello Software Group on 4/19/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Main view controller
class MainViewController: UIViewController {
    
    /// Ringer button
    @IBOutlet private weak var ringerButton: UIButton!
    
    /// Calemndar button
    @IBOutlet private weak var calendarButton: UIButton!
    
    /// Home button
    @IBOutlet private weak var homeButton: UIButton!
    
    /// Logo view
    @IBOutlet private weak var logoView: UIView!
    
    /// Ringer view
    @IBOutlet private weak var ringerView: UIView!
    
    /// Home view
    @IBOutlet private weak var homeView: UIView!
    
    /// Calendar view
    @IBOutlet private weak var calendarView: UIView!
    
    /// Ramadan calendar days
    var ramadanCalendarDays: [CalendarDay]!
    
    /// Today calendar day
    var todayCalendarDay: CalendarDay!
    
    /// Pink circle view
    @IBOutlet private weak var pinkCircleView: UIView!
    
    /// Yellow circle view
    @IBOutlet private weak var yellowCircleView: UIView!
    
    /// Pink circle vertical constraint
    @IBOutlet private weak var pinkCircleVerticalConstraint: NSLayoutConstraint!
    /// Calendar reminder days
    var calendarReminderDays: [CalendarDay]!
    
    /// Pezier path
    var path: CGMutablePath?
    
    /**
     View did load
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set title font
        self.navigationController?.navigationBar.titleTextAttributes =
            [NSAttributedString.Key.font: UIFont(name: "NeoSansArabic-Bold", size: 20)!]
    }
    
    /**
     View will appear
     */
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // set navigation bar hidden
        self.navigationController?.isNavigationBarHidden = true
    }
    
    /**
     View will layout sub views
     */
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        // Set calendar button
        self.calendarButton.layer.cornerRadius = self.calendarView.frame.height / 2
        self.calendarButton.clipsToBounds = true
        
        // Set home button
        self.homeButton.layer.cornerRadius = self.homeView.frame.height / 2
        self.homeButton.clipsToBounds = true
        
        // Set ringer button
        self.ringerButton.layer.cornerRadius = self.ringerView.frame.height / 2
        self.ringerButton.clipsToBounds = true
        
        // Set logo view
        self.logoView.layer.cornerRadius = self.logoView.frame.height / 2
        self.logoView.layer.borderColor = UIColor(red: 229/255, green: 34/255, blue: 99/255, alpha: 1).cgColor
        self.logoView.layer.borderWidth = 1
        
        // Set yellow circle
        self.yellowCircleView.layer.cornerRadius = self.yellowCircleView.frame.height / 2
        self.yellowCircleView.layer.borderColor = UIColor(red: 1, green: 213/255, blue: 0, alpha: 1).cgColor
        self.yellowCircleView.layer.borderWidth = 1
        
        // Set red circle
        self.pinkCircleView.layer.cornerRadius = self.pinkCircleView.frame.height / 2
        self.pinkCircleView.layer.borderColor = UIColor(red: 229/255, green: 34/255, blue: 99/255, alpha: 1).cgColor
        self.pinkCircleView.layer.borderWidth = 1
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        // Update pink circle vertical spacing
        var topPadding: CGFloat = 0.0
        if #available(iOS 11.0, *) {
            let window = UIApplication.shared.keyWindow
            topPadding = window?.safeAreaInsets.top ?? 0.0
        }
        
        self.pinkCircleVerticalConstraint.constant = abs(topPadding) / 2
        self.drawLogoToRingerStrokeLine()
    }
    
    /**
     View will disappear
     */
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // set navigation bar hidden
        self.navigationController?.isNavigationBarHidden = false
    }
    
    // MARK: - Navigation
    /**
     Did click navigate to tab bar button
     */
    @IBAction func didClickNavigateToTabBarButton(_ sender: Any) {
        var segueIdentifer = ""
        
        // Cast button to perform segue.
        if let button = sender as? UIButton {
            if button == self.homeButton {
                segueIdentifer = "ShowTodayViewController"
            } else if button == self.calendarButton {
                segueIdentifer = "ShowCalendarViewController"
            } else {
                segueIdentifer = "ShowReminderViewController"
            }
        }
        
        self.performSegue(withIdentifier: segueIdentifer, sender: sender)
    }
    
    /**
     Prepare for segue
     */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        /// Home button
        if segue.identifier == "ShowTodayViewController", let homeViewcontroller = segue.destination as? TodayViewController {
            homeViewcontroller.calendarDay = self.todayCalendarDay
            
            /// Calendar button
        } else if segue.identifier == "ShowCalendarViewController", let calendarViewController = segue.destination as? CalendarViewController {
            calendarViewController.calendarDays = self.ramadanCalendarDays
            
            /// Ringer button
        } else if segue.identifier == "ShowReminderViewController", let reminderViewController = segue.destination as? ReminderViewController {
            reminderViewController.calendarDays = self.calendarReminderDays
            reminderViewController.todayCalendarDay = self.todayCalendarDay
        }
    }
    
    // MARK: - Draw lines
    
    /**
     Draw logo to ringer stroke line
     */
    func drawLogoToRingerStrokeLine() {
        
        if self.path == nil {
            // Logo view point
            let  p0 = CGPoint(x: self.logoView.frame.origin.x - 5 , y: self.logoView.center.y)
            
            /// ringer view point
            let  p1 = CGPoint(x: self.ringerView.frame.origin.x + self.ringerView.frame.width + 5, y: self.ringerView.center.y)
            
            self.path = CGMutablePath()
            self.path?.addLines(between: [p1, p0])
            
            /// Logo
            let  p2 = CGPoint(x: self.logoView.center.x + 7 , y: self.logoView.frame.origin.y - 10)
            
            // Logo view half point
            let  p3 = CGPoint(x: self.logoView.frame.origin.x - 5 , y: self.homeView.center.y)
            
            /// home view point
            let  p4 = CGPoint(x: self.homeView.frame.origin.x + self.homeView.frame.width + 5, y: self.homeView.center.y)
            
            
            let logoToHomePath1 = CGMutablePath()
            logoToHomePath1.addLines(between: [p2, p3])
            self.path?.addPath(logoToHomePath1)
            
            let logoToHomePath2 = CGMutablePath()
            logoToHomePath2.addLines(between: [p3, p4])
            self.path?.addPath(logoToHomePath2)
            
            /// Logo
            let  p5 = CGPoint(x: self.logoView.frame.origin.x + 10 , y: self.logoView.frame.origin.y + self.logoView.frame.height)
            
            // Logo view half point
            let x = self.logoView.frame.origin.x - ((self.logoView.frame.origin.x - (self.calendarView.frame.origin.x + self.calendarView.frame.width))/2)
            let  p6 = CGPoint(x: x , y: self.calendarView.center.y)
            
            /// home view point
            let  p7 = CGPoint(x: self.calendarView.frame.origin.x + self.calendarView.frame.width + 5, y: self.calendarView.center.y)
            
            let logoToCalendarPath1 = CGMutablePath()
            logoToCalendarPath1.addLines(between: [p5, p6])
            self.path?.addPath(logoToCalendarPath1)
            
            let logoToCalendarPath2 = CGMutablePath()
            logoToCalendarPath2.addLines(between: [p6, p7])
            self.path?.addPath(logoToCalendarPath2)
            
            let shapeLayer = CAShapeLayer()
            shapeLayer.strokeColor = UIColor(red: 182/255, green: 182/255, blue: 182/255, alpha: 182/255).cgColor
            shapeLayer.lineWidth = 1
            shapeLayer.lineDashPattern = [10, 7] // 7 is the length of dash, 3 is length of the gap.
            
            shapeLayer.path = self.path
            view.layer.addSublayer(shapeLayer)
        }
    }
}
