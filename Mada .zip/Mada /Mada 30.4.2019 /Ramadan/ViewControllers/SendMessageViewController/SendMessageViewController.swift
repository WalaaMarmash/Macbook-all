//
//  SendMessageViewController.swift
//  Ramadan
//
//  Created by Fratello Software Group on 3/19/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit
import MessageUI
import ContactsUI

/// Send message view controller type
enum SendMessageViewControllerType {
    case sohor
    case fotor
}

/// Send message view controller
class SendMessageViewController: UIViewController, UIPickerViewDelegate, MFMessageComposeViewControllerDelegate {

    /// Text field
    @IBOutlet private weak var textField: UITextField!
    
    /// Contacts label
    @IBOutlet private weak var contactsLabel: UILabel!
    
    /// Send message button
    @IBOutlet private weak var sendMessageButton: UIButton!
    
    /// Request date button
    @IBOutlet private weak var requestDateButton: UIButton!
    
    /// Add recievers button
    @IBOutlet private weak var addContactsButton: UIButton!
    
    /// Yellow bubble view
    @IBOutlet private weak var yellowBubbleView: UIView!
    
    /// Pink circle view
    @IBOutlet private weak var pinkCircleView: UIView!
    
    /// contacts
    private var contacts: [CNContact] = []
    
    /// Type
    var type: SendMessageViewControllerType = SendMessageViewControllerType.fotor
    
    /// Picker
    private let picker = UIDatePicker()
    
    /// Delegate
    weak var delegate: SendMessageViewControllerDelegate?
    
    /**
     View did load
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        self.yellowBubbleView.layer.borderColor = UIColor(red: 1, green: 206/255, blue: 0, alpha: 1).cgColor
        
        
        // Set navigation item
        self.navigationItem.title = "ارسال دعوه"
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font: UIFont(name: "NeoSansArabic-Bold", size: 20)!]

        self.navigationItem.rightBarButtonItem?.setTitleTextAttributes([NSAttributedString.Key.font: UIFont(name: "NeoSansArabic-Bold", size: 17)!], for: UIControl.State.normal)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "الغاء", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.didClickCancelButton))
        
        // Shadow and Radius
        self.sendMessageButton.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        self.sendMessageButton.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        self.sendMessageButton.layer.shadowOpacity = 1.0
        
        // Shadow and Radius
        self.requestDateButton.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        self.requestDateButton.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        self.requestDateButton.layer.shadowOpacity = 1.0
        
        // Shadow and Radius
        self.addContactsButton.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        self.addContactsButton.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        self.addContactsButton.layer.shadowOpacity = 1.0
        
        // Picker view
        picker.datePickerMode = UIDatePicker.Mode.date
        picker.minimumDate = Date()
        self.textField.inputView = picker
        
        // Add toolbar
        let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        toolbar.barStyle = UIBarStyle.default
        toolbar.items = [UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil), UIBarButtonItem(title: "اختيار", style: UIBarButtonItem.Style.plain, target: self, action: #selector(didClickDoneButton))]
        toolbar.sizeToFit()
        self.textField.inputAccessoryView = toolbar
        
        // Set up contacts label
        self.contactsLabel.numberOfLines = 0
        self.contactsLabel.textAlignment = NSTextAlignment.center
        self.contactsLabel.lineBreakMode = NSLineBreakMode.byTruncatingTail
        
        // Set pink cirle
        self.pinkCircleView.layer.borderColor = UIColor(red: 227/255, green: 20/255, blue: 94/255, alpha: 1).cgColor
    }
    
    /**
     Did click done button
     */
    @objc private func didClickDoneButton() {
        self.textField.resignFirstResponder()
        
        // Get date string
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        let dateString = dateFormatter.string(from: self.picker.date)
        
        self.requestDateButton.setTitle(dateString, for: UIControl.State.normal)
    }
    
    /**
     Did click cancel button
     */
    @objc private func didClickCancelButton() {
        self.dismiss(animated: true, completion: {})
    }
    
    /**
     Request date button clicked
     */
    @IBAction func requestDateButtonClicked(_ sender: Any) {
        self.textField.becomeFirstResponder()
    }
    
    /**
     Add contacts button clicked
     */
    @IBAction func addContactsButtonClicked(_ sender: Any) {
        self.openContactViewController()
    }
    
    /**
     Send message button clicked
     */
    @IBAction func sendMessageButtonClicked(_ sender: Any) {
        
        // Get date string
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        let dateString = dateFormatter.string(from: self.picker.date)
        
        // Message vc
        let messageVC = MFMessageComposeViewController()
        messageVC.messageComposeDelegate = self
        
        var message = "أنت مدعو بتاريخ" + " " + dateString + " "
        message += self.type == SendMessageViewControllerType.fotor ? "لحضور الفطور" : "لحضور السحور"
        
        // Set message body
        messageVC.body = message

        // Set message reciepts
        messageVC.recipients = self.contacts.compactMap({self.getContactNumber(contact: $0)})
        
        // Present view controller
        self.present(messageVC, animated: true, completion: nil)
    }
    
    /**
     did finish with
     */
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        switch (result) {
        case .cancelled:
            print("Message was cancelled")
            self.dismiss(animated: true, completion: nil)
        case .failed:
            print("Message failed")
            self.dismiss(animated: true, completion: nil)
        case .sent:
            print("Message was sent")
            
            // Save messages to user defaults
            if var invitations = UserDefaultssUtils.getObjectValueForKey("messages") as? [Date] {
                invitations.append(Calendar.current.startOfDay(for: self.picker.date))
                UserDefaultssUtils.setObjectValue(invitations, forKey: "messages")
            } else {
                UserDefaultssUtils.setObjectValue([Calendar.current.startOfDay(for: self.picker.date)], forKey: "messages")
            }
            
            // Update previous vc
            self.delegate?.didSendMessage()
            
            self.dismiss(animated: true, completion: nil)
        default:
            break
        }
    }
}

// MARK: Contact picker
extension SendMessageViewController: CNContactPickerDelegate{
    
    /**
     Open contact picker view controller
     */
    func openContactViewController() {
        let contactPicker = CNContactPickerViewController()
        contactPicker.delegate = self
        contactPicker.displayedPropertyKeys =
            [CNContactGivenNameKey
                , CNContactPhoneNumbersKey]
        self.present(contactPicker, animated: true, completion: nil)
    }
    
    /**
     Did select contacts
     */
    func contactPicker(_ picker: CNContactPickerViewController, didSelect contacts: [CNContact]) {
        self.contacts = contacts
        self.contactsLabel.text = self.buildContactsText(contacts: contacts)
    }
    
    /**
     Build contacts text
     - Parameter contacts: contacts
     */
    private func buildContactsText(contacts: [CNContact]) -> String {
        guard contacts.count > 0 else {return ""}
        
        var contactsString = "المدعووين" + ":" + " "
        
        for i in 0 ..< contacts.count - 1 {
            contactsString += contacts[i].givenName + ", "
        }
        
        if let lastContact = contacts.last {
            contactsString += lastContact.givenName
        }
        return contactsString
    }
    
    /**
     Get contact number
     */
    private func getContactNumber(contact: CNContact) -> String? {
        if contact.phoneNumbers.count > 0 {
            
            if let phoneNumber = contact.phoneNumbers.first?.value, let digits = phoneNumber.value(forKey: "digits") as? String {
                return digits
            }
        }
        return nil
    }
}

/// Send message view controller delegate
protocol SendMessageViewControllerDelegate: NSObjectProtocol {
    
    // Did send message
    func didSendMessage()
}
