//
//  LandingViewController.swift
//  Ramadan
//
//  Created by Fratello Software Group on 3/15/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit
import CoreLocation

/// Request type
private enum RequestType {
    case firstMonth
    case secondMonth
}

/// Failure type
private enum FailureType {
    case locationDenied
    case requestFailure
}

/// Values
private struct Values {
    static let firstMonthStartIndex: Int = 5
    static let secondMonthLastIndex: Int = 6
    static let ramadanDaysNumber: Int = 30
}

/// Landing view controller
class LandingViewController: UIViewController {
    
    /// Loading view
    @IBOutlet private weak var loadingView: UIView!
    
    /// Activity indicator View
    @IBOutlet private weak var activityIndicatorView: UIActivityIndicatorView!
    
    /// Failure button
    @IBOutlet private weak var failureButton: UIButton!
    
    /// Failure label
    @IBOutlet private weak var failureLabel: UILabel!
    
    /// Failure container view
    @IBOutlet private weak var failureContainerView: UIView!
    
    /// Location manager
    var locManager: CLLocationManager!
    
    /// Request status list
    private var requestStatusList: [RequestType: RequestStatus] = [:]
    
    /// First month calendar days (May month)
    private var firstMonthCalendarDays: [CalendarDay] = []
    
    /// Second month calendar days (June month)
    private var secondMonthCalendarDays: [CalendarDay] = []
    
    /// Ramadan calendar days
    private var ramadanCalendarDays: [CalendarDay] = []
    
    /// Today calendar day
    private var todayCalendarDay: CalendarDay = CalendarDay()
    
    /// Calendar reminder days
    private var calendarReminderDays: [CalendarDay] = []
    
    /// Is data loading
    private var isDataLoading: Bool {
        
        // Check if data is loading
        for requestStatus in self.requestStatusList.values {
            if requestStatus == RequestStatus.loading {
                return true
            }
        }
        return false
    }
    
    /**
     View did load
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup failure view
        self.setupFailureView()
        
        // Set up loading view
        self.setupLoadingView()
        
        // Init request statuses with success as initial value, as they may not be requested if user dont have access to location enabled.
        self.requestStatusList = [RequestType.firstMonth: RequestStatus.success, RequestType.secondMonth: RequestStatus.success]
        
        // Request authntication
        locManager = CLLocationManager()
        locManager.requestWhenInUseAuthorization()
        locManager.delegate = self
    }
    
    // MARK: - Failure view
    /**
     Setup failure view
     */
    private func setupFailureView() {
        self.failureLabel.textAlignment = NSTextAlignment.center
        self.failureLabel.numberOfLines = 0
        self.showFailureView(show: false)
    }
    
    /**
     Show failure view
     - Parameter show: Boolean to indicate to show or hide view
     */
    private func showFailureView(show: Bool) {
        self.failureContainerView.isHidden = !show
    }
    
    // MARK: - Loading view
    
    /**
     Setup loading view
     */
    private func setupLoadingView() {
        self.activityIndicatorView.color = UIColor(red: 0, green: 169/255, blue: 243/255, alpha: 1)
        self.activityIndicatorView.startAnimating()
        self.showLoadingView(show: true)
    }
    
    /**
     Show loading view
     - Parameter show: Boolean to indicate to show or hide view
     */
    private func showLoadingView(show: Bool) {
        self.loadingView.isHidden = !show
    }
    
    // MARK: - build date
    /**
     Build data
     */
    private func buildData() {
        
        // Build data when all requests returned successfully
        for requestStatus in self.requestStatusList.values {
            if requestStatus != RequestStatus.success {
                return
            }
        }
        
        // Clear data
        self.ramadanCalendarDays.removeAll()
        
        // Clear today hours
        let today = Calendar.current.startOfDay(for: Date())
        
        var ramadanIndex = 0
        
        // Check that first month start index is in range.
        if Values.firstMonthStartIndex < self.firstMonthCalendarDays.count {
            
            for firstMonthIndex in Values.firstMonthStartIndex ..< self.firstMonthCalendarDays.count {
                
                // Add first month date
                if let date = self.firstMonthCalendarDays[firstMonthIndex].date {
                    ramadanIndex = ramadanIndex + 1
                    
                    if today == date {
                        
                        // Check if dat is today
                        self.todayCalendarDay = self.firstMonthCalendarDays[firstMonthIndex]
                        self.calendarReminderDays.append(self.firstMonthCalendarDays[firstMonthIndex])
                    } else if date > today {
                        self.calendarReminderDays.append(self.firstMonthCalendarDays[firstMonthIndex])
                    }
                    
                    // Add date to list
                    self.ramadanCalendarDays.append(self.firstMonthCalendarDays[firstMonthIndex])
                    
                    if ramadanIndex == Values.ramadanDaysNumber {
                        return
                    }
                }
            }
            
            // Check second month is in range
            if Values.secondMonthLastIndex < self.secondMonthCalendarDays.count {
                for secondMonthIndex in 0 ... Values.secondMonthLastIndex {
                    
                    // Add first month date
                    if let date = self.firstMonthCalendarDays[secondMonthIndex].date {
                        ramadanIndex = ramadanIndex + 1
                        
                        // Check if dat is today
                        
                        if today == date {
                            self.todayCalendarDay = self.secondMonthCalendarDays[secondMonthIndex]
                            self.calendarReminderDays.append(self.secondMonthCalendarDays[secondMonthIndex])
                        } else if date > today {
                            self.calendarReminderDays.append(self.secondMonthCalendarDays[secondMonthIndex])
                        }
                        
                        // Add date to list
                        self.ramadanCalendarDays.append(self.secondMonthCalendarDays[secondMonthIndex])
                        if ramadanIndex == Values.ramadanDaysNumber {
                            return
                        }
                    }
                }
            }
        }
    }
}
// MARK: - model
extension LandingViewController {
    
    /**
     Request Data
     */
    private func requestData() {
        
        if !self.isDataLoading {
        
        // Check autorization status
        switch CLLocationManager.authorizationStatus() {
            
            // Authorised
        case .authorizedAlways, .authorizedWhenInUse:
            break
            
            // Not authorised request
        case .notDetermined, .restricted:
            self.locManager.requestWhenInUseAuthorization()
            
            // Not authorised
        case .denied:
            self.showFailureView(type: FailureType.locationDenied)
            self.showLocationAlert()
            return
        }
        
        // Get current location coordinats
        let latitude: Double = locManager.location?.coordinate.latitude ?? 32.22111
        let longitude: Double = locManager.location?.coordinate.longitude ?? 35.25444
        
        // Year
        let year = Calendar.current.component(Calendar.Component.year, from: Date())
        
        // Get months days
        // May
        self.requestStatusList[RequestType.firstMonth] = RequestStatus.loading
        self.getFirstMonthCalendarDays(year: year.description, month: "05", location: (latitude: latitude, longitude: longitude))
        
        // June
        self.requestStatusList[RequestType.secondMonth] = RequestStatus.loading
            self.getSecondMonthCalendarDays(year: year.description, month: "06", location: (latitude: latitude, longitude: longitude))
        }
    }
    
    /**
     Get first month calendar days
     */
    private func getFirstMonthCalendarDays(year: String, month: String, location: (latitude: Double, longitude: Double)) {
        
        PrayerModel.getMonthPrayerCalendarDays(date: (year: year.description, month: month), location: (latitude: location.latitude, longitude: location.longitude), completion: { [weak self] days, error  in
            guard let strongSelf = self else {return}
            
            if let error = error {
                strongSelf.failedToGetFirstMonthCalendarDays(error: error)
            } else if let days = days {
                strongSelf.didGetFirstMonthCalendarDays(days: days)
            }
        })
    }
    
    /**
     Did Get first month calendar days
     - Parameter days: calendar days of first month
     */
    private func didGetFirstMonthCalendarDays(days: [CalendarDay]) {
        self.requestStatusList[RequestType.firstMonth] = RequestStatus.success
        
        // Set data
        self.firstMonthCalendarDays = days
        
        // Build data
        self.buildData()
        
        // Navigate
        if !self.isDataLoading {
            self.performSegue(withIdentifier: "ShowMainViewController", sender: self)
            return
        }
    }
    
    /**
     Failed to get first month calendar days
     - Parameter error: error causing failure
     */
    private func failedToGetFirstMonthCalendarDays(error: Error) {
        self.requestStatusList[RequestType.firstMonth] = RequestStatus.failed
        
        // Show failure view
        if !self.isDataLoading {
            self.showFailureView(type: FailureType.requestFailure)
        }
    }
    
    /**
     Get second month calendar days
     */
    private func getSecondMonthCalendarDays(year: String, month: String, location: (latitude: Double, longitude: Double)) {
        PrayerModel.getMonthPrayerCalendarDays(date: (year: year.description, month: month), location: (latitude: location.latitude, longitude: location.longitude), completion: { [weak self] days, error  in
            guard let strongSelf = self else {return}
            
            if let error = error {
                strongSelf.failedToGetSecondMonthCalendarDays(error: error)
            } else if let days = days {
                strongSelf.didGetSecondMonthCalendarDays(days: days)
            }
        })
    }
    
    /**
     Did Get first month calendar days
     - Parameter days: calendar days of first month
     */
    private func didGetSecondMonthCalendarDays(days: [CalendarDay]) {
        self.requestStatusList[RequestType.secondMonth] = RequestStatus.success
        
        // Set data
        self.secondMonthCalendarDays = days
        
        // Build data
        self.buildData()
        
        // Navigate
        if !self.isDataLoading {
            self.performSegue(withIdentifier: "ShowMainViewController", sender: self)
            return
        }
    }
    
    /**
     Failed to get first month calendar days
     - Parameter error: error causing failure
     */
    private func failedToGetSecondMonthCalendarDays(error: Error) {
        self.requestStatusList[RequestType.secondMonth] = RequestStatus.failed
        
        // Show failure view
        if !self.isDataLoading {
            self.showFailureView(type: FailureType.requestFailure)
        }
    }
}

// MARK: - Navigation
extension LandingViewController {
    
    /**
     Prepare for segue
     */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "ShowMainViewController", let mainNavigationViewController = segue.destination as? UINavigationController, let mainViewController = mainNavigationViewController.viewControllers.first as? MainViewController {
            
            // Set main view controller parameters
            mainViewController.calendarReminderDays = self.calendarReminderDays
            mainViewController.ramadanCalendarDays = self.ramadanCalendarDays
            mainViewController.todayCalendarDay = self.todayCalendarDay
        }
    }
}

// MARK: - CLLocationManagerDelegate, methods for location manager
extension LandingViewController: CLLocationManagerDelegate {
    
    // Alert
    
    /**
     Show alert
     */
    private func showLocationAlert() {
        
        // Create alert
        let alert = UIAlertController(title: "تفعيل الموقع", message: "يرجى تفعيل الاعدادات للاستمرار", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "الاعدادات", style: UIAlertAction.Style.default, handler: { (alert: UIAlertAction!) in
            
            self.goToLocationSettings()
        }))
        
        // Show alert
        self.present(alert, animated: true)
    }
    
    // Navigation
    
    /**
     Go to location settings
     */
    @objc private func goToLocationSettings() {
        
        // present an alert advising the user that they need to go to the settings menu to enable the permissions as they have previously denied it.
        // if the user presses Open Settings on the alert....
        if let url = URL(string: UIApplication.openSettingsURLString) {
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
    
    // CLLocationManagerDelegate
    
    /**
     Did change authorization
     */
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        
        switch status {
            
        // He accepted authorization
        case .authorizedAlways, .authorizedWhenInUse:
            
            // Get ramadan calendar days
            self.requestData()
            break
            
        case .notDetermined, .restricted:
            self.locManager.requestWhenInUseAuthorization()
                
        // Authorization not accepted
        case .denied:
            self.showFailureView(type: FailureType.locationDenied)
            self.showLocationAlert()
            return
        }
    }
}

// MARK: - Failure view
extension LandingViewController {
    
    /**
     Show failure view
     - Parameter type: type causeing failure
     */
    private func showFailureView(type: FailureType) {
        
        var failureMessage: String = ""
        var buttonTitle: String = ""
        self.failureButton.removeTarget(self, action: #selector(self.tryAgain), for: UIControl.Event.touchUpInside)
        self.failureButton.removeTarget(self, action: #selector(self.goToLocationSettings), for: UIControl.Event.touchUpInside)
        
        switch type {
        case .locationDenied:
            failureMessage = "يرجى تفعيل الاعدادات للاستمرار"
            buttonTitle = "الاعدادات"
            self.failureButton.addTarget(self, action: #selector(self.goToLocationSettings), for: UIControl.Event.touchUpInside)
        case .requestFailure:
            failureMessage = "حصل خطأ, اعاده محاوله"
            buttonTitle = "اعاده محاوله"
            self.failureButton.addTarget(self, action: #selector(self.tryAgain), for: UIControl.Event.touchUpInside)
        }
        
        // Set text
        self.failureLabel.text = failureMessage
        self.failureButton.setTitle(buttonTitle, for: UIControl.State.normal)
        
        self.showFailureView(show: true)
        self.showLoadingView(show: false)
    }
    
    /**
     Try again
     */
    @objc private func tryAgain() {
        self.requestData()
        self.showLoadingView(show: true)
        self.showFailureView(show: false)
    }
}
