//
//  UserDefaultsUtils.swift
//  Ramadan
//
//  Created by Fratello Software Group on 3/24/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import Foundation

/// User defaults utils
class UserDefaultssUtils {
    
    /// User defaults
    static private var userDefaults: UserDefaults = UserDefaults.standard
    
    /**
     Set object value
     - Parameter value: value to be set
     - Parameter forKey: key to set and retrive value.
     */
    class func setObjectValue(_ value: Any!, forKey key: String!) {
        if let value = value, let key = key {
            userDefaults.set(value, forKey: key)
            UserDefaults.standard.synchronize()
        }
    }
    
    /**
     Get object value for key
     */
    class func getObjectValueForKey(_ key: String!) -> Any! {
        
        if let key = key, let value = userDefaults.value(forKey: key) {
            return value
        }
        return nil
    }
    
    /**
     Remove value
     - Parameter key: key to retrive value.
     */
    public class func removeValue(_ key: String) {
        userDefaults.removeObject(forKey: key)
        UserDefaults.standard.synchronize()
    }
}
