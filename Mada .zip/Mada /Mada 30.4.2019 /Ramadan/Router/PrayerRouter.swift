//
//  PrayerRouter.swift
//  Ramadan
//
//  Created by Fratello Software Group on 3/14/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import Foundation
import Alamofire

/// Prayer router
enum PrayerRouter: URLRequestConvertible {
    
    /// Get month prayer time
    case getMonthPrayerTime(parameters: Parameters)
    
    /// Method
    var method: HTTPMethod {
        switch self {
        case .getMonthPrayerTime:
            return .get
        }
    }
    
    // Base url string
    var baseURLString: String {
        switch self {
        case .getMonthPrayerTime:
            return "https://api.aladhan.com/v1/calendar"
        }
    }
    
    /**
     Return url request
     */
    func asURLRequest() throws -> URLRequest {
        let url = try self.baseURLString.asURL()
        var urlRequest = URLRequest(url: url)
        
        switch self {
            
        case .getMonthPrayerTime(let parameters):
            urlRequest = try URLEncoding.default.encode(urlRequest, with: parameters)
        }
        
        urlRequest.httpMethod = method.rawValue
        return urlRequest
    }
}
