//
//  CellData.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Cell data
protocol CellData {
    
    /// cell identifier
    var cellIdentifier: String {get set}
    
    // Cell heigth
    var cellHeight: CGFloat {get set}
}
