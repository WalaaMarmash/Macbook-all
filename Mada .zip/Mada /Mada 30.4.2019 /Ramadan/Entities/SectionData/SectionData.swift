//
//  SectionData.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Section data
protocol SectionData {
    
    /// Section height
    var sectionHeight: CGFloat {get set}
    
    /// Section identifier
    var sectionIdentifier: String {get set}
    
    /// Is expanded
    var isExpanded: Bool {get set}
    
    /// Is Expandable
    var isExpandable: Bool {get set}
    
    /// Cells data
    var cellsData: [CellData] {get set}
}
