//
//  RequestStatus.swift
//  Ramadan
//
//  Created by Fratello Software Group on 3/15/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import Foundation

/// Request Status
enum RequestStatus {
    case loading
    case failed
    case success
}
