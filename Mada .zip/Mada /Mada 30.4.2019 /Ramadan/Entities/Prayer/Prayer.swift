//
//  Prayer.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import Foundation

/// Prayer type
enum PrayerType: String, Codable, Equatable {
    case fajer    = "Fajr"
    case sunRise  = "Sunrise"
    case dohor    = "Dhuhr"
    case aser     = "Asr"
    case maghreb  = "Maghrib"
    case ishaa    = "Isha"
    
    /**
     Get title
     - Returns: String representing salah name
     */
    func getTitle() -> String {
        switch self {
        case .fajer:
            return "الفجر"
        case .sunRise:
            return "الشمس"
        case .dohor:
            return "الظهر"
        case .aser:
            return "العصر"
        case .maghreb:
            return "المغرب"
        case .ishaa:
            return "العشاء"
        }
    }
    
    /**
     Get prayer image name
     - Returns: name represeinting image name
     */
    func getPrayerImageName() -> String {
        switch self {
        case .fajer:
            return "fajer"
        case .sunRise:
            return "sunRise"
        case .dohor:
            return "dohor"
        case .aser:
            return "aser"
        case .maghreb:
            return "maghreb"
        case .ishaa:
            return "ishaa"
        }
    }
    
    static func == (lhs: PrayerType, rhs: PrayerType) -> Bool {
        return lhs.rawValue == rhs.rawValue
    }
}

/// Prayer
struct Prayer: Codable {
    
    /// Type
    var type: PrayerType
    
    /// Date time
    var dateTime: Date?
    
    
    /**
     Initilizer
     */
    init() {
        self.type = PrayerType.fajer
        self.dateTime = Date()
    }
    
    /**
     Initilizer
     */
    init(type: PrayerType, dateTime: Date?) {
        self.init()
        
        // Set values
        self.type = type
        self.dateTime = dateTime
    }
    
    /**
     Get prayer time string
     - Returns: string representing time string
     */
    func getPrayerTimeString() -> String {
        
        if let date = self.dateTime {
            // Formatter
            let formatter = DateFormatter()
            formatter.dateFormat = "h:mm"
            
            // Get todays date formatted
            return formatter.string(from: date)
        }
        
        return ""
    }
}
