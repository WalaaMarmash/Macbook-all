//
//  CalendarDay.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/12/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import Foundation

/// Calendar day json tags
private enum CalendarDayJsonTags: String {
    case timings   = "timings"
    case hijri     = "hijri"
    case date      = "date"
    case gregorian = "gregorian"
    case format    = "format"
    case day       = "day"
    case readable  = "readable"
}

/// Calendar Day
struct CalendarDay: Codable {
    
    /// Date
    var date: Date? = Date()
    
    /// Prayers
    var prayers: [Prayer]
    
    /// Is set
    var isSet: Bool
    
    /// Ramdan day number
    var ramadanDayNumber: Int
    
    /**
     Initilizer
     */
    init() {
        self.date = nil
        self.prayers = []
        self.isSet = false
        self.ramadanDayNumber = 0
    }
    
    /**
     Initilizer
     */
    init(dictionary: NSDictionary) {
        self.init()
        
        // Set date and prayer times
        if let dateDictionary = dictionary.value(forKey: CalendarDayJsonTags.date.rawValue) as? NSDictionary, let dateString = dateDictionary.value(forKey: CalendarDayJsonTags.readable.rawValue) as? String, let timeList = dictionary.value(forKey: CalendarDayJsonTags.timings.rawValue) as? NSDictionary {
            
            // Get date
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd MM yyyy"
            dateFormatter.timeZone = NSTimeZone.local
            dateFormatter.locale = Locale(identifier: "en_US_POSIX")
            self.date = dateFormatter.date(from: dateString)
            
            for key in timeList.allKeys {
                if let keyString = key as? String,let prayerType = PrayerType(rawValue: keyString), let prayerTime = timeList[key] as? String {
                    let first4 = String(prayerTime.prefix(5))

                    // Prayer time
                    let fullPrayerTiem = dateString + " " + first4
                    let dateFormatterr = DateFormatter()
                    dateFormatterr.timeZone = TimeZone.current
                    dateFormatterr.locale = Locale(identifier: "en_US_POSIX")
                    dateFormatterr.dateFormat = "dd MM yyyy" + " " + "HH:mm"
                    let timeDate = dateFormatterr.date(from: fullPrayerTiem)
                    
                    // Add prayer
                    let prayer = Prayer(type: prayerType, dateTime: timeDate)
                    self.prayers.append(prayer)
                }
            }
            
            // set ramadan index day
            if let hijri = dateDictionary.value(forKey: CalendarDayJsonTags.hijri.rawValue) as? NSDictionary, let day = hijri.value(forKey: CalendarDayJsonTags.day.rawValue) as? String, let index = Int(day) {
                self.ramadanDayNumber = index
            }
        }
    }
    
    /**
     Get week day
     */
    func getWeekDay() -> WeekDay {
        
        // Create date time formatter
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE"
        
        // Create week day
        let weekdayString = dateFormatter.string(from: self.date!)
        
        if let weekDay = WeekDay(rawValue: weekdayString) {
            return weekDay
        }
        return WeekDay.saturday
    }
}
