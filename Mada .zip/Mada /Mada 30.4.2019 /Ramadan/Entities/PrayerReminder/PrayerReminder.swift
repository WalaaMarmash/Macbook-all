//
//  Reminder.swift
//  Ramadan
//
//  Created by Yara Abuhijleh on 3/11/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import UIKit

/// Prayer reminder before time
enum PrayerReminderBeforeTime: Int, Codable {
    case onTime          = 0
    case before10Mins    = 10
    case before20Mins    = 20
    case before30Mins    = 30
    case before40Mins    = 40
    
    /**
     Get title
     - Returns: String representing title of reminder before time
     */
    func getTitle() -> String {
        switch self {
        case .onTime:
            return "وقت الاذان"
        default:
            return "\(self.rawValue) قبل الاذان"
        }
    }
}

/// Views tags
enum WeekDay: String, Codable {
    case saturday  = "Saturday"
    case sunday    = "Sunday"
    case monday    = "Monday"
    case tuesday   = "Tuesday"
    case wedensday = "Wednesday"
    case thursday  = "Thursday"
    case friday    = "Friday"
    
    /**
     Get Day title
     - Returns: String representing title of day
     */
    func getTitle() -> String {
        switch self {
            
        case .saturday:
            return "السبت"
        case .sunday:
            return "الاحد"
        case .monday:
            return "الاثنين"
        case .tuesday:
            return "الثلاثاء"
        case .wedensday:
            return "الاربعاء"
        case .thursday:
            return "الخميس"
        case .friday:
            return "الجمعه"
        }
    }
}

/// Prayer Reminder
struct PrayerReminder: Codable {
    
    /// Prayer type
    var prayer: Prayer
    
    /// reminderVolume
    var reminderVolume: Float
    
    /// Reminder days
    var reminderDaysMap: [WeekDay: [PrayerReminderDay]]
    
    /// Reminder before time
    var reminderBeforeTime: PrayerReminderBeforeTime
    
    /// is Reminder Set
    var isReminderSet: Bool
    
    /**
     Initilizer
     */
    init() {
        self.prayer = Prayer()
        self.reminderVolume = 50
        self.reminderBeforeTime = PrayerReminderBeforeTime.onTime
        self.reminderDaysMap = [:]
        self.isReminderSet = false
    }
    
    /**
     Initilizer
     - Parameter prayer: prayer
     - Parameter reminderVolume: Reminder volume
     - Parameter reminderDays: Reminder days
     - Parameter reminderBeforeTime: reminder before time
     - Parameter isReminderSet: is reminder set
     */
    init(prayer: Prayer, reminderVolume: Float, days: [CalendarDay], reminderBeforeTime: PrayerReminderBeforeTime, isReminderSet: Bool) {
        self.init()
        
        // Set values
        self.prayer = prayer
        self.reminderVolume = reminderVolume
        self.reminderBeforeTime = reminderBeforeTime
        self.isReminderSet = isReminderSet
        self.reminderDaysMap = self.buildDaysMap(calendarDays: days)
    }
    
    /**
     Build days map
     - Parameter calendarDays: calendar days list
     - Returns: map of week days as keys, and reminder days as values.
     */
    private func buildDaysMap(calendarDays: [CalendarDay]) -> [WeekDay: [PrayerReminderDay]] {
        
        // Map
        var map: [WeekDay: [PrayerReminderDay]] = [WeekDay.saturday: [], WeekDay.sunday: [], WeekDay.monday: [], WeekDay.tuesday: [], WeekDay.wedensday: [], WeekDay.thursday: [], WeekDay.friday: []]
        
        for day in calendarDays {
                
                // Make sure date is set
            if let prayer = day.prayers.filter({$0.type == self.prayer.type}).first, let prayerDate = prayer.dateTime {
                    
                    // Get week day
                    let weekDay = day.getWeekDay()
                    
                    // Create reminder day object
                    let prayerReminderDay = PrayerReminderDay(date: prayerDate, isSet: false)
                    
                    // Add day to its week day array
                    var values = map[weekDay] ?? []
                    values.append(prayerReminderDay)
                    map.updateValue(values, forKey: weekDay)
                }
        }
        return map
    }
    
    /**
     set is set
     - Parameter isSet: Boolean to indicate if reminder is set
     */
    mutating func setIsSet(isSet: Bool) {
        self.isReminderSet = isSet
    }
    
    /**
     Set week day is set
     - Parameter isSet: Bool
     - Parameter weekDay: week day to set its is set values
     */
    mutating func toggleIsSet(for weekDay: WeekDay) {
        var newDays: [PrayerReminderDay] = []
        
        // Update is Set value
        for var day in self.reminderDaysMap[weekDay] ?? [] {
            day.toggleIsSet()
            newDays.append(day)
        }
        self.reminderDaysMap.updateValue(newDays, forKey: weekDay)
    }
    
    /**
     Set volume
     - Parameter volume: Float
     */
    mutating func setVoulme(volume: Float) {
        self.reminderVolume = volume
    }
    
    /**
     Set reminder before time
     - Parameter volume: Float
     */
    mutating func setReminderBeforetime(beforeTime: PrayerReminderBeforeTime) {
        self.reminderBeforeTime = beforeTime
    }
}
