//
//  PrayerReminderDay.swift
//  Ramadan
//
//  Created by Fratello Software Group on 3/13/19.
//  Copyright © 2019 Yara Abuhijleh. All rights reserved.
//

import Foundation

/// Prayer reminder day
struct PrayerReminderDay: Codable {
    
    /// Date
    var date: Date?
    
    /// Event store id
    var eventStoreID: String
    
    /// is Set
    var isSet: Bool
    
    /**
     initilizer
     */
    init() {
        self.date = nil
        self.isSet = false
        self.eventStoreID = ""
    }
    
    /**
     initilizer
     - Parameter date: Date
     - Parameter isSet: Boolean to indicate if day is set for reminder.
     */
    init(date: Date?, isSet: Bool) {
        self.init()
        self.date = date
        self.isSet = isSet
    }
    
    /**
     Set Event store id
     */
    mutating func setEventStoreID(id: String) {
        self.eventStoreID = id
    }
    
    /**
     Toggle is set
     */
    mutating func toggleIsSet() {
       self.isSet = !self.isSet
    }
}
