//
//  DeliverWayViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 5/23/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import Kingfisher

class DeliverWayViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate, UITextViewDelegate{
    
    
    
    @IBOutlet weak var selectedImage: UIImageView!
    @IBOutlet weak var detailTextField: UITextView!
    @IBOutlet var uiLable: [UILabel]!
    @IBOutlet var uiStack: [UIStackView]!
    @IBOutlet weak var dateTextField: CustomTextField!
    @IBOutlet weak var dateView: CustomPopupView!
    @IBOutlet weak var dateTypeTextField: CustomTextField!
    @IBOutlet weak var dateTypePickerView: UIPickerView!
    let lenghtUnit = ["cm","mm","m"]
    let wegithUnit = ["Kg","Gm"]
    let dateType = ["في تاريخ محدد","التاريخ الحالي"]
    static var selectedCarImage: Int! = 0
    static var DeliverWayID: Int!
    @IBOutlet weak var lenghtUnitPickerView: CustomPickerView!
    @IBOutlet weak var wegithUnitPickerView: CustomPickerView!
    @IBOutlet weak var lenghtUnitTextField: CustomTextField!
    @IBOutlet weak var wegithUnitTextField: CustomTextField!
    @IBOutlet weak var lenghtTextFeild: CustomTextField!
    @IBOutlet weak var weidthTextField: CustomTextField!
    @IBOutlet weak var heightTextField: CustomTextField!
    @IBOutlet weak var wegithTextField: CustomTextField!
    @IBOutlet weak var bottomSpace: NSLayoutConstraint!
    @IBOutlet weak var saveBtn: UIBarButtonItem!
    
    @IBOutlet weak var productCost: CustomTextField!
    
    @IBOutlet weak var datePickerView: UIDatePicker!
    
    
    @IBOutlet weak var foodLoadtype: UIImageView!
    @IBOutlet weak var smalLoadeType: UIImageView!
    @IBOutlet weak var bigLoadType: UIImageView!
    
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        saveBtn.setTitleTextAttributes([NSAttributedStringKey.font: UIFont(name: "beIN-Arabicblack", size: 20)!], for: .normal)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
       // SetUpOriantation()
        self.datePickerView.locale = Locale(identifier: "en_GB")
        // CreateDeliveryParamArray()
        
        self.detailTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
        self.detailTextField.layer.borderWidth = 1
        self.detailTextField.layer.cornerRadius = 10
       // bottomSpace.constant = 20
        ClearData()
        
        
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(foodLoadtypeimageTapped(tapGestureRecognizer:)))
        foodLoadtype.isUserInteractionEnabled = true
        foodLoadtype.addGestureRecognizer(tapGestureRecognizer)
        
        
        let tapGestureRecognizer1 = UITapGestureRecognizer(target: self, action: #selector(smalLoadeTypeimageTapped(tapGestureRecognizer:)))
        smalLoadeType.isUserInteractionEnabled = true
        smalLoadeType.addGestureRecognizer(tapGestureRecognizer1)
        
        
        let tapGestureRecognizer2 = UITapGestureRecognizer(target: self, action: #selector(bigLoadTypeimageTapped(tapGestureRecognizer:)))
        bigLoadType.isUserInteractionEnabled = true
        bigLoadType.addGestureRecognizer(tapGestureRecognizer2)
    }
    
    
    @objc func foodLoadtypeimageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        let tappedImage = tapGestureRecognizer.view as! UIImageView
        if tappedImage.image != UIImage(named: "To Go - September-41"){
             tappedImage.image = UIImage(named: "To Go - September-41")
        }else{
            tappedImage.image = UIImage(named: "To Go - September-40")
        }
       
        smalLoadeType.image = UIImage(named: "To Go - September-36")
        bigLoadType.image = UIImage(named: "To Go - September-37")
        // Your action
    }
    
    @objc func smalLoadeTypeimageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        let tappedImage = tapGestureRecognizer.view as! UIImageView
        if tappedImage.image != UIImage(named: "To Go - September-40"){
            tappedImage.image = UIImage(named: "To Go - September-40")
        }else{
             tappedImage.image = UIImage(named: "To Go - September-36")
        }
       
        foodLoadtype.image = UIImage(named: "To Go - September-40")
        bigLoadType.image = UIImage(named: "To Go - September-37")
        // Your action
    }
    
    @objc func bigLoadTypeimageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        let tappedImage = tapGestureRecognizer.view as! UIImageView
        if tappedImage.image != UIImage(named: "To Go - September-39"){
            tappedImage.image = UIImage(named: "To Go - September-39")
        }else{
             tappedImage.image = UIImage(named: "To Go - September-39")
        }
       
        foodLoadtype.image = UIImage(named: "To Go - September-38")
        smalLoadeType.image = UIImage(named: "To Go - September-36")
        // Your action
    }
    
    override func viewDidAppear(_ animated: Bool) {
        setSelectedImagePhoto()
        
    }
    
    func setSelectedImagePhoto()  {
        
        print(image_URL + DeliverDetailViewController._carPhotos[DeliverWayViewController.selectedCarImage].PhotoUrl!)
        selectedImage.kf.setImage(with: URL(string:image_URL + DeliverDetailViewController._carPhotos[DeliverWayViewController.selectedCarImage].PhotoUrl!))
        
    }
    
    
    func ClearData()  {
        ReciverAddressViewController.SenderAdress["lat"] = ""
        ReciverAddressViewController.SenderAdress["long"] = ""
        ReciverAddressViewController.ReciverAdress["lat"] = ""
        ReciverAddressViewController.ReciverAdress["long"] = ""
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == dateTypePickerView{
            return 2
        }else if pickerView == lenghtUnitPickerView{
            return lenghtUnit.count
        }else{
            return wegithUnit.count
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        self.view.endEditing(true)
        if pickerView == dateTypePickerView{
            return dateType[row]
        }
        else if pickerView == lenghtUnitPickerView{
            return  lenghtUnit[row]
        }else{
            return  wegithUnit[row]
        }
        
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if pickerView == dateTypePickerView{
            self.dateTypeTextField.text = dateType[row]
            
            if dateTypeTextField.text == "التاريخ الحالي"{
                self.dateView.isHidden = true
                dateTextField.text = GetCurrentDate()
            }else{
                dateTextField.text = ""
            }
            dateTypePickerView.isHidden = true
            
        }
            
        else if pickerView == lenghtUnitPickerView{
            lenghtUnitTextField.text = lenghtUnit[row]
            lenghtUnitPickerView.isHidden = true
            
        }else{
            wegithUnitTextField.text = wegithUnit[row]
            wegithUnitPickerView.isHidden = true
        }
        
    }
    
    ////////////// PickerView///////////////
    
    //textField//
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == dateTypeTextField{
            dateTypePickerView.isHidden = false
           // bottomSpace.constant = 250
            self.view.endEditing(true)
        }
        
        if textField == dateTextField{
            self.view.endEditing(true)
            if dateTypeTextField.text == "في تاريخ محدد"{
                dateView.isHidden = false
                
            }else{
                self.view.endEditing(true)
                
            }
            
        }
        
        if textField == lenghtUnitTextField {
            lenghtUnitPickerView.isHidden  = false
            self.view.endEditing(true)
        }
        if textField == wegithUnitTextField {
            wegithUnitPickerView.isHidden = false
            self.view.endEditing(true)
        }
        
    }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    // handel return key for textField
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    //    //textField//
    
    
    @IBAction func doneDateView(_ sender: Any) {
        dateView.isHidden = true
       //bottomSpace.constant = 20
        dateTextField.resignFirstResponder()
    }
    
    func GetCurrentDate() -> String {
        
        let date = Date()
        let formatter = DateFormatter()
        
        
        formatter.locale = Locale(identifier: "en_GB")
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        let result = formatter.string(from: date)
        print(result)
        
        return result
        // print(String(result.dropLast().replacingOccurrences(of: " ", with: "")))
        // return (String(result).replacingOccurrences(of: ",", with: "T")).replacingOccurrences(of: " ", with: "")
        //let date1 = "2012-02-21T18:10:00"
        //return date1
    }
    
    @IBAction func datePickerChanged(_ sender: UIDatePicker) {
        
        ////        let dateFormatter = DateFormatter()
        ////        dateFormatter.dateFormat = "MM-dd-yyyy"
        ////        dateFormatter.timeStyle = DateFormatter.Style.short
        //        dateTextField.text =  dateFormatter.string(from: sender.date)
        
        let dateFormatter = DateFormatter()
        
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
        
        let strDate = dateFormatter.string(from: sender.date)
        print(strDate)
        dateTextField.text = strDate
        print(dateTextField.text!)
        
        //        let strDate = dateFormatter.string(from: sender.date)
        //        let dataSting: String = String(strDate.dropLast().dropLast())
        //        dateTextField.text = dataSting
        //        print(dateTextField.text!)
    }
    
    
    
    @IBAction func saveBtnPressed(_ sender: Any) {
        
        SaveOdrerData()
    }
    
    
    func SaveOdrerData()  {
        
        
        
        if detailTextField.text == "" || lenghtTextFeild.text == "" || wegithTextField.text == "" || heightTextField.text == "" || weidthTextField.text == "" || dateTextField.text == "" {
            
            let alert = UIAlertController(title: "", message: "الرجاء ادخال جميع البيانات", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
            self.present(alert, animated: true)
            
        }else{
            
            ReciverAddressViewController.LoadDetails["detail"] = detailTextField.text
            ReciverAddressViewController.LoadDetails["lenght"] = detailTextField.text
            ReciverAddressViewController.LoadDetails["wegith"] = detailTextField.text
            ReciverAddressViewController.LoadDetails["height"] = detailTextField.text
            ReciverAddressViewController.LoadDetails["weidth"] = detailTextField.text
            ReciverAddressViewController.LoadDetails["date"] = dateTextField.text
            // 21D33F14-A932-4220-A3FF-89A52EA21050
            
            ReciverAddressViewController.LoadDetails["SelectedCarID"] = DeliverDetailViewController._carPhotos[DeliverWayViewController.selectedCarImage].vehicleId!
            
            CreateDeliveryParamArray()
            ReciverAddressViewController.LoadDetailsFlage = true
            let alert = UIAlertController(title: "", message: "تم حفظ البيانات بنجاح", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
            self.present(alert, animated: true)
            
        }
        
    }
    
    
    func CreateDeliveryParamArray()  {
        
        
        let dict = ["Idvehicle":  ReciverAddressViewController.LoadDetails["SelectedCarID"]!, "deliveryWay": "\(DeliverWayViewController.DeliverWayID!)", "DetailsLoad": ReciverAddressViewController.LoadDetails["detail"]!, "LengthLoad": ReciverAddressViewController.LoadDetails["lenght"]!,"WidthLoad": ReciverAddressViewController.LoadDetails["weidth"]!, "HeightLoad":   ReciverAddressViewController.LoadDetails["height"]!,"WeightLoad": ReciverAddressViewController.LoadDetails["wegith"]!,"DateLoad": dateTextField.text!] as [String : Any]
        
        
        var _ : NSError?
        
        let jsonData = try! JSONSerialization.data(withJSONObject: dict, options: JSONSerialization.WritingOptions.prettyPrinted)
        let jsonString = NSString(data: jsonData, encoding: String.Encoding.utf8.rawValue)! as String
        
        print(jsonString.replacingOccurrences(of: "\\", with: ""))
        
        
        let DeliveryParamJson = "{\"DeliveryParam\": [\(jsonString.replacingOccurrences(of: "\\", with: ""))]\r\n}"
        print(DeliveryParamJson)
        ClientLoader.jsonDeliveryParam = DeliveryParamJson
    }
    
    @IBAction func backBtnPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    func SetUpOriantation()  {
        let lang = UserDefaults.standard.string(forKey: "lang")
        if lang == "ar"{
            for item in uiLable{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
            
            for item in uiStack{
                item.semanticContentAttribute = .forceLeftToRight
                
            }
            
        }else{
            for item in uiLable{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
            
            for item in uiStack{
                item.semanticContentAttribute = .forceRightToLeft
                
            }
        }
        
        
    }
    
}
