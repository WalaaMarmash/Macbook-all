//
//  OrderOfferModel.swift
//  TOGOClient
//
//  Created by Fratello Software Group on 9/20/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation
import ObjectMapper
import UIKit

class OrderOfferModel: Mappable {
    
    
    var IdTransporterBidRequist: String?
    var BidCost: String?
    var TransporterName: String?
    
    
    init() {
        
    }
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        
        IdTransporterBidRequist <- map["IdTransporterBidRequist"]
        BidCost <- map["BidCost"]
        TransporterName <- map["TransporterName"]
        
        
    }
}


class OrderDetailModel: Mappable {
    
    
    var idOrder: String?
    var DateOrder: String?
    var DeliveryWay: String?
    
    
    init() {
        
    }
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        
        idOrder <- map["idOrder"]
        DateOrder <- map["DateOrder"]
        DeliveryWay <- map["DeliveryWay"]
        
        
    }
}

import Foundation
import ObjectMapper

class OrderOfferModelResult: Mappable {
    
    var ordersOfferResult: [OrderOfferModel]?
     var OrderDetailResult: [OrderDetailModel]?
    
    required init?(map: Map) {}
    
    func mapping(map: Map){
        ordersOfferResult <- map["CostDetail"]
        OrderDetailResult <- map["OrderDetail"]
    }
    
}
