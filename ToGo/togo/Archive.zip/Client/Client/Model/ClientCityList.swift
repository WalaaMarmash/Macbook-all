//
//  ClientCityList.swift
//  ToGo
//
//  Created by Fratello Software Group on 8/14/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation
import ObjectMapper
import UIKit

class ClientCityList: Mappable {
    
    var IdCity: String?
    var LatRegion: String?
    var LongRegion: String?
    var Name: String?
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        IdCity <- map["IdCity"]
        LatRegion <- map["LatRegion"]
        Name <- map["Name"]
        LongRegion <- map["LongRegion"]
    }
}
