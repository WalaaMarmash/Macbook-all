//
//  GetIdPlaceModel.swift
//  ToGo
//
//  Created by Fratello Software Group on 7/22/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation
import ObjectMapper
import UIKit

class idPlaceModel: Mappable {
    
    
    var IdPlace: String?
    var NamePlace: String?
    
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        IdPlace <- map["IdPlace"]
        NamePlace <- map["NamePlace"]
        
    }
}
