//
//  CurrentOrderTrackingModel.swift
//  TOGOClient
//
//  Created by Fratello Software Group on 10/14/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation
import ObjectMapper
import UIKit

class CurrentOrderTrackingModel: Mappable {
    
    
    var TransporterLatLocation: String?
    var TransporterLongLoc: String?
    var Orderfinished: String?
    var IsDeleted: String?
    
    init() {
        
    }
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        
        TransporterLatLocation <- map["TransporterLatLocation"]
        TransporterLongLoc <- map["TransporterLongLoc"]
        Orderfinished <- map["Orderfinished"]
        IsDeleted <- map["IsDeleted"]
        
    }
}


import Foundation
import ObjectMapper

class CurrentOrderTrackingResult: NSObject, Mappable {
    
    var currentOrderTrackingResult: [CurrentOrderTrackingModel]?
    
    required init?(map: Map) {}
    
    func mapping(map: Map){
        currentOrderTrackingResult <- map["server_response"]
    }
    
}
