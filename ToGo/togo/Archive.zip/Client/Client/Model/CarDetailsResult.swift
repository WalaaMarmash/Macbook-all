//
//  CarColorResult.swift
//  ToGo
//
//  Created by Fratello Software Group on 7/24/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation
import ObjectMapper


class CarDetailsResult: Mappable {
    
    var Color: [CarColorModel]?
    var Photos: [CarPhotos]?
    
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map){
        Color <- map["Color"]
        Photos <- map["Photos"]
    }
    
}
