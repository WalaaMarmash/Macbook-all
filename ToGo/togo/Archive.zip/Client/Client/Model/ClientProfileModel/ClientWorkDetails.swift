//
//  ClientWorkDetails.swift
//  Client
//
//  Created by Fratello Software Group on 11/29/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation
import UIKit
import ObjectMapper

class ClientWorkDetailsResult: Mappable {
    
    var WorkDetailsResult: [ClientWorkDetailsModel]?
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map){
        WorkDetailsResult <- map["server_response"]
    }
    
}


class ClientWorkDetailsModel: Mappable {
    
    
    var BusinessName: String?
    var BusinessTypeId: String?
    var BusinessPlace: String?
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        BusinessName <- map["BusinessName"]
        BusinessTypeId <- map["BusinessTypeId"]
        BusinessPlace <- map["BusinessPlace"]
        
    }
}
