//
//  ClientPersonalInfoDetails.swift
//  Client
//
//  Created by Fratello Software Group on 12/3/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation
import UIKit
import ObjectMapper

class ClientPersonalInfoDetailsResult: Mappable {
    
    var clientPersonalInfoDetailsResult: [ClientPersonalInfoDetailsModel]?
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map){
        clientPersonalInfoDetailsResult <- map["server_response"]
    }
    
}


class ClientPersonalInfoDetailsModel: Mappable {
    
    
    var FullName: String?
    var Email: String?
    
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        FullName <- map["FullName"]
        Email <- map["Email"]
        
        
    }
}

