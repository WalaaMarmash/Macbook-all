//
//  RegistrationClass.swift
//  Client
//
//  Created by Fratello Software Group on 12/4/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation
class PersonalInfoClass{
    
    static let shared = PersonalInfoClass()
    var Email: String = ""
    var FullName: String = ""
    

    
    init(){}
}

class BusinessInfoClass{
    
    static let shared = BusinessInfoClass()
    
    var BusinessName: String = ""
    var BusinessPlace: String = ""
    var BusinessType: String = ""
    var ImagePath: String = ""
    var ImageCode: String = ""
    
    
    init(){}
}
