//
//  CarPhotos.swift
//  ToGo
//
//  Created by Fratello Software Group on 7/24/18.
//  Copyright © 2018 yara. All rights reserved.
//


import Foundation
import ObjectMapper
import UIKit

class CarPhotos: Mappable {
    
    var vehicleId: String?
    var Name: String?
    var PhotoUrl: String?
    
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        vehicleId <- map["vehicleId"]
        Name <- map["Name"]
        PhotoUrl <- map["PhotoUrl"]
        
    }
}
