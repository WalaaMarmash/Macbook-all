//
//  PostRegionResult.swift
//  ToGo
//
//  Created by Fratello Software Group on 7/10/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation
import ObjectMapper

class PostRegionResult: Mappable {
    
    var postRegionResult: [PostRegionListModel]?
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map){
        postRegionResult <- map["server_response"]
    }
    
}

