//
//  idPlaceTypeModel.swift
//  ToGo
//
//  Created by Fratello Software Group on 7/22/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation
import ObjectMapper
import UIKit

class idPlaceTypeModel: Mappable {
    
    
    var IdTypeLicence: String?
    var TypeName: String?
    
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        IdTypeLicence <- map["IdTypeLicence"]
        TypeName <- map["TypeName"]
        
    }
}
