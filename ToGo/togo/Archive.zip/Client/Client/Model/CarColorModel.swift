//
//  CarColorModel.swift
//  ToGo
//
//  Created by Fratello Software Group on 7/24/18.
//  Copyright © 2018 yara. All rights reserved.
//


import Foundation
import ObjectMapper
import UIKit

class CarColorModel: Mappable {
    
    var ColorId: String?
    var Name: String?
    
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        ColorId <- map["ColorId"]
        Name <- map["Name"]
        
    }
}


class ClientCarPhoto: Mappable {
    
    var vehicleId: String?
    var PhotoUrl: String?
    
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        vehicleId <- map["vehicleId"]
        PhotoUrl <- map["PhotoUrl"]
        
    }
}


