//
//  LangugeResult.swift
//  ToGo
//
//  Created by Fratello Software Group on 7/10/18.
//  Copyright © 2018 yara. All rights reserved.
//


import Foundation
import ObjectMapper


class LangugeResult: Mappable {
    
    var langugeResult: [LangugeListModel]?
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map){
        langugeResult <- map["server_response"]
    }
    
}


class LangugeListModel: Mappable {
    
    // langauge list parameters
    var id: String?
    var Name: String?
    var Orintation: String?
    
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        id <- map["id"]
        Name <- map["Name"]
        Orintation <- map["Orintation"]
        
    }
}

