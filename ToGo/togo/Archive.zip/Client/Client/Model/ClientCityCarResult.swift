//
//  ClientCityCarResult.swift
//  ToGo
//
//  Created by Fratello Software Group on 8/14/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation
import ObjectMapper


class ClientCityCarResult: Mappable {
    
    var Citys: [ClientCityList]?
    var Photos: [ClientCarPhoto]?
    
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map){
        Citys <- map["Citys"]
        Photos <- map["Photos"]
    }
    
}
