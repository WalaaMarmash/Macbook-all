//
//  AppDelegate.swift
//  ToGo
//
//  Created by Fratello Software Group on 5/14/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces
import Firebase
import UserNotifications

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    var googleAPIKey = "AIzaSyA8_TurOEiGaBf_3cQvKRPRyRhzZ6Ux1VE"
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        GMSServices.provideAPIKey(googleAPIKey)
        GMSPlacesClient.provideAPIKey(googleAPIKey)
        
        
        //AIzaSyAlyfM3mRPQSITjwUnqojHTMBZr9thKqMs
        //  GMSServices.provideAPIKey("AIzaSyC00BY_a3l3SPUO-juwzPFsuULy-cEreB0")
        // GMSPlacesClient.provideAPIKey("AIzaSyC00BY_a3l3SPUO-juwzPFsuULy-cEreB0")
        // GMSServices.provideAPIKey("AIzaSyB_4ggxR_zYx1WQ_YvQ3_fCBYqMR2moA34")
        
        let pageContoller = UIPageControl.appearance()
        pageContoller.pageIndicatorTintColor = UIColor.white
        pageContoller.currentPageIndicatorTintColor = UIColor.darkGray
        
        //      UIApplication.shared.setMinimumBackgroundFetchInterval(
        //        UIApplication.)
        
        
        
        let PersonalFlagRegistration = UserDefaults.standard.bool(forKey: "personalClientRegistration")
        let WorkDetailsRegistration = UserDefaults.standard.bool(forKey: "BusnissInfoRegistration")
        let PaymentRegistration = UserDefaults.standard.bool(forKey: "paymentRegistration")
       
        
        if PaymentRegistration == true{
            self.window = UIWindow(frame: UIScreen.main.bounds)
            
            let storyboard = UIStoryboard(name: "Second", bundle: nil)
            let initialViewController = storyboard.instantiateViewController(withIdentifier: "UITabBarController-bAs-bi-vwu")
            self.window?.rootViewController = initialViewController
            self.window?.makeKeyAndVisible()
        }
        
        else if WorkDetailsRegistration == true{
            self.window = UIWindow(frame: UIScreen.main.bounds)
            
            let storyboard = UIStoryboard(name: "Second", bundle: nil)
            let initialViewController = storyboard.instantiateViewController(withIdentifier: "paymentPage")
            self.window?.rootViewController = initialViewController
            self.window?.makeKeyAndVisible()
        }
        
        
        
        else if PersonalFlagRegistration == true{
            self.window = UIWindow(frame: UIScreen.main.bounds)
            
            let storyboard = UIStoryboard(name: "Second", bundle: nil)
            let initialViewController = storyboard.instantiateViewController(withIdentifier: "WorkDetailsPage")
            self.window?.rootViewController = initialViewController
            self.window?.makeKeyAndVisible()
        }
        
      
        
        if #available(iOS 10.0, *) {
            // For iOS 10 display notification (sent via APNS)
            UNUserNotificationCenter.current().delegate = self
            
            let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
            UNUserNotificationCenter.current().requestAuthorization(
                options: authOptions,
                completionHandler: {_, _ in })
            
            // For iOS 10 data message (sent via FCM)
            Messaging.messaging().remoteMessageDelegate = self
            
        } else {
            let settings: UIUserNotificationSettings =
                UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
            application.registerUserNotificationSettings(settings)
        }
        application.registerForRemoteNotifications()
        
        // [END register_for_notifications]
        FirebaseApp.configure()
        
        
        return true
    }
    
 
    
    
    func messaging(_ messaging: Messaging, didRefreshRegistrationToken fcmToken: String) {
        
        UserDefaults.standard.set(fcmToken, forKey: "ClientfcmToken")
        print("Firebase registration token: \(fcmToken)")
        
    }
    
    
    // [START receive_message]
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any]) {
        // If you are receiving a notification message while your app is in the background,
        // this callback will not be fired till the user taps on the notification launching the application.
        // TODO: Handle data of notification
        // Print message ID.
        // Print full message.
        print("userInfo\(userInfo)")
    }
    
    
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any],
                     fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        // If you are receiving a notification message while your app is in the background,
        // this callback will not be fired till the user taps on the notification launching the application.
        // TODO: Handle data of notification
        // Print message ID.
        
        if #available(iOS 10.0, *) {
            UNUserNotificationCenter.current().getNotificationSettings { (notificationSettings) in
                switch notificationSettings.authorizationStatus {
                case .notDetermined: break
                // Request Authorization
                case .authorized: break
                // Schedule Local Notification
                case .denied:
                    print("Application Not Allowed to Display Notifications")
                case .provisional:
                    print("Application Not Allowed to Display Notifications")
                    
                }
            }
        } else {
            
            // Fallback on earlier versions
        }
        
        completionHandler(UIBackgroundFetchResult.newData)
    }
    
    // [END receive_message]
    // [START refresh_token]
    func tokenRefreshNotification(_ notification: Notification) {
        if let refreshedToken = InstanceID.instanceID().token() {
            print("InstanceID token: \(refreshedToken)")
        }
        // Connect to FCM since connection may have failed when attempted before having a token.
        connectToFcm()
    }
    // [END refresh_token]
    // [START connect_to_fcm]
    func connectToFcm() {
        // Won't connect since there is no token
        guard InstanceID.instanceID().token() != nil else {
            return
        }
        
        // Disconnect previous FCM connection if it exists.
        Messaging.messaging().shouldEstablishDirectChannel = false
        
        Messaging.messaging().connect { (error) in
            if error != nil {
                print("Unable to connect with FCM. \(error?.localizedDescription ?? "")")
            } else {
                
                
                
                print("Connected to FCM.")
                //            self.setUpNotificationView()
                //            self.DisplayNotificationPopup()
            }
        }
    }
    // [END connect_to_fcm]
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Unable to register for remote notifications: \(error.localizedDescription)")
    }
    
    // This function is added here only for debugging purposes, and can be removed if swizzling is enabled.
    // If swizzling is disabled then this function must be implemented so that the APNs token can be paired to
    // the InstanceID token.
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        InstanceID.instanceID().setAPNSToken(deviceToken, type: InstanceIDAPNSTokenType.sandbox)
        print("APNs token retrieved: \(deviceToken)")
        
        // RegistrationID.sharedInstance.reg_ID = deviceToken
        
        // With swizzling disabled you must set the APNs token here.
        // FIRInstanceID.instanceID().setAPNSToken(deviceToken, type: FIRInstanceIDAPNSTokenType.sandbox)
    }
    
    // [START connect_on_active]
    func applicationDidBecomeActive(_ application: UIApplication) {
        connectToFcm()
    }
    // [END connect_on_active]
    // [START disconnect_from_fcm]
    func applicationDidEnterBackground(_ application: UIApplication) {
        
        if  CurrentOrderViewController.Orders.count != 0{
            
            // print("ss")
        }
        
        
        Messaging.messaging().disconnect()
        print("Disconnected from FCM.")
    }
    // [END disconnect_from_fcm]
}

// [START ios_10_message_handling]
@available(iOS 10, *)
extension AppDelegate : UNUserNotificationCenterDelegate {
    
    // Receive displayed notifications for iOS 10 devices.
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.alert, .badge, .sound])
        
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let response = response.notification.request.content.userInfo
        
        print(response)
        
        
        let Notification = NotificationManager()
        
        if let TypeIntent = response["TypeIntent"] as? NSString {
            Notification.title = TypeIntent as String
            //Do stuff
        }
        
        if let IdOrder = response["IdOrder"] as? NSString {
            
            Notification.orderID = IdOrder as String
            Notification.requestForNotification()
            
        }
        if let aps = response["aps"] as? NSDictionary {
            if let alert = aps["alert"] as? NSDictionary {
                
                
                if let title = alert["title"] as? NSString {
                    print(title)
                }
                if let body = alert["body"] as? NSString {
                    
                    print(body)
                    //Do stuff
                }
            } else if let alert = aps["alert"] as? NSString {
                print(alert)
            }
        }
        
        completionHandler()
    }
    
    
    
    
}


// [END ios_10_message_handling]
// [START ios_10_data_message_handling]
extension AppDelegate : MessagingDelegate {
    // Receive data message on iOS 10 devices while app is in the foreground.
    @objc(applicationReceivedRemoteMessage:) func application(received remoteMessage: MessagingRemoteMessage) {
        
        print(remoteMessage.appData)
        
    }
   
    
}


class NotificationManager{
    
    static let shared = NotificationManager()
    var orderID: String = ""
    var title: String = ""
    
    init(){}
    
    func requestForNotification(){
        
        if title == "CostOffersOrder"{
            print(title)
           OrderAndOffersViewController.Orders.idOrder = orderID
            MasterViewController.segmentedControlIndex = 0
            
            let storyboard = UIStoryboard(name: "Second", bundle: nil)
            let initialViewController = storyboard.instantiateViewController(withIdentifier: "OrderAndOffers")
            UIApplication.shared.windows.first?.rootViewController = initialViewController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
        }
        if title == "TransporterDeleteOrder"{
            
            let storyboard = UIStoryboard(name: "Second", bundle: nil)
            let initialViewController = storyboard.instantiateViewController(withIdentifier: "UITabBarController-bAs-bi-vwu")
            UIApplication.shared.windows.first?.rootViewController = initialViewController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            
        }
        
    }
    
}

