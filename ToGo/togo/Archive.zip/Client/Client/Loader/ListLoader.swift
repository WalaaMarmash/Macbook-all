//
//  ListLoader.swift
//  Client
//
//  Created by Fratello Software Group on 10/17/18.
//  Copyright © 2018 yara. All rights reserved.
//


import Foundation
import Alamofire
import AlamofireObjectMapper
import ObjectMapper

//Get Language List API
class LangugeListLoader{
    
    // Languge List
    var _langugeList = [LangugeListModel]()
    var langugeList: [LangugeListModel]{
        return _langugeList
    }
    
    // Get Languge List
    func GetLangugeList(completed: @escaping DownloadComplete) {
        
        let url =  Base_URL
        
        Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"GetLanguages"]).responseString{ response in
            
            
              let result = response.result.value
             MainViewController.LangugeResult = result!
            
            let LangugeResult = Mapper<LangugeResult>().map(JSONString: result!)

            if let langugeModelResult =  LangugeResult?.langugeResult {
               self._langugeList = langugeModelResult
            }
            
            
          
            
         //   MainViewController.LangugeResult = result
            completed()
            
            
        }
    }
}

// Get Place List API
class PlaceListLoader{
    
    // Languge List
    var _palceList = [PlaceListModel]()
    var palceList: [PlaceListModel]{
        return _palceList
    }
    
    // Get Place List
    func GetPlaceList(completed: @escaping DownloadComplete) {
        
        let url =  Base_URL
        
        let lang_id = UserDefaults.standard.string(forKey: "language_id")
        print("lang_id\(lang_id!)")
        
        Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"GetRegions", "IdLanguages": lang_id!]).responseObject{ (response: DataResponse<PlaceResult>) in
            
            let result = response.result.value
            
            if (result?.placeResult)!.count == 0{
                self._palceList = []
            }else{
                self._palceList = (result?.placeResult)!
            }
            
            completed()
            
            
        }
    }
    
}




// Get Region List API
class RegionListLoader{
    
    
    // Languge List
    var _RegionList = [PostRegionListModel]()
    var RegionList: [PostRegionListModel]{
        return _RegionList
    }
    
    // Get Place List
    func GetPostRegions(completed: @escaping DownloadComplete) {
        
        let url =  Base_URL
        
        let Region_id = UserDefaults.standard.string(forKey: "Region_id")
        print("Region_id\(Region_id!)")
        
        Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"GetPostRegions", "IdRegion": Region_id!]).responseObject{ (response: DataResponse<PostRegionResult>) in
            
            let result = response.result.value
            
            if (result?.postRegionResult)!.count == 0{
                self._RegionList = []
            }else{
                print((result?.postRegionResult)!.count)
                self._RegionList = (result?.postRegionResult)!
            }
            
            
            completed()
            
            
        }
    }
}




