//
//  ClientLoader.swift
//  Client
//
//  Created by Fratello Software Group on 10/17/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation
import Alamofire
import AlamofireObjectMapper
import ObjectMapper


class ClientLoader{
    
    // Client Personal Info
//    static var Email = ""
//    static var FullName = ""
//    static var BusinessName = ""
//    static var BusinessPlace = ""
//    static var BusinessType = ""
    static var ImagePath = ""
    static var ImageCode = ""
    
    var personalInfo = PersonalInfoClass()
    var businessInfo = BusinessInfoClass()
    
    static var PersonalInfoResult = ""
    static var BusinessInfoResult = ""
    static var GetBusinessTypeResult = ""
    //Client Business Info
    static var  BusinessIDResult: [String]! =  []
    static var  BusinessNAmeResult: [String]! = []
    
    static var jsonDeliveryParam: String = ""
    static var jsonAddressParam: String = ""
    static var SendOrderResult = ""
    static var AcceptClientBidResult = ""
    static var CancelOrderResult = ""
    
    static  var  _OrderDetailsResult = [OrderDetails]()
    
    var rating = RatingClass()
    
    //OrderDetails
    static  var  currentOrderTrackingResult = [CurrentOrderTrackingModel]()
    // Car Photos Result
    var _carPhotos = [ClientCarPhoto]()
    
    var carPhotos: [ClientCarPhoto]{
        return _carPhotos
    }
    
    // City List Result
    var _CityList = [ClientCityList]()
    var CityList: [ClientCityList]{
        return _CityList
    }
    
    
    let Region_id = UserDefaults.standard.string(forKey: "Region_id")
    let url =  Base_URL
    var workDetailsParameters = WorkDetailsParameters()
    
    
    // Post client Personal Information
    func SetPersonalInfo(completed: @escaping DownloadComplete) {
        
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            
            
            
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"SetPersonalInfo", "FullName":personalInfo.FullName,"Email":personalInfo.Email,"CustomerId":userID,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!]).responseString{ response in
                
                if  let result = response.result.value{
                    ClientLoader.PersonalInfoResult = result
                    print("SetPersonalInfoResponse:\(ClientLoader.PersonalInfoResult )")
                }
                completed()
                
            }
            
        }
    }
    
    // Post client Business Information
    func SetBusinessInfo(completed: @escaping DownloadComplete) {
        
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"SetBusinessInfo", "BusinessName":businessInfo.BusinessName,"BusinessPlace":businessInfo.BusinessPlace,"CustomerId":userID,"BusinessType":businessInfo.BusinessType,"ImgName":ClientLoader.ImagePath,"ImgCode":ClientLoader.ImageCode,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!]).responseString{ response in
                
                
                if  let result = response.result.value{
                    
                    ClientLoader.BusinessInfoResult =   result
                }
                completed()
            }
        }
    }
    
    // get Business Type
    func GetBusinessType(completed: @escaping DownloadComplete) {
        
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            let lang_id = UserDefaults.standard.string(forKey: "language_id")
            
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"GetTypeBusiness", "Idlanguage":lang_id!,"CustomerId":userID,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!]).responseString{ response in
                
                if let result = response.result.value{
                    
                    print("GetBusinessTypeResponse:\(result)")
                
                if result == "Blocked"{
                    
                    ClientLoader.GetBusinessTypeResult = response.result.value!
                }else if result == "TokenError"{
                    ClientLoader.GetBusinessTypeResult = response.result.value!
                }
                    
                    
                else{
                    
                    do {
                        let data = response.data
                        if
                            let json = try JSONSerialization.jsonObject(with: data!) as? [String: Any],
                            let res = json["server_response"] as? [[String: Any]] {
                            for item in res {
                                if let id = item["id"] as? String {
                                    
                                    ClientLoader.BusinessIDResult.append(id)
                                }
                                if let name = item["Name"] as? String {
                                    
                                    ClientLoader.BusinessNAmeResult.append(name)
                                }
                                
                                
                            }
                        }
                    } catch {
                        print("Error deserializing JSON: \(error)")
                    }
                    
                }
                }
     
                completed()
            }
            
        }
    }
    
    
    
    /////////bid engie Send Order//////
    
    // Get Citys, Car Images API
    func GetCityPhotosBidEngin(completed: @escaping DownloadComplete) {
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            
            let lang_id = UserDefaults.standard.string(forKey: "language_id")
            
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"GetCityPhotosBidEngin", "Idlanguage":lang_id!,"CustomerId":userID,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!,"IdRegion":Region_id!]).responseString{ response in
                
               
                if let result = response.result.value{
                    
                    print("GetCityPhotosBidEnginResponse:\(result)")
                
                if result == "TokenError"{
                    DeliverDetailViewController.GetCityPhotosBidEnginResult = "TokenError"
                    print("TokenError")
                    
                }else if result == ""{
                 
                    print("error")
                    
                }
                
                
                else{
                    
                   
                        let ClientCityCarResult = Mapper<ClientCityCarResult>().map(JSONString: result)
                        self._carPhotos = (ClientCityCarResult?.Photos)!
                        self._CityList = (ClientCityCarResult?.Citys)!
                   
                }
                }
                
                completed()
            }
            
        }
    }
    
    
    // Send Order API
    func SendOrderBidEnginParams(completed: @escaping DownloadComplete) {
        
        //print(ReciverAddressViewController.LoadDetails["SelectedCarID"])
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"OrderBidEnginParams","CustomerId":userID,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!,"DeliveryParams":ClientLoader.jsonDeliveryParam, "AddressClint": ClientLoader.jsonAddressParam]).responseString{ response in
                
                
                if  let result = response.result.value{
                    ClientLoader.SendOrderResult = result
                    print("SendOrderBidEnginParamsResponse:\(ClientLoader.SendOrderResult)")
                }
                completed()
            }
            
        }
    }
    
    //All Client Orders
    func ShowClientOrder(completed: @escaping DownloadComplete) {
        
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            
           // print("ClientID:\(userID)")
            
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"ShowClientOrder","ClientId":userID
                
                ,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!]).responseString{ response in
                    
                    
                    print("ShowClientOrderResponse:\(response.result.value)")
                    
                    if let result = response.result.value{
                        
                        OrdersViewController.getOrderResult = result
                        
                        if result  == "TokenError"{
                            
                            print("TokenError")
                            
                            
                            
                        }else if result  ==  "Blocked" {
                            print("Blocked")
                        }
                            
                        else{
                         
                                
                                let ordersModelResult = Mapper<OrdersModelResult>().map(JSONString: result)
                                
                                if let OrdersModelResult =  ordersModelResult?.ordersModelResult {
                                    OrdersViewController.Orders = OrdersModelResult
                                }
                                
                                
                            
                        }
                        
                    }
                    
                    completed()
            }
            
        }
    }
    
    
    //All Offers Orders
    func ClientShowBidRequists(completed: @escaping DownloadComplete) {
        
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"ClientShowBidRequists","ClientId":userID, "OrderId":OrderAndOffersViewController.Orders.idOrder!
                
                ,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!]).responseString{ response in
                    
                    if  let result = response.result.value{
                        
                        print("ClientShowBidRequistsResponse:\(result)")
                        
                        if result == "TokenError"{
                            
                            print("TokenError")
                            
                        }else if result == "Blocked" {
                            print("Blocked")
                        }
                            
                        else{
                           
                                let ordersModelResult = Mapper<OrderOfferModelResult>().map(JSONString: result)
                               let ordersdetailsResult = Mapper<OrderOfferModelResult>().map(JSONString: result)
                            
                                if let OrdersModelResult = ordersModelResult?.ordersOfferResult{
                                    
                                    OrderAndOffersViewController.OrderOffers = OrdersModelResult
                              
                        }
                            
                            if let ordersdetailsResult = ordersdetailsResult?.OrderDetailResult{
                                OrderAndOffersViewController.OrderDetailModelOffers = ordersdetailsResult
                                
                            }
                        }
                        
                        
                    }
                    completed()
            }
            
        }
    }
    
    
    
    //Accept Offers
    func AcceptClientBidEngie(completed: @escaping DownloadComplete) {
        
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            
            print(OrderAndOffersViewController.TransporterID)
            
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"AcceptClientBidEngie","ClientId":userID, "OrderId":OrderAndOffersViewController.Orders.idOrder!
                
                ,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!, "TransporterId":  OrderAndOffersViewController.TransporterID]).responseString{ response in
                    
                    
                    if  let result = response.result.value{
                        
                        ClientLoader.AcceptClientBidResult = result
                        print("AcceptClientBidEngieResponse:\(ClientLoader.AcceptClientBidResult)")
                    }
                    
                    completed()
                    
            }
        }
    }
    
    // show order Details
    func ClientShowDetailsOrder(completed: @escaping DownloadComplete) {
        
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"ClientShowDetailsOrder", "ClientId":userID,"OrderId":OrderDetailsViewController.OrderID,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!]).responseString{ response in
                
                
                
                if let  result = response.result.value{
                
                    print("ClientShowDetailsOrderResponse:\(result)")
                    
                if result == "TokenError"{
                    
                    print("TokenError")
                    
                }else if result == "Blocked" {
                    print("Blocked")
                }
                    
                else{
                  
                        let ordersModelResult = Mapper<OrderDetailsResult>().map(JSONString: result)
                        
                        if let ordersModelResult = ordersModelResult?.orderDetailsResult{
                            ClientLoader._OrderDetailsResult = ordersModelResult
                       
                        
                    }
                }
                }
                
                
                completed()
                
                
            }
        }
    }
    
    
    
    // cancel order
    func ClientDeleteOrder(completed: @escaping DownloadComplete) {
        
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"ClientDeleteOrder", "ClientId":userID,"OrderId":OrdersViewController.CancelOrderId,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!]).responseString{ response in
                
                
                if  let result = response.result.value{
                    ClientLoader.CancelOrderResult = result
                    print("ClientDeleteOrderResponse:\(ClientLoader.CancelOrderResult)")
                }
                
                
                
                
                completed()
                
            }
        }
    }
    
    
    
    //All  current Client Orders
    func ClientShowBidRequistsAccepted(completed: @escaping DownloadComplete) {
        
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"ClientShowBidRequistsAccepted","ClientId":userID
                
                ,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!]).responseString{ response in
                    
                    
                    if  let result = response.result.value{
                        
                        print("ClientShowBidRequistsAcceptedResponse:\(result)")
                        
                        let ordersModelResult = Mapper<OrdersModelResult>().map(JSONString: result)
                        
                        if let r = ordersModelResult?.ordersModelResult{
                            CurrentOrderViewController.Orders = r
                        }
                        
                    }
                    
                    completed()
            }
            
        }
    }
    
    
    // show order Details--Current order
    func ClientShowDetailsOrderCurrent(completed: @escaping DownloadComplete) {
        
        
        let lang_id = UserDefaults.standard.string(forKey: "language_id")
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":
                "ClientShowDetailsOrderCurrent","ClientId":userID,
                                                "TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!,
                                                "LangId": lang_id! ,"OrderId": OrderDetailsOfCurrentOrdersViewController.OrderID]).responseString{ response in
                                                    
                                                    
                                                    
                                                    if  let result = response.result.value{
                                                        
                                                         print("ClientShowDetailsOrderCurrentResponse:\(result)")
                                                        
                                                        let OrderDetailsResult = Mapper<OrderDetailsResult>().map(JSONString: result)
                                                        if let r = OrderDetailsResult?.orderDetailsResult {
                                                            ClientLoader._OrderDetailsResult = r
                                                        }
                                                        
                                                        
                                                        
                                                        
                                                        
                                                    }
                                                    completed()
                                                    
            }
        }
    }
    
    
    //All  Previous Client Orders
    func ClientHistoryOrder(completed: @escaping DownloadComplete) {
        
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            
            print("ClientId:\(userID)")
            
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"ClientHistoryOrder","ClientId":userID
                 
                ,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!,"Counter": HistoryPageNumber]).responseString{ response in
                    
                    print(HistoryPageNumber)
                   
                    print(userID)
                    
                    if  let result = response.result.value{
                        
                        
                        
                        print("ClientHistoryOrderResponse:\(result)")
                        
                        let ordersModelResult = Mapper<OrdersModelResult>().map(JSONString: result)
                        
                        if let r = ordersModelResult?.ordersModelResult{
                            
                            
                            
                            if r.count == 0 {
                                // PreviousViewController.isPageRefreshing = true
                            }
                            else{
                                PreviousViewController.isPageRefreshing = false
                            }
                            //  AvailableOrderViewController.Orders = OrdersModelResult
                            
                            for item in r{
                                
                                
                                PreviousViewController.Orders.append(item)
                            }
                            
                            
                            
                          
                        }
                        
                    }
                    completed()
            }
            
        }
    }
    
    
    
    
    func ClientTrackTransporterLocation(completed: @escaping DownloadComplete) {
        
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"ClientTrackTransporterLocation","ClientId":userID,"OrderId":OrderDetailsOfCurrentOrdersViewController.OrderID
                
                ,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!]).responseString{ response in
                    
                    if  let result = response.result.value{
                        
                        OrderDetailMapViewController.ClientTrackTransporterLocationResponse = result
                        
                        print("ClientTrackTransporterLocationResponse:\(result)")
                        
                        let Result = Mapper<CurrentOrderTrackingResult>().map(JSONString: result)
                        
                        
                        if let r = Result?.currentOrderTrackingResult {
                            
                            ClientLoader.currentOrderTrackingResult = r
                            
                            
                        }
                        
                        
                        
                        
                        print(result)
                    }
                    completed()
            }
            
        }
    }
    
    /////// profile API/////
    
    
    func ClientProfileGetTypeWork(completed: @escaping DownloadComplete) {
        
        let lang_id = UserDefaults.standard.string(forKey: "language_id")
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"ClientProfileGetDataTypeWork","ClientId":userID,"LangId": lang_id!
                
                ,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!]).responseString{ response in
                    
                    
                    
                    if  let result = response.result.value{
                        
                        print("ClientProfileGetTypeWorkResponse:\(result)")

                        let WorkDetailsResult = Mapper<ClientWorkDetailsResult>().map(JSONString: result)
                        
                        if let r = WorkDetailsResult?.WorkDetailsResult{
                            WorkDetailsProfileViewController.clientWorkDetailsModel = r
                        }
                        
                    }

                    completed()
            }
            
        }
    }
    
    func ClientProfileEditWorkInfo (completed: @escaping DownloadComplete) {
        
        print(self.workDetailsParameters.WorkName)
        print(self.workDetailsParameters.WorkPlace)
        print(self.workDetailsParameters.WorkTypeId)
        
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"ClientProfileEditWorkInfo","ClientId":userID,"WorkName": self.workDetailsParameters.WorkName,"WorkPlace": self.workDetailsParameters.WorkPlace, "WorkTypeId": self.workDetailsParameters.WorkTypeId
                
                ,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!]).responseString{ response in
                    
                    
                    
                    if  let result = response.result.value{
                        
                        print("ClientProfileEditWorkInfoResponse:\(result)")
                        
                       
                        
                    }
                    
                    completed()
            }
            
        }
    }
    
    
    
    func ClientProfileViewPersonalInfo(completed: @escaping DownloadComplete) {
        
       
        if let  userID = UserDefaults.standard.string(forKey: "userID"){
            Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"ClientProfileViewPersonalInfo","ClientId":userID
                ,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!]).responseString{ response in
                    
                    
                    
                    if  let result = response.result.value{
                        
                        print("ClientProfileViewPersonalInfoResponse:\(result)")
                        
                        let PersonalInfoResult = Mapper<ClientPersonalInfoDetailsResult>().map(JSONString: result)
                        
                        if let r = PersonalInfoResult?.clientPersonalInfoDetailsResult{
                            PersonalInfoProfileViewController.clientPersonalInfoDetailsModel = r
                        }
                      
                        
                    }
                    
                    completed()
            }
            
        }
    }
    
    
    
    func GetBalanceTransporter (completed: @escaping DownloadComplete) {
        
        
        
        let userID = UserDefaults.standard.string(forKey: "userID")!
        Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"GetBalanceTransporter", "TransporterId":userID,"TokenDevice": UserDefaults.standard.string(forKey: "deviceToken")!]).responseString{ response in
            
            
            if  let result = response.result.value{
                print(result)
                
                let TransporterBalanceResult = Mapper<TransporterBalanceResult>().map(JSONString: result)
                
                if let BalanceResult = TransporterBalanceResult?.TransporterBalanceResult {
                    print(BalanceResult.count)
                    WalletViewController.BalanceResult = "\(BalanceResult[0].TransporterBalance!)"
                }
            }
            
            
            completed()
            
            
        }
    }
    
    func ClientRateTrip (completed: @escaping DownloadComplete) {
        
        
        
        let userID = UserDefaults.standard.string(forKey: "userID")!
       
        print("RateValue\(PreviousViewController.RateValue)")
        print("self.rating.OrderId\(PreviousViewController.orderId)")
        
        Alamofire.request(url, method: .post,parameters:["CheckTypeFunction":"ClientRateTrip", "ClientId":userID,"TokenDevice":UserDefaults.standard.string(forKey: "deviceToken")!,"OrderId":PreviousViewController.orderId,"RateValue":PreviousViewController.RateValue]).responseString{ response in
            
            
            if  let result = response.result.value{
                print(result)
                PreviousViewController.orderRatingResult = result
               
            }
            
            
            completed()
            
            
        }
    }
    
}

