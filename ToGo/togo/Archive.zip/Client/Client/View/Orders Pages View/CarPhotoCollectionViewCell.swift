//
//  CarPhotoCollectionViewCell.swift
//  ToGo
//
//  Created by Fratello Software Group on 8/13/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit

class CarPhotoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var carButton: UIButton!
    @IBOutlet weak var carImage: UIImageView!
    
}
