//
//  OrderAndOffersTableViewCell.swift
//  ToGo
//
//  Created by Fratello Software Group on 6/24/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit

class OrderAndOffersTableViewCell: UITableViewCell {
    
    @IBOutlet var uiStack: [UIStackView]!
    @IBOutlet weak var transporterName: UILabel!
    @IBOutlet weak var Price: UILabel!
    @IBOutlet weak var AcceptBtn: GradientButton!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        SetUpOriantation()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    
    func SetUpOriantation()  {
        let lang = UserDefaults.standard.string(forKey: "lang")
        if lang == "ar"{
            for item in uiStack{
                item.semanticContentAttribute = .forceLeftToRight
                
            }
        }else{
            for item in uiStack{
                item.semanticContentAttribute = .forceRightToLeft
            }
            
        }
    }
    
}
