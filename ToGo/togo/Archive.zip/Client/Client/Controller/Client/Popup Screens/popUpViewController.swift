//
//  PopUpViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 7/12/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit

class popUpViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func saveBtnPressed(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
