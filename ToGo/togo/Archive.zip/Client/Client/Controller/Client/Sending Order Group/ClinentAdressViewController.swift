//
//  ClinentAdressViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 5/24/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlacePicker




class ClinentAdressViewController: UIViewController,GMSMapViewDelegate , CLLocationManagerDelegate , GMSPlacePickerViewControllerDelegate {
  
    // Outlets
    @IBOutlet weak var showMapIcon: UIImageView!
    @IBOutlet weak var topSpace: NSLayoutConstraint!
    @IBOutlet var uiLable: [UILabel]!
    @IBOutlet weak var fromPickerView: UIPickerView!
    @IBOutlet weak var fromTextField: CustomTextField!
    @IBOutlet var uiTextField: [CustomTextField]!
    @IBOutlet weak var placeNameTextField: CustomTextField!
    @IBOutlet weak var streetNameTextField: CustomTextField!
    @IBOutlet weak var buildingNameTextField: CustomTextField!
    @IBOutlet weak var flowrTextField: CustomTextField!
    @IBOutlet weak var flowrNumberTextField: CustomTextField!
    @IBOutlet weak var otherDetailsTextField: CustomTextView!
    @IBOutlet weak var saveBtn: UIBarButtonItem!
    @IBOutlet weak var MapLocationTextField: CustomTextField!
    
    @IBOutlet weak var mainScrollView: UIScrollView!
    
    @IBOutlet weak var fromPlaceTableView: UITableView!

    
    // City List
    static var _CityList = [ClientCityList]()
    static var FromcityID: String! = ""
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        
   //     saveBtn.setTitleTextAttributes([NSAttributedStringKey.zone: UIFont(name: "beIN-Arabicblack", size: 20)!], for: .normal)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fromPlaceTableView.isHidden = true
        fromPlaceTableView.tableFooterView = UIView()
        fromPlaceTableView.layer.cornerRadius = 10
        
        let tooBar: UIToolbar = UIToolbar()
        tooBar.barStyle = UIBarStyle.blackTranslucent
        tooBar.items=[
            UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: self, action: nil),
            UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.done, target: self, action:#selector(ReciverAddressViewController.doneTap(_:)))]
        
        tooBar.sizeToFit()
       
        flowrTextField.inputAccessoryView = tooBar
        flowrNumberTextField.inputAccessoryView = tooBar
        //SetUpMapView()
        setUpShowImage()
        SetUpOriantation()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
    }
    
    
    @objc func doneTap(_: UILabel) {
        view.endEditing(true)
      
        flowrNumberTextField.resignFirstResponder()
        flowrTextField.resignFirstResponder()
    }
    
    
    func setUpShowImage()  {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(ClinentAdressViewController.imageTapped(gesture:)))
        // add it to the image view;
        showMapIcon.addGestureRecognizer(tapGesture)
        // make sure imageView can be interacted with by user
        showMapIcon.isUserInteractionEnabled = true
    }
    
    @objc func imageTapped(gesture: UIGestureRecognizer) {
        
        
        selectDestFromMap()
        
       // performSegue(withIdentifier: "showMapView", sender: nil)
    }
    
    
    func selectDestFromMap() {
        let config = GMSPlacePickerConfig(viewport: nil)
        
        let placePicker = GMSPlacePickerViewController(config: config)
        
        placePicker.delegate = self
        
        self.present(placePicker, animated: true, completion: nil)
        
    }
    
    @IBAction func showMapLocation(_ sender: Any) {
         selectDestFromMap()
    }
    
    
    // Configure ui Oriantation
    func SetUpOriantation()  {
        
        let lang = UserDefaults.standard.string(forKey: "lang")
        if lang == "ar"{
            for item in uiLable{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
            for item in uiTextField{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
        }else{
            for item in uiLable{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
            for item in uiTextField{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
        }
    }
    
    
    @IBAction func nextBtnPressed(_ sender: Any) {
         SaveOdrerData()
    }
    
    
    @IBAction func saveBtnPressed(_ sender: Any) {
        //SaveOdrerData()
    }
    
    
    
    // Save Odrer Data
    func SaveOdrerData()  {
        
        
        if  ReciverAddressViewController.SenderAdress["lat"] != "" , ReciverAddressViewController.SenderAdress["long"] != ""{
            
            ReciverAddressViewController.SenderAdress["from"] = ClinentAdressViewController.FromcityID
            ReciverAddressViewController.SenderAdress["placeName"] = placeNameTextField.text
            ReciverAddressViewController.SenderAdress["streetName"] = streetNameTextField.text
            ReciverAddressViewController.SenderAdress["buildingName"] = buildingNameTextField.text
            ReciverAddressViewController.SenderAdress["flowr"] = flowrTextField.text
            ReciverAddressViewController.SenderAdress["flowrNumber"] = flowrNumberTextField.text
            ReciverAddressViewController.SenderAdress["otherDetails"] = otherDetailsTextField.text
            
            ReciverAddressViewController.SenderAdressFlage = true
            
            UserDefaults.standard.set(ReciverAddressViewController.SenderAdress["placeName"], forKey: "placeName")
            UserDefaults.standard.set(ReciverAddressViewController.SenderAdress["streetName"], forKey: "streetName")
            UserDefaults.standard.set(ReciverAddressViewController.SenderAdress["buildingName"], forKey: "buildingName")
            UserDefaults.standard.set(ReciverAddressViewController.SenderAdress["flowr"], forKey: "flowr")
            UserDefaults.standard.set(ReciverAddressViewController.SenderAdress["flowrNumber"], forKey: "flowrNumber")
            UserDefaults.standard.set(ReciverAddressViewController.SenderAdress["otherDetails"], forKey: "otherDetails")
            
            
            let alert = UIAlertController(title: "", message: successSaveOrder_Message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: {(action:UIAlertAction!) in
                
                
                self.performSegue(withIdentifier: "ReciverAddressSegue", sender: nil)
            }))
            self.present(alert, animated: true)
            
        }
            
            
        else{
           
            if placeNameTextField.text == "" {
                placeNameTextField.layer.borderWidth = 1.0
                placeNameTextField.layer.borderColor = UIColor.red.cgColor
                
            }else if  streetNameTextField.text == "" {
                streetNameTextField.layer.borderWidth = 1.0
                streetNameTextField.layer.borderColor = UIColor.red.cgColor
                
            }else if buildingNameTextField.text == "" {
                buildingNameTextField.layer.borderWidth = 1.0
                buildingNameTextField.layer.borderColor = UIColor.red.cgColor
                
            }else if flowrTextField.text == "" {
                flowrTextField.layer.borderWidth = 1.0
                flowrTextField.layer.borderColor = UIColor.red.cgColor
                
            }else if flowrNumberTextField.text == ""{
                
                flowrNumberTextField.layer.borderWidth = 1.0
                flowrNumberTextField.layer.borderColor = UIColor.red.cgColor
            }
            
            
            else{
                placeNameTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
                streetNameTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
                buildingNameTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
                flowrTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
                MapLocationTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
                flowrNumberTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
                
                ReciverAddressViewController.SenderAdress["from"] = ClinentAdressViewController.FromcityID
                ReciverAddressViewController.SenderAdress["placeName"] = placeNameTextField.text
                ReciverAddressViewController.SenderAdress["streetName"] = streetNameTextField.text
                ReciverAddressViewController.SenderAdress["buildingName"] = buildingNameTextField.text
                ReciverAddressViewController.SenderAdress["flowr"] = flowrTextField.text
                ReciverAddressViewController.SenderAdress["flowrNumber"] = flowrNumberTextField.text
                ReciverAddressViewController.SenderAdress["otherDetails"] = otherDetailsTextField.text
                
                ReciverAddressViewController.SenderAdressFlage = true
                
                UserDefaults.standard.set(ReciverAddressViewController.SenderAdress["placeName"], forKey: "placeName")
                UserDefaults.standard.set(ReciverAddressViewController.SenderAdress["streetName"], forKey: "streetName")
                UserDefaults.standard.set(ReciverAddressViewController.SenderAdress["buildingName"], forKey: "buildingName")
                UserDefaults.standard.set(ReciverAddressViewController.SenderAdress["flowr"], forKey: "flowr")
                UserDefaults.standard.set(ReciverAddressViewController.SenderAdress["flowrNumber"], forKey: "flowrNumber")
                UserDefaults.standard.set(ReciverAddressViewController.SenderAdress["otherDetails"], forKey: "otherDetails")
                
                
                let alert = UIAlertController(title: "", message: successSaveOrder_Message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: {(action:UIAlertAction!) in
                    
                    
                    self.performSegue(withIdentifier: "ReciverAddressSegue", sender: nil)
                }))
                self.present(alert, animated: true)
                
            }
            
            
        }
        
//        if  ReciverAddressViewController.SenderAdress["lat"] == "" || ReciverAddressViewController.SenderAdress["long"] == "" {
//
//            MapLocationTextField.layer.borderWidth = 1.0
//            MapLocationTextField.layer.borderColor = UIColor.red.cgColor
//
//        }
        
        
        
        
        
        
    }
    
    @IBAction func setLastLocation(_ sender: Any) {
        
        // print(UserDefaults.standard.string(forKey: "placeName"))
        if UserDefaults.standard.string(forKey: "placeName") == nil{
            let alert = UIAlertController(title: "", message: NoPreviousLocation_Message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
            self.present(alert, animated: true)
            
        }else{
            placeNameTextField.text = UserDefaults.standard.string(forKey: "placeName")
            streetNameTextField.text = UserDefaults.standard.string(forKey: "streetName")
            buildingNameTextField.text = UserDefaults.standard.string(forKey: "buildingName")
            flowrNumberTextField.text = UserDefaults.standard.string(forKey: "flowr")
            flowrTextField.text = UserDefaults.standard.string(forKey: "flowrNumber")
            otherDetailsTextField.text = UserDefaults.standard.string(forKey: "otherDetails")
        }
        
    }
    
    
    
    
    func placePicker(_ viewController: GMSPlacePickerViewController, didPick place: GMSPlace) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        print("Place name \(place.name)")
        print("Lat \(place.coordinate.latitude)")
        
        print("Long \(place.coordinate.longitude)")
        
        self.MapLocationTextField.text = place.name
         self.MapLocationTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
        ReciverAddressViewController.SenderAdress["lat"] = String(place.coordinate.latitude)
        ReciverAddressViewController.SenderAdress["long"] = String(place.coordinate.longitude)
        
    }
    
    func placePickerDidCancel(_ viewController: GMSPlacePickerViewController) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        print("No place selected")
    }
    
    @IBAction func unwindToVC1(segue:UIStoryboardSegue) {
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "showMapView"{
            
            _ = segue.destination as?
            SenderMapViewController
        }
        
        if segue.identifier == "ReciverAddressSegue"{
            
            _ = segue.destination as?
            ReciverAddressViewController
        }
        
    }
    
    
    @IBAction func backBtnPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
   
    func animate(toogle: Bool, type: Int) {
        
        if type == 1{
            if toogle {
                UIView.animate(withDuration: 0.3) {
                    self.fromPlaceTableView.isHidden = false
                }
            } else {
                UIView.animate(withDuration: 0.3) {
                    self.fromPlaceTableView.isHidden = true
                }
                
            }
        }
    }
    
    
    
}





/// ///////////City List drop down////////////////
extension ClinentAdressViewController: UIPickerViewDelegate ,UIPickerViewDataSource{
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return ClinentAdressViewController._CityList.count
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        self.view.endEditing(true)
        if pickerView == fromPickerView{
            return ClinentAdressViewController._CityList[row].Name
        }
        else{
            return ""
        }
        
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if pickerView == fromPickerView{
            self.fromTextField.text = ClinentAdressViewController._CityList[row].Name
            ClinentAdressViewController.FromcityID = ClinentAdressViewController._CityList[row].IdCity
            fromTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            
            
        }
        
        fromPickerView.isHidden = true
        
        
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 60
    }
}


///////////////////////TextField//////////////////////////////////////////////
extension ClinentAdressViewController: UITextFieldDelegate{
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == fromTextField{
            //fromPickerView.isHidden = false
             animate(toogle: true, type: 1)
            
            self.view.endEditing(true)
        }
        else if textField == flowrNumberTextField{
         //   mainScrollView.setContentOffset(CGPoint(x: 0, y: 250), animated: true)
        }
        
       
        
    }
    // handel return key for textField
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == flowrNumberTextField{
          //  mainScrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        }
    }
    
    
    
}

//////////////////TextView///////////////////////
extension ClinentAdressViewController: UITextViewDelegate{
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView == otherDetailsTextField{
            
           // mainScrollView.setContentOffset(CGPoint(x: 0, y: 400), animated: true)
        }
        
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
       //  mainScrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        
        
       
        
        if textField == placeNameTextField{
            if textField.text == ""{
                 placeNameTextField.layer.borderColor = UIColor.red.cgColor
            }else{
                placeNameTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            }
        }
        if textField == streetNameTextField{
            if textField.text == ""{
                streetNameTextField.layer.borderColor = UIColor.red.cgColor
            }else{
                streetNameTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            }
        }
        if textField == buildingNameTextField{
            if textField.text == ""{
                buildingNameTextField.layer.borderColor = UIColor.red.cgColor
            }else{
                buildingNameTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            }
        }
        if textField == flowrTextField{
            if textField.text == ""{
                flowrTextField.layer.borderColor = UIColor.red.cgColor
            }else{
                flowrTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            }
        }
        if textField == MapLocationTextField{
            if textField.text == ""{
                MapLocationTextField.layer.borderColor = UIColor.red.cgColor
            }else{
                MapLocationTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            }
        }
        
        if textField == flowrNumberTextField{
            if textField.text == ""{
                flowrNumberTextField.layer.borderColor = UIColor.red.cgColor
            }else{
                flowrNumberTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            }
        }
    }
    
    
    
}



extension ClinentAdressViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
      
            return ClinentAdressViewController._CityList.count
      
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.textLabel?.text = ClinentAdressViewController._CityList[indexPath.row].Name
            return cell
        }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
            self.fromTextField.text = "\(String(describing: ClinentAdressViewController._CityList[indexPath.row].Name!))"
        
         ClinentAdressViewController.FromcityID = ClinentAdressViewController._CityList[indexPath.row].IdCity
        
        fromTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            animate(toogle: false, type: 1)
      
}
}
