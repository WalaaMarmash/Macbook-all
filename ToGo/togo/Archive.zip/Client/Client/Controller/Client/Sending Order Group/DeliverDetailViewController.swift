//
//  DeliverDetailViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 5/23/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import ReachabilitySwift

class DeliverDetailViewController: UIViewController{
    
    
    @IBOutlet var RoundedBtn: [RoundedBtn]!
    @IBOutlet weak var saveBtn: UIBarButtonItem!
    //Car Photo Collection
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var collectionHight: NSLayoutConstraint!
    
    var clientLoader = ClientLoader()
    // var transporterLoader = TransporterLoader()
    // Car Color
    var _CarColorModel = [CarColorModel]()
    
    // Car Photos
    static  var _carPhotos = [ClientCarPhoto]()
    @IBOutlet weak var LoadingView: UIView!
    // var loadingView: UIView = UIView()
    // Internet Connection
    let reachability = Reachability()!
    // ActivityIndicator
    var container: UIView = UIView()
    var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
    var refreshControlller = UIRefreshControl()
    static var GetCityPhotosBidEnginResult = ""
    
    override func viewDidAppear(_ animated: Bool) {
        
        DeliverWayViewController.selectedCarImage = -1
        
        let sv = UIViewController.displaySpinner(onView: self.view)
        
        self.clientLoader.GetCityPhotosBidEngin {
            
            
            if DeliverDetailViewController.GetCityPhotosBidEnginResult == "TokenError"{
                
                let alert = UIAlertController(title: "تحذير", message: "لقد تم الدخول لحسابك من جهاز اخر قم بالاغلاق وحاول لاحقا", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "اغلاق", style: .default, handler: {(alert: UIAlertAction!) in
                    UserDefaults.standard.set(false, forKey:  "Client_Status_reg")
                    
                    
                    exit(0)
                    
                }))
                self.present(alert, animated: true)
                
            }
            else{
                
                DeliverDetailViewController._carPhotos = self.clientLoader.carPhotos
                ClinentAdressViewController._CityList = self.clientLoader._CityList
                
                print(DeliverDetailViewController._carPhotos.count)
                
                
                if DeliverDetailViewController._carPhotos.count % 3 == 0{
                    
                    let rowNumber = (DeliverDetailViewController._carPhotos.count)/3
                    
                    
                    let collectionHeight =  rowNumber * 100
                    
                    
                    self.collectionHight.constant = CGFloat(collectionHeight)
                    print(collectionHeight)
                    print(self.collectionHight.constant)
                    self.collectionView.reloadData()
                    
                    UIViewController.removeSpinner(spinner: sv)
                }else{
                    
                    
                    let rowNumber = (DeliverDetailViewController._carPhotos.count)/3
                    
                    let x   = Int(rowNumber) + 1
                    print(x)
                    
                    let collectionHeight =  x * 100
                    
                    
                    self.collectionHight.constant = CGFloat(collectionHeight)
                    print(collectionHeight)
                    print(self.collectionHight.constant)
                    self.collectionView.reloadData()
                    
                    UIViewController.removeSpinner(spinner: sv)
                }
            }
            
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        intilizeView()
        //           print("viewWillAppear")
        //
        //        // Check internet connection
        //        //when Reachable
        //        reachability.whenReachable = { reachability in
        //            DispatchQueue.main.async {
        
        
        //  }
        //}
        //        // When UnReachable
        //        self.reachability.whenUnreachable = { reachability in
        //            // this is called on a background thread, but UI updates must
        //            // be on the main thread, like this:
        //            DispatchQueue.main.async {
        //
        //
        //            }
        //
        //        }
        //
        //        do {
        //            try reachability.startNotifier()
        //        } catch {
        //            print("Unable to start notifier")
        //        }
        //
        //
    }
    
    
    func intilizeView()  {
        DeliverWayViewController.DeliverWayID = 0
        for item in RoundedBtn{
            
            item.backgroundColor = UIColor.clear
            
        }
        // print( "DeliverWayViewController.selectedCarImage\( DeliverWayViewController.selectedCarImage)")
        
        let indexpath = IndexPath(row: DeliverWayViewController.selectedCarImage, section: 0)
        let cell = self.collectionView.cellForItem(at: indexpath)
        self.collectionView.deselectItem(at: indexpath, animated: false)
        cell?.layer.borderColor  = UIColor.clear.cgColor
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        
        SetupBtn()
    }
    
    @IBAction func completeOrderBtnPressed(_ sender: Any) {
       SaveOdrerData()
    }
    @IBAction func saveBtnPressed(_ sender: Any) {
    }
    
    func SaveOdrerData()  {
        
        print(DeliverWayViewController.selectedCarImage)
        
        
        if DeliverWayViewController.selectedCarImage == -1{
       
                            let alert = UIAlertController(title: "", message: "الرجاء اختيار طريقة التوصيل", preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                            self.present(alert, animated: true)
        }
            else{
                self.performSegue(withIdentifier: "DeliverWaySegue", sender: nil)

            }
        
        // print("selectedCarImage:\(DeliverWayViewController.selectedCarImage)")
        //  print("DeliverWayID:\(DeliverWayViewController.DeliverWayID)")
        
        //        if DeliverWayViewController.selectedCarImage == 0{
        ////            let alert = UIAlertController(title: "", message: "الرجاء اختيار وسيلة التوصيل ", preferredStyle: .alert)
        ////            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
        ////            self.present(alert, animated: true)
        //        }else
        
        //            if DeliverWayViewController.DeliverWayID == 0{
        //            let alert = UIAlertController(title: "", message: "الرجاء اختيار طريقة التوصيل", preferredStyle: .alert)
        //            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
        //            self.present(alert, animated: true)
        //        }
        //
        //
        //        else{
        //            let alert = UIAlertController(title: "", message: "تم حفظ البيانات بنجاح", preferredStyle: .alert)
        //            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
        //            self.present(alert, animated: true)
        
        self.performSegue(withIdentifier: "DeliverWaySegue", sender: nil)
        
        // }
        
        
    }
    
    @objc func addTapped() {
        
    }
    
    
    // Choose delivered Type
    @IBAction func deliveredTypeBtnPressed(_ sender: UIButton) {
        
        DeliverWayViewController.DeliverWayID = sender.tag
        
        for item in RoundedBtn{
            
            if item.tag != sender.tag{
                item.backgroundColor = UIColor.clear
            }
        }
        
        if sender.backgroundColor == UIColor(netHex: 0x29A89A){
            sender.backgroundColor = UIColor.clear
        }else{
            sender.backgroundColor = UIColor(netHex: 0x29A89A)
        }
        
        print(sender.tag)
       // SaveOdrerData()
        
        
    }
    
    
    
    @objc func carImageimageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        let tappedImage = tapGestureRecognizer.view as! UIButton
       
        print("you tap image number : \(tappedImage.tag)")
        
        
        //        TransporterLoader.CarImgId = DeliverDetailViewController._carPhotos[tappedImage.tag].vehicleId!
        
        DeliverWayViewController.selectedCarImage = tappedImage.tag
        
        if tappedImage.backgroundColor == UIColor.lightGray.withAlphaComponent(0.6){
            tappedImage.backgroundColor = UIColor.clear
        }
        else{
            tappedImage.backgroundColor = UIColor.lightGray.withAlphaComponent(0.6)
            
        }
        
    }
    
    
    
    // called when back btn pressed
    @IBAction func backBtnPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    func SetupBtn()  {
        
        for item in RoundedBtn{
            item.layer.borderWidth = 1
            item.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
        }
    }
    
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "DeliverWaySegue"{
            
            _ = segue.destination as?
            DeliverWayViewController
        }
        
        
        
    }
}


//////////////////////// Car  Collection ////////////////////////////////////////
extension DeliverDetailViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return DeliverDetailViewController._carPhotos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CarPhotoCollectionViewCell
        
        print(image_URL + DeliverDetailViewController._carPhotos[indexPath.row].PhotoUrl!)
        
        cell.carImage.layer.cornerRadius = cell.carImage.frame.size.width / 2
        cell.carImage.backgroundColor = UIColor.clear
        cell.carImage.clipsToBounds = true
        
        cell.carImage.kf.setImage(with: URL(string:image_URL + DeliverDetailViewController._carPhotos[indexPath.row].PhotoUrl!))
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print(indexPath.row)
        let cell = collectionView.cellForItem(at: indexPath) as! CarPhotoCollectionViewCell
        //        cell?.layer.borderWidth = 2.0
        //        cell?.layer.cornerRadius = 10.0
        //        cell?.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
        
        cell.carImage.backgroundColor = UIColor(netHex: 0x29A89A).withAlphaComponent(0.5)
        DeliverWayViewController.selectedCarImage = indexPath.row
    }
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath) as! CarPhotoCollectionViewCell
        
        cell.carImage.backgroundColor = UIColor.clear
    }
    
    // set the size of collectionview cell
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        // let padding: CGFloat =  0
        let collectionViewSize = collectionView.frame.size.width
        return CGSize(width: collectionViewSize/4,height: collectionViewSize/4)
        
    }
}
//

extension DeliverDetailViewController: UITextViewDelegate{
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    
    
    
}







