//
//  ReciverAddressViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 6/20/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import GoogleMaps
import ReachabilitySwift
import GooglePlacePicker

class ReciverAddressViewController: UIViewController ,GMSMapViewDelegate , CLLocationManagerDelegate , GMSPlacePickerViewControllerDelegate{
    
    //Outlets
    @IBOutlet weak var confirmationPopup: RoundedBtn!
    @IBOutlet weak var submitBtn: RoundedBtn!
    @IBOutlet weak var cancelBtn: RoundedBtn!
    @IBOutlet weak var mapView: GMSMapView!
    @IBOutlet weak var showMapIcon: UIImageView!
    @IBOutlet weak var topSpace: NSLayoutConstraint!
    @IBOutlet var uiLable: [UILabel]!
    @IBOutlet var uiTextField: [CustomTextField]!
    @IBOutlet weak var toPickerView: CustomPickerView!
    @IBOutlet weak var toCitysTextField: CustomTextField!
    @IBOutlet weak var placeNameTextField: CustomTextField!
    @IBOutlet weak var streetNameTextField: CustomTextField!
    @IBOutlet weak var buildingNameTextField: CustomTextField!
    @IBOutlet weak var flowrTextField: CustomTextField!
    @IBOutlet weak var flowrNumberTextField: CustomTextField!
    @IBOutlet weak var otherDetailsTextField: CustomTextView!
    @IBOutlet weak var saveBtn: UIBarButtonItem!
    @IBOutlet weak var MapLocationTextField: CustomTextField!
    
     @IBOutlet weak var mainScrollView: UIScrollView!
    
    
    @IBOutlet weak var Loadingview: UIView!
    @IBOutlet weak var ReciverMobileNumber: CustomTextField!
    
    static var LoadDetails: [String: String] = [:]
    static var SenderAdress: [String: String] = [:]
    static var ReciverAdress: [String: String] = [:]
    
    static var LoadDetailsFlage: Bool = false
    static var SenderAdressFlage: Bool = false
    static var ReciverAdressFlage: Bool = false
    static var TocityID: String! = ""
    
    var clientLoader = ClientLoader()
    
    
    
    // Internet Connection
    let reachability = Reachability()!
    // ActivityIndicator
    var container: UIView = UIView()
    var loadingView: UIView = UIView()
    var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
    var refreshControlller = UIRefreshControl()
    let View = UIView()
   // @IBOutlet weak var LoadingView: UIView!
    
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        
      //  saveBtn.setTitleTextAttributes([NSAttributedString.Key.zone: UIFont(name: "beIN-Arabicblack", size: 20)!], for: .normal)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Loadingview.frame = CGRect(x: 0,y: 0,width: 80,height: 80)
        Loadingview.center = self.view.center
        Loadingview.backgroundColor = UIColor(netHex: 0x444444).withAlphaComponent(0.7)
         Loadingview.clipsToBounds = true
         Loadingview.layer.cornerRadius = 10
        
        
        let tooBar: UIToolbar = UIToolbar()
        tooBar.barStyle = UIBarStyle.blackTranslucent
        tooBar.items=[
            UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: self, action: nil),
            UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.done, target: self, action:#selector(ReciverAddressViewController.doneTap(_:)))]
        
        tooBar.sizeToFit()
        ReciverMobileNumber.inputAccessoryView = tooBar
        flowrTextField.inputAccessoryView = tooBar
        flowrNumberTextField.inputAccessoryView = tooBar
        
        //SetUpMapView()
        setUpShowImage()
        SetUpOriantation()
        setUpUI()
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
    }
    
    
    @objc func doneTap(_: UILabel) {
        view.endEditing(true)
        ReciverMobileNumber.resignFirstResponder()
        flowrNumberTextField.resignFirstResponder()
        flowrTextField.resignFirstResponder()
    }
    
    
    // maxLength for mobileTextField
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange,
                   replacementString string: String) -> Bool
    {
        if textField ==  ReciverMobileNumber{
            
            let maxLength = 10
            let currentString: NSString = ReciverMobileNumber.text! as NSString
            let newString: NSString =
                currentString.replacingCharacters(in: range, with: string) as NSString
            return newString.length <= maxLength
        }
            
        else{
            return true
        }
        
    }
    
    func SetUpMapView()  {
        // Create a GMSCameraPosition that tells the map to display the
        // coordinate -33.86,151.20 at zoom level 6.
        let camera = GMSCameraPosition.camera(withLatitude: -33.86, longitude: 151.20, zoom: 6.0)
        let mapView = GMSMapView.map(withFrame: CGRect.zero, camera: camera)
        self.mapView = mapView
        
        // Creates a marker in the center of the map.
        let marker = GMSMarker()
        marker.position = CLLocationCoordinate2D(latitude: -33.86, longitude: 151.20)
        marker.title = "Sydney"
        marker.snippet = "Australia"
        marker.map = mapView
    }
    
    // Configure UI
    func setUpUI()  {
        self.submitBtn.layer.borderWidth = 0.5
        self.submitBtn.layer.cornerRadius = 15
        self.submitBtn.layer.borderColor = UIColor.white.cgColor
        self.cancelBtn.layer.borderWidth = 0.5
        self.cancelBtn.layer.cornerRadius = 15
        self.cancelBtn.layer.borderColor = UIColor.white.cgColor
    }
    
    
    // Configure ui Oriantation
    func SetUpOriantation()  {
        
        let lang = UserDefaults.standard.string(forKey: "lang")
        if lang == "ar"{
            for item in uiLable{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
            for item in uiTextField{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
        }else{
            for item in uiLable{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
            for item in uiTextField{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
        }
    }
    
    @IBAction func saveBtnPressed(_ sender: Any) {
     //   SaveOdrerData()
    }
    
    // Save Reciver Address
    func SaveOdrerData()  {
        
        
        if  ReciverAddressViewController.ReciverAdress["lat"] == "" || ReciverAddressViewController.ReciverAdress["long"] == "" {
            
            MapLocationTextField.layer.borderWidth = 1.0
            MapLocationTextField.layer.borderColor = UIColor.red.cgColor
            
        }
        else if placeNameTextField.text == "" {
            placeNameTextField.layer.borderWidth = 1.0
            placeNameTextField.layer.borderColor = UIColor.red.cgColor
            
        }else if  streetNameTextField.text == "" {
            streetNameTextField.layer.borderWidth = 1.0
            streetNameTextField.layer.borderColor = UIColor.red.cgColor
            
        } else if buildingNameTextField.text == "" {
            buildingNameTextField.layer.borderWidth = 1.0
            buildingNameTextField.layer.borderColor = UIColor.red.cgColor
            
        }else if  flowrTextField.text == ""{
            flowrTextField.layer.borderWidth = 1.0
            flowrTextField.layer.borderColor = UIColor.red.cgColor
            
        }else if flowrNumberTextField.text == "" {
            flowrNumberTextField.layer.borderWidth = 1.0
            flowrNumberTextField.layer.borderColor = UIColor.red.cgColor
            
        } else if ReciverMobileNumber.text == ""{
            
           
            ReciverMobileNumber.layer.borderWidth = 1.0
            ReciverMobileNumber.layer.borderColor = UIColor.red.cgColor
        }
            
            
        else if  ReciverMobileNumber.text != "" , (ReciverMobileNumber.text?.characters.count)! < 10{
           
            let alert = UIAlertController(title: "", message: DataCount_Message , preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                self.present(alert, animated: true)
            ReciverMobileNumber.layer.borderWidth = 1.0
            ReciverMobileNumber.layer.borderColor = UIColor.red.cgColor
            }
            
            
            else{
            placeNameTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            streetNameTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            buildingNameTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            flowrTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            MapLocationTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            flowrNumberTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            ReciverMobileNumber.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            
            ReciverAddressViewController.ReciverAdress["from"] = toCitysTextField.text
            ReciverAddressViewController.ReciverAdress["placeName"] = placeNameTextField.text
            ReciverAddressViewController.ReciverAdress["streetName"] = streetNameTextField.text
            ReciverAddressViewController.ReciverAdress["buildingName"] = buildingNameTextField.text
            ReciverAddressViewController.ReciverAdress["flowr"] = flowrTextField.text
            ReciverAddressViewController.ReciverAdress["flowrNumber"] = flowrNumberTextField.text
            ReciverAddressViewController.ReciverAdress["otherDetails"] = otherDetailsTextField.text
            
            ReciverAddressViewController.ReciverAdress["ReceiverAddressNum"] = ReciverMobileNumber.text
           
            
            
            ReciverAddressViewController.ReciverAdressFlage = true
            
            if ReciverAddressViewController.LoadDetailsFlage == false {
                let alert = UIAlertController(title: "", message: LoadDetails_Message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                self.present(alert, animated: true)
            }
            else if ReciverAddressViewController.SenderAdressFlage  == false{
                let alert = UIAlertController(title: "", message: SenderDetails_Message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                self.present(alert, animated: true)
            }
            else if ReciverAddressViewController.ReciverAdressFlage  == false{
                let alert = UIAlertController(title: "", message: ReciverDetails_Message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                self.present(alert, animated: true)
            }
                
            else{
                CreaterAddressArray()
                confirmationPopup.isHidden = false
                self.Loadingview.isHidden = false
                showActivityIndicator(uiView: self.View)
                //self.view.backgroundColor = UIColor.black.withAlphaComponent(0.4)
               
            }
   
            
        }
      
    }
    
    func setUpShowImage()  {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(ClinentAdressViewController.imageTapped(gesture:)))
        // add it to the image view;
        showMapIcon.addGestureRecognizer(tapGesture)
        // make sure imageView can be interacted with by user
        showMapIcon.isUserInteractionEnabled = true
    }
    
    @objc func imageTapped(gesture: UIGestureRecognizer) {
        
        
        selectDestFromMap()
        
        // performSegue(withIdentifier: "showMapView", sender: nil)
    }
    
    @IBAction func showMapLocation(_ sender: Any) {
        selectDestFromMap()
    }
    
    func selectDestFromMap() {
        let config = GMSPlacePickerConfig(viewport: nil)
        
        let placePicker = GMSPlacePickerViewController(config: config)
        
        placePicker.delegate = self
        
        self.present(placePicker, animated: true, completion: nil)
        
    }
    
    
    func placePicker(_ viewController: GMSPlacePickerViewController, didPick place: GMSPlace) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        print("Place name \(place.name)")
        print("Lat \(place.coordinate.latitude)")
        
        print("Long \(place.coordinate.longitude)")
        self.MapLocationTextField.text = place.name
        self.MapLocationTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
        ReciverAddressViewController.ReciverAdress["lat"] = String(place.coordinate.latitude)
        ReciverAddressViewController.ReciverAdress["long"] = String(place.coordinate.longitude)
        
        
        
    }
    
    func placePickerDidCancel(_ viewController: GMSPlacePickerViewController) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        print("No place selected")
    }
    
    
    // Creater Address Array
    func CreaterAddressArray()  {
        
        
        let dict = ["IdCity": ReciverAddressViewController.SenderAdress["from"], "NameNeighborhood": ReciverAddressViewController.SenderAdress["placeName"], "NameStreet":  ReciverAddressViewController.SenderAdress["streetName"], "NameBuilding": ReciverAddressViewController.SenderAdress["buildingName"],"FloorNumbers":  ReciverAddressViewController.SenderAdress["flowr"], "ApartmentNumber":  ReciverAddressViewController.SenderAdress["flowrNumber"],"OtherDetails": ReciverAddressViewController.SenderAdress["otherDetails"],"IdCityDes": ReciverAddressViewController.TocityID,"NameNeighborhoodDes": ReciverAddressViewController.ReciverAdress["placeName"],"NameStreetDes": ReciverAddressViewController.ReciverAdress["streetName"],"NameBuildingDes": ReciverAddressViewController.ReciverAdress["buildingName"],"FloorNumbersDes": ReciverAddressViewController.ReciverAdress["flowr"] ,"ApartmentNumberDes": ReciverAddressViewController.ReciverAdress["flowrNumber"],"OtherDetailsDes": ReciverAddressViewController.ReciverAdress["otherDetails"] ,"LatSender": ReciverAddressViewController.SenderAdress["lat"],"LongSender": ReciverAddressViewController.SenderAdress["long"],"LatReciver": ReciverAddressViewController.ReciverAdress["lat"] ,"LongReciver": ReciverAddressViewController.ReciverAdress["long"], "ReceiverAddressNum": ReciverAddressViewController.ReciverAdress["ReceiverAddressNum"]]
        
        
        var _ : NSError?
        
        let jsonData = try! JSONSerialization.data(withJSONObject: dict, options: JSONSerialization.WritingOptions.prettyPrinted)
        
        print(jsonData)
        
        let jsonString = NSString(data: jsonData, encoding: String.Encoding.utf8.rawValue)! as String
        
        
        
        let AddressParamJson = "{\"AddressParam\": [\(jsonString)]\r\n}"
        print(AddressParamJson)
        ClientLoader.jsonAddressParam = AddressParamJson
    }
    
    
    @IBAction func sendOrderBtnPressed(_ sender: Any) {
        
        SaveOdrerData()
   
    }
    
    
    // Send Order
    @IBAction func sendOrder(_ sender: Any) {
        
        confirmationPopup.isHidden = true
        self.Loadingview.isHidden = true

        //self.view.backgroundColor = UIColor.clear
        
        let sv = UIViewController.displaySpinner(onView: self.view)
        
        //showActivityIndicator(uiView: self.view)
        
        clientLoader.SendOrderBidEnginParams {
            
            UIViewController.removeSpinner(spinner: sv)
            
            if ClientLoader.SendOrderResult.contains("SuccsessInserted"){
                
                
                let alert = UIAlertController(title: "", message: SuccessSendOrder_Message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: {(action:UIAlertAction!) in
                    
                    //Clear data
                    ReciverAddressViewController.LoadDetails = [:]
                    ReciverAddressViewController.ReciverAdress = [:]
                    ReciverAddressViewController.SenderAdress = [:]
                    UserDefaults.standard.set(true, forKey: "Client_Status_reg")
                    // Client_Status_reg
                    //showOrdersSegue
                    
                    self.performSegue(withIdentifier: "showOrdersSegue", sender: nil)
                }))
                
                self.present(alert, animated: true)
                
                
                
            }else if ClientLoader.SendOrderResult.contains("Blocked") {
                let alert = UIAlertController(title: "", message: Blocked_Message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                self.present(alert, animated: true)
            }
                
                
            else{
                let alert = UIAlertController(title: "", message: "حدث خطا يرجى المحاولة لاحقا", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                self.present(alert, animated: true)
            }
            
        }
        
    }
    
    @IBAction func cancelBtnPressed(_ sender: Any) {
        
        //self.view.backgroundColor = UIColor.clear
        confirmationPopup.isHidden = true
         self.Loadingview.isHidden = true
     //   self.LoadingView.isHidden = true
    }
    
    
    
    
    
    
    @IBAction func unwindToVC1(segue:UIStoryboardSegue) {
    }
    
    
    // display Loading Indicator
    func showActivityIndicator(uiView: UIView) {
        container.frame = uiView.frame
        container.center = uiView.center
        container.backgroundColor = UIColor(netHex: 0xffffff).withAlphaComponent(0.3)
        
//        loadingView.frame = CGRect(x: 0,y: 0,width: 80,height: 80)
//        loadingView.center = uiView.center
//        loadingView.backgroundColor = UIColor(netHex: 0x444444).withAlphaComponent(0.7)
//        loadingView.clipsToBounds = true
//        loadingView.layer.cornerRadius = 10
//
//        activityIndicator.frame = CGRect(x: 0.0,y: 0.0,width: 40.0,height: 40.0);
//        activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorView.Style.whiteLarge
//        activityIndicator.center = CGPoint(x: loadingView.frame.size.width / 2,y: loadingView.frame.size.height / 2)
//        activityIndicator.color = UIColor.white
        
        
        //loadingView.addSubview(activityIndicator)
        container.addSubview(loadingView)
        uiView.addSubview(container)
       // activityIndicator.startAnimating()
    }
    
    
    //  Hide loading indicator
    func hideActivityIndicator(uiView: UIView) {
        activityIndicator.stopAnimating()
        container.removeFromSuperview()
    }
    
    
    @IBAction func backBtnPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "ConfirmOrderSegue"{
            
            _ = segue.destination as?
            ConfirmOrderPopUpViewController
        }
        if segue.identifier == "showMapView"{
            
            _ = segue.destination as?
            SenderMapViewController
        }
        
        if segue.identifier == "showOrdersSegue"{
            
            _ = segue.destination as?
            TabBarControllerViewController
        }
        
    }
    
}





/// ///////////City List drop down////////////////
extension ReciverAddressViewController: UIPickerViewDelegate ,UIPickerViewDataSource{
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return ClinentAdressViewController._CityList.count
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        self.view.endEditing(true)
        if pickerView == toPickerView{
            return ClinentAdressViewController._CityList[row].Name
        }
        else{
            return ""
        }
        
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if pickerView == toPickerView{
            self.toCitysTextField.text = ClinentAdressViewController._CityList[row].Name
            ReciverAddressViewController.TocityID = ClinentAdressViewController._CityList[row].IdCity
             toCitysTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
        }
        
        toPickerView.isHidden = true
        
        
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 60
    }
}


///////////////////////TextField//////////////////////////////////////////////
extension ReciverAddressViewController: UITextFieldDelegate{
    
    //textField//
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == toCitysTextField{
            toPickerView.isHidden = false
            self.view.endEditing(true)
        }
        else if textField == flowrNumberTextField{
          //  mainScrollView.setContentOffset(CGPoint(x: 0, y: 250), animated: true)
        }
        else if textField == ReciverMobileNumber{
          //  mainScrollView.setContentOffset(CGPoint(x: 0, y: 300), animated: true)
        }
       
        
    }
    // handel return key for textField
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == flowrNumberTextField || textField == ReciverMobileNumber{
          //  mainScrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        }
    }
   
    //    //textField//
    
    
    
    
}

//////////////////TextView///////////////////////
extension ReciverAddressViewController: UITextViewDelegate{
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
         if textView == otherDetailsTextField{
            
          //  mainScrollView.setContentOffset(CGPoint(x: 0, y: 400), animated: true)
        }
            
            
     
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
       // mainScrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        
        
//        if textField == toCitysTextField{
//            if textField.text == ""{
//                toCitysTextField.layer.borderColor = UIColor.red.cgColor
//            }else{
//                toCitysTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
//            }
//        }
        if textField == MapLocationTextField{
            if textField.text == ""{
                MapLocationTextField.layer.borderColor = UIColor.red.cgColor
            }else{
                MapLocationTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            }
        }
        
        
        if textField == placeNameTextField{
            if textField.text == ""{
                placeNameTextField.layer.borderColor = UIColor.red.cgColor
            }else{
                placeNameTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            }
        }
        if textField == streetNameTextField{
            if textField.text == ""{
                streetNameTextField.layer.borderColor = UIColor.red.cgColor
            }else{
                streetNameTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            }
        }
        if textField == buildingNameTextField{
            if textField.text == ""{
                buildingNameTextField.layer.borderColor = UIColor.red.cgColor
            }else{
                buildingNameTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            }
        }
        if textField == flowrTextField{
            if textField.text == ""{
                flowrTextField.layer.borderColor = UIColor.red.cgColor
            }else{
                flowrTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            }
        }
        if textField == MapLocationTextField{
            if textField.text == ""{
                MapLocationTextField.layer.borderColor = UIColor.red.cgColor
            }else{
                MapLocationTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            }
        }
        
        if textField == flowrNumberTextField{
            if textField.text == ""{
                flowrNumberTextField.layer.borderColor = UIColor.red.cgColor
            }else{
                flowrNumberTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
            }
        }
    }
    
    
}
