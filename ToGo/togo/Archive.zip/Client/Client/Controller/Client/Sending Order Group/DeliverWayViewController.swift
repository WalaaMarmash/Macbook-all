//
//  DeliverWayViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 5/23/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import Kingfisher
import WWCalendarTimeSelector

class DeliverWayViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,WWCalendarTimeSelectorProtocol{
    
    
    
    @IBOutlet weak var selectedImage: UIImageView!
    @IBOutlet weak var detailTextField: UITextView!
    @IBOutlet var uiLable: [UILabel]!
    @IBOutlet var uiStack: [UIStackView]!
    @IBOutlet weak var dateTextField: CustomTextField!
    @IBOutlet weak var dateView: CustomPopupView!
    @IBOutlet weak var dateTypeTextField: CustomTextField!
    @IBOutlet weak var dateTypePickerView: UIPickerView!
    let lenghtUnit = ["cm","mm","m","km"]
    let wegithUnit = ["Kg","Gm","gr","µg","dwt"]
    let dateType = ["في تاريخ محدد","التاريخ الحالي"]
    static var selectedCarImage: Int! = -1
    static var DeliverWayID: Int!
    @IBOutlet weak var lenghtUnitPickerView: CustomPickerView!
    @IBOutlet weak var wegithUnitPickerView: CustomPickerView!
    @IBOutlet weak var lenghtUnitTextField: CustomTextField!
    @IBOutlet weak var wegithUnitTextField: CustomTextField!
    @IBOutlet weak var lenghtTextFeild: CustomTextField!
    @IBOutlet weak var weidthTextField: CustomTextField!
    @IBOutlet weak var heightTextField: CustomTextField!
    @IBOutlet weak var wegithTextField: CustomTextField!
    @IBOutlet weak var bottomSpace: NSLayoutConstraint!
    @IBOutlet weak var saveBtn: UIBarButtonItem!
    
    @IBOutlet weak var productCost: CustomTextField!
    
    @IBOutlet weak var datePickerView: UIDatePicker!
    
    @IBOutlet weak var mainScrollView: UIScrollView!
    
    @IBOutlet weak var LoadView: UIView!
    @IBOutlet weak var foodLoadtype: UIImageView!
    @IBOutlet weak var smalLoadeType: UIImageView!
    @IBOutlet weak var bigLoadType: UIImageView!
    
    var loadType: String = "0"
    
    @IBOutlet weak var buttonSpace: NSLayoutConstraint!
    @IBOutlet weak var topSpace: NSLayoutConstraint!
    @IBOutlet weak var lengthUnitTableList: UITableView!
    @IBOutlet weak var weightTableList: UITableView!
    @IBOutlet weak var dayTypeTableView: UITableView!
    
    
    @IBOutlet var numberTextField: [CustomTextField]!
    
    
    
    override func viewWillAppear(_ animated: Bool) {
         LoadView.isHidden = true
        topSpace.constant = 10
       // saveBtn.setTitleTextAttributes([NSAttributedStringKey.zone: UIFont(name: "beIN-Arabicblack", size: 20)!], for: .normal)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lenghtTextFeild.sizeToFit()
        wegithTextField.sizeToFit()
        heightTextField.sizeToFit()
        
        for item in numberTextField{
            let tooBar: UIToolbar = UIToolbar()
            tooBar.barStyle = UIBarStyle.blackTranslucent
            tooBar.items=[
                UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: self, action: nil),
                UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.done, target: self, action:#selector(DeliverWayViewController.doneTap(_:)))]
            
            tooBar.sizeToFit()
            item.inputAccessoryView = tooBar
        }
        
        
        
        
         lengthUnitTableList.isHidden = true
         weightTableList.isHidden = true
         dayTypeTableView.isHidden = true
        
       // SetUpOriantation()
       // self.datePickerView.locale = Locale(identifier: "en_GB")
        // CreateDeliveryParamArray()
        
        self.detailTextField.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
        self.detailTextField.layer.borderWidth = 1
        self.detailTextField.layer.cornerRadius = 10
       // bottomSpace.constant = 5
        ClearData()
        
        
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(foodLoadtypeimageTapped(tapGestureRecognizer:)))
        foodLoadtype.isUserInteractionEnabled = true
        foodLoadtype.addGestureRecognizer(tapGestureRecognizer)
        
        
        let tapGestureRecognizer1 = UITapGestureRecognizer(target: self, action: #selector(smalLoadeTypeimageTapped(tapGestureRecognizer:)))
        smalLoadeType.isUserInteractionEnabled = true
        smalLoadeType.addGestureRecognizer(tapGestureRecognizer1)
        
        
        let tapGestureRecognizer2 = UITapGestureRecognizer(target: self, action: #selector(bigLoadTypeimageTapped(tapGestureRecognizer:)))
        bigLoadType.isUserInteractionEnabled = true
        bigLoadType.addGestureRecognizer(tapGestureRecognizer2)
    }
    
    
    @objc func doneTap(_: UILabel) {
        view.endEditing(true)
        
        for item in numberTextField{
            item.resignFirstResponder()
           
        }
        
    }
    
    
    
    
    
    
    @objc func foodLoadtypeimageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        loadType = "1"
        ReciverAddressViewController.LoadDetails["TypeLoad‏"] = "1"
        
        let tappedImage = tapGestureRecognizer.view as! UIImageView
        if tappedImage.image != UIImage(named: "To Go - September-41"){
             tappedImage.image = UIImage(named: "To Go - September-41")
        }else{
            tappedImage.image = UIImage(named: "To Go - September-38")
        }
        topSpace.constant = 10
        LoadView.isHidden = true
        smalLoadeType.image = UIImage(named: "To Go - September-36")
        bigLoadType.image = UIImage(named: "To Go - September-37")
        // Your action
    }
    
    @objc func smalLoadeTypeimageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        
        
        
        loadType = "2"
        ReciverAddressViewController.LoadDetails["TypeLoad‏"] = "2"
        let tappedImage = tapGestureRecognizer.view as! UIImageView
        if tappedImage.image != UIImage(named: "To Go - September-40"){
            tappedImage.image = UIImage(named: "To Go - September-40")
            topSpace.constant = 170.5
            LoadView.isHidden = false
        }else{
             tappedImage.image = UIImage(named: "To Go - September-36")
            
        }
       
        foodLoadtype.image = UIImage(named: "To Go - September-38")
        bigLoadType.image = UIImage(named: "To Go - September-37")
        // Your action
    }
    
    @objc func bigLoadTypeimageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        
        loadType = "3"
        ReciverAddressViewController.LoadDetails["TypeLoad‏"] = "3"
        let tappedImage = tapGestureRecognizer.view as! UIImageView
        if tappedImage.image != UIImage(named: "To Go - September-39"){
            tappedImage.image = UIImage(named: "To Go - September-39")
            topSpace.constant = 170.5
            LoadView.isHidden = false
        }else{
             tappedImage.image = UIImage(named: "To Go - September-37")
            topSpace.constant = 10
            LoadView.isHidden = true
        }
       
        foodLoadtype.image = UIImage(named: "To Go - September-38")
        smalLoadeType.image = UIImage(named: "To Go - September-36")
        // Your action
    }
    
    override func viewDidAppear(_ animated: Bool) {
        setSelectedImagePhoto()
        
    }
    
    func setSelectedImagePhoto()  {
        
        print(image_URL + DeliverDetailViewController._carPhotos[DeliverWayViewController.selectedCarImage].PhotoUrl!)
        selectedImage.kf.setImage(with: URL(string:image_URL + DeliverDetailViewController._carPhotos[DeliverWayViewController.selectedCarImage].PhotoUrl!))
        
    }
    
    
    func ClearData()  {
        ReciverAddressViewController.SenderAdress["lat"] = ""
        ReciverAddressViewController.SenderAdress["long"] = ""
        ReciverAddressViewController.ReciverAdress["lat"] = ""
        ReciverAddressViewController.ReciverAdress["long"] = ""
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
       //if pickerView == dateTypePickerView{
            return 2
            
//        }else if pickerView == lenghtUnitPickerView{
//            return lenghtUnit.count
//        }else{
//            return wegithUnit.count
//        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        self.view.endEditing(true)
       // if pickerView == dateTypePickerView{
            return dateType[row]
//        }
//        else if pickerView == lenghtUnitPickerView{
//            return  lenghtUnit[row]
//        }else{
//            return  wegithUnit[row]
//        }
        
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if pickerView == dateTypePickerView{
            
            self.dateTypeTextField.text = dateType[row]
            
            if dateTypeTextField.text == "التاريخ الحالي"{
               self.dateView.isHidden = true
                buttonSpace.constant = 10
                dateTextField.text = GetCurrentDate()
            }else{
                buttonSpace.constant = 10
                dateTextField.text = ""
            }
            dateTypePickerView.isHidden = true
            
        }
            
//        else if pickerView == lenghtUnitPickerView{
//            lenghtUnitTextField.text = lenghtUnit[row]
//            lenghtUnitPickerView.isHidden = true
//
//        }else{
//            wegithUnitTextField.text = wegithUnit[row]
//            wegithUnitPickerView.isHidden = true
//        }
        
    }
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 60
    }
    ////////////// PickerView///////////////
    
    //textField//
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == dateTypeTextField{
            
//            if dayTypeTableView.isHidden {
//                animate(toogle: true, type: 3)
//            } else {
//                animate(toogle: false, type: 3)
//            }
//
//
//         //   dateTypePickerView.isHidden = false
//            bottomSpace.constant = 306
//          //
//            buttonSpace.constant = 240
//            self.view.endEditing(true)
        }
        
        if textField == dateTextField{
            self.view.endEditing(true)
            if dateTypeTextField.text == "في تاريخ محدد"{
//
//                let selector = WWCalendarTimeSelector.instantiate()
//
//                // 2. You can then set delegate, and any customization options
//                selector.delegate = self
//                selector.optionTopPanelTitle = "Awesome Calendar!"
//
//                // 3. Then you simply present it from your view controller when necessary!
//                self.present(selector, animated: true, completion: nil)

                
            }else{
              //  self.view.endEditing(true)
                
            }
            
        }
        
        if textField == lenghtUnitTextField {
           // lenghtUnitPickerView.isHidden  = false
            
            if lengthUnitTableList.isHidden {
                animate(toogle: true, type: 1)
            } else {
                animate(toogle: false, type: 1)
            }
           //  mainScrollView.setContentOffset(CGPoint(x: 0, y: 400), animated: true)
            self.view.endEditing(true)
        }
        if textField == wegithUnitTextField {
            
            if weightTableList.isHidden {
                animate(toogle: true, type: 2)
            } else {
                animate(toogle: false, type: 2)
            }
            
            //wegithUnitPickerView.isHidden = false
            self.view.endEditing(true)
        }
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == lenghtUnitTextField {
           // mainScrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)

        }
        if textField == wegithUnitTextField {
           // mainScrollView.setContentOffset(CGPoint(x: 0, y: 400), animated: true)

        }
    }
    
   
    
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    // handel return key for textField
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    //    //textField//
    
    
    
    //// date////
    func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        print("Selected \n\(date)\n---")
        
        self.dateTextField.text = "\(date)"
        buttonSpace.constant = 10
       
    }
    
 
    @IBAction func chooseDateType(_ sender: Any) {
        
         self.view.endEditing(true)
        
        if dayTypeTableView.isHidden {
            animate(toogle: true, type: 3)
        } else {
            animate(toogle: false, type: 3)
        }
        
        
        //   dateTypePickerView.isHidden = false
        bottomSpace.constant = 306
        //
        buttonSpace.constant = 240
        self.view.endEditing(true)
    }
    
    
    //// date////
    
    
    
    
    @IBAction func doneDateView(_ sender: Any) {
        dateView.isHidden = true
       bottomSpace.constant = 5
        buttonSpace.constant  = 10
        dateTextField.resignFirstResponder()
    }
    
    func GetCurrentDate() -> String {
        
        let date = Date()
        let formatter = DateFormatter()
        
        
       // formatter.locale = Locale(identifier: "en_GB")
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        //formatter.timeZone = TimeZone(secondsFromGMT: 0)
        let result = formatter.string(from: date)
        print(result)
        
        return result
        // print(String(result.dropLast().replacingOccurrences(of: " ", with: "")))
        // return (String(result).replacingOccurrences(of: ",", with: "T")).replacingOccurrences(of: " ", with: "")
        //let date1 = "2012-02-21T18:10:00"
        //return date1
    }
    
    @IBAction func datePickerChanged(_ sender: UIDatePicker) {
        
        ////        let dateFormatter = DateFormatter()
        ////        dateFormatter.dateFormat = "MM-dd-yyyy"
        ////        dateFormatter.timeStyle = DateFormatter.Style.short
        //        dateTextField.text =  dateFormatter.string(from: sender.date)
        
        let dateFormatter = DateFormatter()
        
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
        
        let strDate = dateFormatter.string(from: sender.date)
        print(strDate)
        dateTextField.text = strDate
        buttonSpace.constant  = 10
        
        print(dateTextField.text!)
        
        //        let strDate = dateFormatter.string(from: sender.date)
        //        let dataSting: String = String(strDate.dropLast().dropLast())
        //        dateTextField.text = dataSting
        //        print(dateTextField.text!)
    }
    
    
    
    @IBAction func saveBtnPressed(_ sender: Any) {
        
       // SaveOdrerData()
    }
    
    
    func SaveOdrerData()  {
        
        if loadType != "1"{
            
            if  lenghtTextFeild.text == "" || wegithTextField.text == "" || heightTextField.text == "" || weidthTextField.text == "" || detailTextField.text == "" || dateTextField.text == "" || productCost.text == ""{
                
            let alert = UIAlertController(title: "", message: DataWarning_Message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                self.present(alert, animated: true)
                
            }
            else{
                
                ReciverAddressViewController.LoadDetails["detail"] = detailTextField.text
                ReciverAddressViewController.LoadDetails["lenght"] = lenghtTextFeild.text
                ReciverAddressViewController.LoadDetails["wegith"] = wegithTextField.text
                ReciverAddressViewController.LoadDetails["height"] = heightTextField.text
                ReciverAddressViewController.LoadDetails["weidth"] = weidthTextField.text
                ReciverAddressViewController.LoadDetails["date"] = dateTextField.text
                 ReciverAddressViewController.LoadDetails["CostLoad"] = productCost.text
                //ReciverAddressViewController.LoadDetails["TypeLoad‏"] = "\(String(describing: loadType!))"
               
                // 21D33F14-A932-4220-A3FF-89A52EA21050
                
                ReciverAddressViewController.LoadDetails["SelectedCarID"] = DeliverDetailViewController._carPhotos[DeliverWayViewController.selectedCarImage].vehicleId!
                
                CreateDeliveryParamArray()
                ReciverAddressViewController.LoadDetailsFlage = true
                let alert = UIAlertController(title: "", message: successSaveOrder_Message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: ar_yes, style: .default,handler: {(action:UIAlertAction!) in
                    
                  
                    
                    self.performSegue(withIdentifier: "ClinentAdressSegue", sender: nil)
                }))
                self.present(alert, animated: true)
                
            }
            
        }
        
        else{
            
         if   detailTextField.text == "" || dateTextField.text == ""{
            
            let alert = UIAlertController(title: "", message: DataWarning_Message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
            self.present(alert, animated: true)
            
            }
            
         else{
            ReciverAddressViewController.LoadDetails["detail"] = ""
            ReciverAddressViewController.LoadDetails["lenght"] = ""
            ReciverAddressViewController.LoadDetails["wegith"] = ""
            ReciverAddressViewController.LoadDetails["height"] = ""
            ReciverAddressViewController.LoadDetails["weidth"] = ""
            ReciverAddressViewController.LoadDetails["date"] = ""
            ReciverAddressViewController.LoadDetails["CostLoad"] = productCost.text
          //  ReciverAddressViewController.LoadDetails["TypeLoad‏"] = "\(String(describing: loadType!))"
        
            
            // 21D33F14-A932-4220-A3FF-89A52EA21050
            
            ReciverAddressViewController.LoadDetails["SelectedCarID"] = DeliverDetailViewController._carPhotos[DeliverWayViewController.selectedCarImage].vehicleId!
            
            CreateDeliveryParamArray()
            ReciverAddressViewController.LoadDetailsFlage = true
            let alert = UIAlertController(title: "", message: successSaveOrder_Message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: ar_yes, style: .default,handler: {(action:UIAlertAction!) in
                
               
                self.performSegue(withIdentifier: "ClinentAdressSegue", sender: nil)
            }))
            self.present(alert, animated: true)
            
            }
        }
        
      
        
    }
    
    
    @IBAction func nextBtnPressed(_ sender: UIButton) {
        SaveOdrerData()
    }
    
    
    
    func CreateDeliveryParamArray()  {
        
       
        print(ReciverAddressViewController.LoadDetails["TypeLoad‏"]!)
        
        let dict = ["Idvehicle":  ReciverAddressViewController.LoadDetails["SelectedCarID"]!, "deliveryWay": "\(DeliverWayViewController.DeliverWayID!)", "TypeLoad": loadType, "DetailsLoad": ReciverAddressViewController.LoadDetails["detail"]!, "LengthLoad": ReciverAddressViewController.LoadDetails["lenght"]!,"WidthLoad": ReciverAddressViewController.LoadDetails["weidth"]!, "HeightLoad":   ReciverAddressViewController.LoadDetails["height"]!,"WeightLoad": ReciverAddressViewController.LoadDetails["wegith"]!,"CostLoad": ReciverAddressViewController.LoadDetails["CostLoad"]!
            ,"DateLoad": dateTextField.text!] as [String : Any]
       
        // dict["TypeLoad‏"] = "\(DeliverWayViewController.DeliverWayID!)"
        
       
        
        var _ : NSError?
        
        let jsonData = try! JSONSerialization.data(withJSONObject: dict, options: JSONSerialization.WritingOptions.prettyPrinted)
        let jsonString = NSString(data: jsonData, encoding: String.Encoding.utf8.rawValue)! as String
        
        print(jsonString.replacingOccurrences(of: "\\", with: ""))
    
        
        let DeliveryParamJson = "{\"DeliveryParam\": [\(jsonString.replacingOccurrences(of: "\\", with: ""))]\r\n}"
        print(DeliveryParamJson)
        ClientLoader.jsonDeliveryParam = DeliveryParamJson
    }
    
    @IBAction func backBtnPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    func animate(toogle: Bool, type: Int) {
        
        if type == 1{
            if toogle {
                UIView.animate(withDuration: 0.3) {
                    self.lengthUnitTableList.isHidden = false
                }
            } else {
                UIView.animate(withDuration: 0.3) {
                    self.lengthUnitTableList.isHidden = true
                }
           
        }
        }
        else if type == 2{
            
            if toogle {
                UIView.animate(withDuration: 0.3) {
                    self.weightTableList.isHidden = false
                }
            } else {
                UIView.animate(withDuration: 0.3) {
                    self.weightTableList.isHidden = true
                }
                
            }
        }
            
            
            
        else{
            if toogle {
                UIView.animate(withDuration: 0.3) {
                    self.dayTypeTableView.isHidden = false
                }
            } else {
                UIView.animate(withDuration: 0.3) {
                    self.dayTypeTableView.isHidden = true
                }
                
            }
            
        }
    }
    

    
    
    
    
    func SetUpOriantation()  {
        let lang = UserDefaults.standard.string(forKey: "lang")
        if lang == "ar"{
            for item in uiLable{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
            
            for item in uiStack{
                item.semanticContentAttribute = .forceLeftToRight
                
            }
            
        }else{
            for item in uiLable{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
            
            for item in uiStack{
                item.semanticContentAttribute = .forceRightToLeft
                
            }
        }
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "ClinentAdressSegue"{
            
            _ = segue.destination as?
            ClinentAdressViewController
        }
        
        
        
    }


}


extension DeliverWayViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView == lengthUnitTableList{
        return lenghtUnit.count
        }else if tableView == weightTableList{
            return wegithUnit.count
        }
        else{
            return dateType.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == lengthUnitTableList{
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = lenghtUnit[indexPath.row]
        return cell
        }
        else if tableView == weightTableList{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.textLabel?.text = wegithUnit[indexPath.row]
            return cell
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.textLabel?.text = dateType[indexPath.row]
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if tableView == lengthUnitTableList{
        self.lenghtUnitTextField.text = "\(lenghtUnit[indexPath.row])"
        animate(toogle: false, type: 1)
        }
        else if tableView == weightTableList{
            self.wegithUnitTextField.text = "\(wegithUnit[indexPath.row])"
            animate(toogle: false, type: 2)
        }
        else{
            self.dateTypeTextField.text = dateType[indexPath.row]
            
            if dateTypeTextField.text == "التاريخ الحالي"{
                //self.dateView.isHidden = true
                buttonSpace.constant = 10
                dateTextField.text = GetCurrentDate()
            }else{
                buttonSpace.constant = 10
                dateTextField.text = ""
                
                let selector = WWCalendarTimeSelector.instantiate()
                
                // 2. You can then set delegate, and any customization options
                selector.delegate = self
                selector.optionTopPanelTitle = "Awesome Calendar!"
                
                // 3. Then you simply present it from your view controller when necessary!
                self.present(selector, animated: true, completion: nil)
                
            }
            dateTypePickerView.isHidden = true
            animate(toogle: false, type: 3)
        }
    }
    
    
}




