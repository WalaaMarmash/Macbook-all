//
//  ClientWorkDetailsViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 5/17/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import ReachabilitySwift


class ClientWorkDetailsViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    
    //Outlets
    @IBOutlet weak var LoadingView: UIView!
    @IBOutlet weak var workTypeTableView: UITableView!
    @IBOutlet weak var uploadImage: UIImageView!
    @IBOutlet var uiLable: [UILabel]!
    @IBOutlet var uiTextField: [CustomTextField]!
    @IBOutlet weak var WorkTypePicker: UIPickerView!
    //TextField
    @IBOutlet weak var workPlaceTextField: CustomTextField!
    @IBOutlet weak var workNameTextField: CustomTextField!
    @IBOutlet weak var WorkTypeTextField: CustomTextField!
    @IBOutlet weak var imageTextField: CustomTextField!
    //Loader
    var clientLoader = ClientLoader()
    let RegistrationParameters = BusinessInfoClass()
    let imagePicker = UIImagePickerController()
    
    // ActivityIndicator
    var container: UIView = UIView()
    // var loadingView: UIView = UIView()
    var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
    var refreshControlller = UIRefreshControl()
    
    // Internet Connection
    let reachability = Reachability()!
    
    var BusinessTypeResult: String!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        workTypeTableView.isHidden = true
        workTypeTableView.tableFooterView = UIView()
        imageTextField.isEnabled = false
        GetBussnissTypeList()
        //SetUpOriantation()
        setUpPickerViewUI()
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        uploadImage.isUserInteractionEnabled = true
        uploadImage.addGestureRecognizer(tapGestureRecognizer)
        imagePicker.delegate = self
    }
    
    
    // pull Bussniss Type  from api
    func GetBussnissTypeList()  {
        
        // Check internet connection
        //when Reachable
        reachability.whenReachable = { reachability in
            DispatchQueue.main.async {
                
                let sv = UIViewController.displaySpinner(onView: self.view)
                
                // Get  list
                self.clientLoader.GetBusinessType {
                    
                    self.BusinessTypeResult = ClientLoader.GetBusinessTypeResult
                    if self.BusinessTypeResult == "Blocked"{
                        let alert = UIAlertController(title: "", message: Blocked_Message, preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                        self.present(alert, animated: true)
                    }
                    else{
                        //                    self._BusinessTypeList = self.clientLoader.BusinessTypeList
                        UIViewController.removeSpinner(spinner: sv)
                        self.workTypeTableView.reloadData()
                    }
                }
                
            }
            UserDefaults.standard.set("ar", forKey: "lang")
            
        }
        // When UnReachable
        self.reachability.whenUnreachable = { reachability in
            // this is called on a background thread, but UI updates must
            // be on the main thread, like this:
            DispatchQueue.main.async {
                
                //                self.setUpPopupView()
                //               self.DisplayPopup(message: "")
                let alert = UIAlertController(title: ar_error_title, message: ar_error_message, preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                alert.addAction(UIAlertAction(title: ar_no, style: .cancel, handler: nil))
                self.present(alert, animated: true)
            }
            
        }
        
        do {
            try reachability.startNotifier()
        } catch {
            print("Unable to start notifier")
        }
    }
    
    
    
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        imagePicker.allowsEditing = false
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
        
    }
    
    @IBAction func selectImageTap(_ sender: Any) {
        
        imagePicker.allowsEditing = false
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let selectedImge = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        
        ClientLoader.ImagePath = "image" +  "\(Date().timeIntervalSinceReferenceDate)" + ".jpg"
        
        imageTextField.text =  ClientLoader.ImagePath
        //ImageCode
        let imageData:NSData = UIImagePNGRepresentation(selectedImge)! as NSData
        let strBase64 = imageData.base64EncodedString(options: .lineLength64Characters)
        // print(strBase64)
        ClientLoader.ImageCode = strBase64
        
        
        dismiss(animated: true, completion: nil)
    }
    
    
    
    @IBAction func submitBtnPressed(_ sender: UIButton) {
        
        if workPlaceTextField.text == "" || workNameTextField.text == "" || WorkTypeTextField.text == ""  ||   ClientLoader.ImageCode == ""{
            let alert = UIAlertController(title: "", message: DataWarning_Message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
            self.present(alert, animated: true)
            
        }else{
            RegistrationParameters.BusinessName = workPlaceTextField.text!
            RegistrationParameters.BusinessPlace = workNameTextField.text!
            clientLoader.businessInfo = RegistrationParameters
            
            let sv = UIViewController.displaySpinner(onView: self.view)
            
            clientLoader.SetBusinessInfo {
                
                UIViewController.removeSpinner(spinner: sv)
                print(ClientLoader.BusinessInfoResult)
                if ClientLoader.PersonalInfoResult == "Blocked"{
                    
                    
                    let alert = UIAlertController(title: "", message: Blocked_Message, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                    self.present(alert, animated: true)
                }
                else {
                    UserDefaults.standard.set(true, forKey: "BusnissInfoRegistration")
                    
                    self.performSegue(withIdentifier: "BusnissInfoSegue", sender: nil)
                }
            }
            
        }
        
    }
    
    
    
   
    
    
    func setUpPickerViewUI()  {
        self.WorkTypePicker.layer.borderWidth = 0.5
        self.WorkTypePicker.layer.cornerRadius = 10
        self.WorkTypePicker.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
        
    }
    // Configure ui Oriantation
    func SetUpOriantation()  {
        
        let lang = UserDefaults.standard.string(forKey: "lang")
        if lang == "ar"{
            for item in uiLable{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
            for item in uiTextField{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
        }else{
            for item in uiLable{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
            for item in uiTextField{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
        }
    }
    
    // called when back btn pressed
    @IBAction func backBtnPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "BusnissInfoSegue"{
            
            let destinationNavigationController = segue.destination as! UINavigationController
            let _ = destinationNavigationController.topViewController as! ClientPaymentTypeViewController
        }
        
    }
    
    
    
    func animate(toogle: Bool, type: Int) {
        
        if type == 1{
            if toogle {
                UIView.animate(withDuration: 0.3) {
                    self.workTypeTableView.isHidden = false
                }
            } else {
                UIView.animate(withDuration: 0.3) {
                    self.workTypeTableView.isHidden = true
                }
                
            }
        }
    }
    
}


extension ClientWorkDetailsViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
     return ClientLoader.BusinessIDResult.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.textLabel?.text = ClientLoader.BusinessNAmeResult[indexPath.row]
            return cell
    
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.WorkTypeTextField.text = ClientLoader.BusinessNAmeResult[indexPath.row]
        RegistrationParameters.BusinessType = ClientLoader.BusinessIDResult[indexPath.row]
           
        animate(toogle: false, type: 1)
    
    
}
}


extension ClientWorkDetailsViewController: UITextFieldDelegate{
    //textField//
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == WorkTypeTextField{
            
            self.workTypeTableView.reloadData()
            animate(toogle: true, type: 1)
            //WorkTypePicker.isHidden = false
            self.view.endEditing(true)
            
        }
    }
    // handel return key for textField
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    //textField//
}

