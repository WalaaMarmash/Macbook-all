//
//  ClientPaymentDetailsViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 5/17/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit

class ClientPaymentDetailsViewController: UIViewController,UITextFieldDelegate{
    
    //Outlets
    @IBOutlet weak var yearTextField: CustomTextField!
    @IBOutlet weak var monthTextField: CustomTextField!
    @IBOutlet weak var dayTextField: CustomTextField!
    @IBOutlet var uiLable: [UILabel]!
    @IBOutlet var uiTextField: [CustomTextField]!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpOriantation()
    }
    
    
    // handel return key for textField
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    //textField//
    
    // Configure ui Oriantation
    func SetUpOriantation()  {
        let lang = UserDefaults.standard.string(forKey: "lang")
        if lang == "ar"{
            for item in uiLable{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
            for item in uiTextField{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
                
            }
        }else{
            for item in uiLable{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
            for item in uiTextField{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
                
            }
        }
    }
    
    // called when back btn pressed
    @IBAction func backBtnPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
