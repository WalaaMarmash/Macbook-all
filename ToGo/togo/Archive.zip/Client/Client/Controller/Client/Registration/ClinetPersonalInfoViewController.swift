//
//  ClinetPersonalInfoViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 5/17/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit

class ClinetPersonalInfoViewController: UIViewController , UITextFieldDelegate{
    
    //Outlets
    @IBOutlet var uiLable: [UILabel]!
    @IBOutlet var uiTextField: [CustomTextField]!
    
    //TextField
    @IBOutlet weak var nameTextField: CustomTextField!
    @IBOutlet weak var emailTextField: CustomTextField!
    //Loader
    var clientLoader = ClientLoader()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //  SetUpOriantation()
    }
    
    
    
    @IBAction func submitBtnPressed(_ sender: Any) {
        
        let RegistrationParameters = PersonalInfoClass()
        
        if nameTextField.text == "" || emailTextField.text == ""{
            let alert = UIAlertController(title: "", message: DataWarning_Message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
            self.present(alert, animated: true)
        }
            
        else if isValidEmail(testStr: emailTextField.text!) ==  false{
            let alert = UIAlertController(title: "", message: ErrorData_Message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
            self.present(alert, animated: true)
        }
            
            
        else{
            RegistrationParameters.Email = emailTextField.text!
            RegistrationParameters.FullName = nameTextField.text!
            
            clientLoader.personalInfo = RegistrationParameters
            
            
            let sv = UIViewController.displaySpinner(onView: self.view)
            
            clientLoader.SetPersonalInfo {
                
                print(ClientLoader.PersonalInfoResult)
                UIViewController.removeSpinner(spinner: sv)
                
                if ClientLoader.PersonalInfoResult == "Blocked"{
                    
                    
                    let alert = UIAlertController(title: "", message: Blocked_Message, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                    self.present(alert, animated: true)
                }
                else {
                    
                     UserDefaults.standard.set(true, forKey: "personalClientRegistration")
                    
                    self.performSegue(withIdentifier: "personalClientSegue", sender: nil)
                }
                
            }
            
        }
        
        
    }
    
    
    func isValidEmail(testStr:String) -> Bool {
        // print("validate calendar: \(testStr)")
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
    // handel return key for textField
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    // called when back btn pressed
    @IBAction func backBtnPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    // Configure ui Oriantation
    func SetUpOriantation()  {
        
        let lang = UserDefaults.standard.string(forKey: "lang")
        if lang == "ar"{
            for item in uiLable{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
            for item in uiTextField{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
        }else{
            for item in uiLable{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
            for item in uiTextField{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "personalClientSegue"{
            
            let destinationNavigationController = segue.destination as! UINavigationController
            let _ = destinationNavigationController.topViewController as! ClientWorkDetailsViewController
        }
        
    }
    //
    
}
