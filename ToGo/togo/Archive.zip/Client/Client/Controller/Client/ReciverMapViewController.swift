//
//  ReciverMapViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 8/28/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit

import GoogleMaps
import GooglePlaces
import SwiftyJSON
import Alamofire



class ReciverMapViewController: UIViewController, GMSMapViewDelegate ,  CLLocationManagerDelegate {
    
    @IBOutlet weak var googleMaps: GMSMapView!
    @IBOutlet weak var startLocation: UITextField!
    @IBOutlet weak var destinationLocation: UITextField!
    @IBOutlet weak var saveBtn: UIBarButtonItem!
    
    
    var locationManager = CLLocationManager()
    var locationSelected = Location.startLocation
    
    var locationStart = CLLocation()
    var locationEnd = CLLocation()
    
    let marker = GMSMarker()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // saveBtn.setTitleTextAttributes([NSAttributedStringKey.font: UIFont(name: "beIN-Arabicblack", size: 20)!], for: .normal)
        
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startMonitoringSignificantLocationChanges()
        
        //Your map initiation code
        let camera = GMSCameraPosition.camera(withLatitude: -7.9293122, longitude: 112.5879156, zoom: 15.0)
        
        self.googleMaps.camera = camera
        self.googleMaps.delegate = self
        self.googleMaps?.isMyLocationEnabled = true
        self.googleMaps.settings.myLocationButton = true
        self.googleMaps.settings.compassButton = true
        self.googleMaps.settings.zoomGestures = true
        
    }
    
    // MARK: function for create a marker pin on map
    func createMarker(titleMarker: String, iconMarker: UIImage, latitude: CLLocationDegrees, longitude: CLLocationDegrees) {
       // let marker = GMSMarker()
        marker.position = CLLocationCoordinate2DMake(latitude, longitude)
        marker.title = titleMarker
        marker.icon = iconMarker
        marker.map = googleMaps
    }
    
    //MARK: - Location Manager delegates
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error to get location : \(error)")
    }
    //
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let location = locations.last
        
        createMarker(titleMarker: "عنوان المستقبل", iconMarker: #imageLiteral(resourceName: "mapspin"), latitude: (location?.coordinate.latitude)!, longitude: (location?.coordinate.longitude)!)
        ReciverAddressViewController.ReciverAdress["lat"] = String((location?.coordinate.latitude)!)
        ReciverAddressViewController.ReciverAdress["long"] = String((location?.coordinate.longitude)!)
        
        self.locationManager.stopUpdatingLocation()
        
    }
    
    // MARK: - GMSMapViewDelegate
    
    func mapView(_ mapView: GMSMapView, idleAt position: GMSCameraPosition) {
        print("gggg")
        
        googleMaps.isMyLocationEnabled = true
    }
    
    func mapView(_ mapView: GMSMapView, willMove gesture: Bool) {
        
        
        //  googleMaps.isMyLocationEnabled = true
        
        //  createMarker(titleMarker: "عنوان المرسل", iconMarker: #imageLiteral(resourceName: "mapspin"), latitude: (mapView.myLocation?.coordinate.latitude)!, longitude: (mapView.myLocation?.coordinate.latitude)!)
        //ReciverAddressViewController.SenderAdress["lat"] = String((location?.coordinate.latitude)!)
        //  ReciverAddressViewController.SenderAdress["long"] = String((location?.coordinate.longitude)!)
        //        if (gesture) {
        //            mapView.selectedMarker = nil
        //        }
    }
    
    func mapView(_ mapView: GMSMapView, didTap marker: GMSMarker) -> Bool {
        googleMaps.isMyLocationEnabled = true
        print("tap")
        return false
    }
    
    func mapView(_ mapView: GMSMapView, didTapAt coordinate: CLLocationCoordinate2D) {
        
        createMarker(titleMarker: "عنوان المستقبل", iconMarker: #imageLiteral(resourceName: "mapspin"), latitude: coordinate.latitude, longitude: coordinate.longitude)
        
        ReciverAddressViewController.SenderAdress["lat"] = String(coordinate.latitude)
        ReciverAddressViewController.SenderAdress["long"] = String(coordinate.longitude)
        print("COORDINATE \(coordinate)")
        
        
    }
    
    func didTapMyLocationButton(for mapView: GMSMapView) -> Bool {
        
        
        // googleMaps.isMyLocationEnabled = true
        // googleMaps.selectedMarker = marker
        return false
    }
    
    
    @IBAction func backBtnPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func saveBtnPressed(_ sender: Any) {
        
//        if startLocation.text == ""  {
//
//            let alert = UIAlertController(title: "", message: "الرجاء اختيار المدينة", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
//            self.present(alert, animated: true)
//        }else{
//
//            let alert = UIAlertController(title: "", message: "تم حفظ البيانات بنجاح", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
//            self.present(alert, animated: true)
//        }
        
        
        
    }
    
    @IBAction func setLocation(_ sender: Any) {
        
        
        if ReciverAddressViewController.ReciverAdress["lat"] != "" , ReciverAddressViewController.ReciverAdress["long"] != "" {
            let alert = UIAlertController(title: "", message: successSaveOrder_Message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler:  {(action:UIAlertAction!) in
                self.dismiss(animated: true, completion: nil)
            }))
            self.present(alert, animated: true)
        }else{
            let alert = UIAlertController(title: "", message: "الرجاء اختيار المدينة", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
            self.present(alert, animated: true)
        }
    }
    
    
    //MARK: - this is function for create direction path, from start location to desination location
    
    func drawPath(startLocation: CLLocation, endLocation: CLLocation)
    {
        let origin = "\(startLocation.coordinate.latitude),\(startLocation.coordinate.longitude)"
        let destination = "\(endLocation.coordinate.latitude),\(endLocation.coordinate.longitude)"
        
        
        let url = "https://maps.googleapis.com/maps/api/directions/json?origin=\(origin)&destination=\(destination)&mode=driving"
        
        Alamofire.request(url).responseJSON { response in
            
            print(response.request as Any)  // original URL request
            print(response.response as Any) // HTTP URL response
            print(response.data as Any)     // server data
            print(response.result as Any)   // result of response serialization
            
            do{
                let json = try JSON(data: response.data!)
                let routes = json["routes"].arrayValue
                // print route using Polyline
                for route in routes
                {
                    let routeOverviewPolyline = route["overview_polyline"].dictionary
                    let points = routeOverviewPolyline?["points"]?.stringValue
                    let path = GMSPath.init(fromEncodedPath: points!)
                    let polyline = GMSPolyline.init(path: path)
                    polyline.strokeWidth = 4
                    polyline.strokeColor = UIColor.red
                    polyline.map = self.googleMaps
                }
            }
            catch {
                print("Error deserializing JSON: \(error)")
            }
            
            
            
            
        }
    }
    
    // MARK: when start location tap, this will open the search location
    @IBAction func openStartLocation(_ sender: UIButton) {
        
        let autoCompleteController = GMSAutocompleteViewController()
        autoCompleteController.delegate = self
        
        // selected location
        locationSelected = .startLocation
        
        // Change text color
        UISearchBar.appearance().setTextColor(color: UIColor.black)
        self.locationManager.stopUpdatingLocation()
        
        self.present(autoCompleteController, animated: true, completion: nil)
    }
    
    // MARK: when destination location tap, this will open the search location
    @IBAction func openDestinationLocation(_ sender: UIButton) {
        
        let autoCompleteController = GMSAutocompleteViewController()
        autoCompleteController.delegate = self
        
        // selected location
        locationSelected = .destinationLocation
        
        // Change text color
        UISearchBar.appearance().setTextColor(color: UIColor.black)
        self.locationManager.stopUpdatingLocation()
        
        self.present(autoCompleteController, animated: true, completion: nil)
    }
    
    
    // MARK: SHOW DIRECTION WITH BUTTON
    @IBAction func showDirection(_ sender: UIButton) {
        // when button direction tapped, must call drawpath func
        self.drawPath(startLocation: locationStart, endLocation: locationEnd)
    }
    
}

// MARK: - GMS Auto Complete Delegate, for autocomplete search location
extension ReciverMapViewController: GMSAutocompleteViewControllerDelegate {
    
    
    
    
    func viewController(_ viewController: GMSAutocompleteViewController, didFailAutocompleteWithError error: Error) {
        print("Error \(error)")
    }
    
    func viewController(_ viewController: GMSAutocompleteViewController, didAutocompleteWith place: GMSPlace) {
        
        // Change map location
        let camera = GMSCameraPosition.camera(withLatitude: place.coordinate.latitude, longitude: place.coordinate.longitude, zoom: 16.0
        )
        // self.googleMaps.camera = camera
        // set coordinate to text
        
        
        //  googleMaps.clear()
        
        startLocation.text = place.name
        
        //startLocation.text = "\(place.coordinate.latitude), \(place.coordinate.longitude)"
        locationStart = CLLocation(latitude: place.coordinate.latitude, longitude: place.coordinate.longitude)
        
        let marker = GMSMarker()
        marker.position = CLLocationCoordinate2DMake(place.coordinate.latitude, place.coordinate.longitude)
        marker.title = "عنوان المستقبل"
        marker.icon = #imageLiteral(resourceName: "mapspin")
        marker.map = googleMaps
        
        // createMarker(titleMarker: "عنوان المرسل", iconMarker: #imageLiteral(resourceName: "mapspin"), latitude: place.coordinate.latitude, longitude: place.coordinate.longitude)
        
        ReciverAddressViewController.ReciverAdress["lat"] = String(place.coordinate.latitude)
        ReciverAddressViewController.ReciverAdress["long"] = String(place.coordinate.longitude)
        
        
        self.googleMaps.camera = camera
        self.dismiss(animated: true, completion: nil)
        
    }
    
    func wasCancelled(_ viewController: GMSAutocompleteViewController) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func didRequestAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    
    func didUpdateAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
    
}

public extension UISearchBar {
    
    public func setTextColor(color: UIColor) {
        let svs = subviews.flatMap { $0.subviews }
        guard let tf = (svs.filter { $0 is UITextField }).first as? UITextField else { return }
        tf.textColor = color
    }
    
}
