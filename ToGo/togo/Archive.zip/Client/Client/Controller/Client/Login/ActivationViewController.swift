//
//  ActivationViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 5/14/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import SACodedTextField
import KOPinCodeView




class ActivationViewController: UIViewController , KOPinCodeViewDelegate{
    
    @IBOutlet weak var pinCodeView: KOPinCodeView!
    @IBOutlet weak var LoadingView: UIView!
    static var  Usertype: Int = 1
    // outlets
    @IBOutlet weak var codeTextField: ActivationCodeTextField!
    //Loader
    var verifiedAcountLoader = VerifiedAcountLoader()
    //device Token
    @IBOutlet weak var CodeView: UIView!
    var textField: ActivationCodeTextField!
    @IBOutlet weak var msglable: UILabel!
    
    override func viewDidLoad(){
        super.viewDidLoad()
        
        updateUI()
        ConfigurePinCodeView()
        
    
        let DeviceTokenStatus = UserDefaults.standard.bool(forKey: "deviceTokenStatus")
        
        if DeviceTokenStatus == false{
            
            let token = genarateDeviceToken()
            UserDefaults.standard.set(true, forKey: "deviceTokenStatus")
            UserDefaults.standard.set(token, forKey: "deviceToken")
        }
     }
    
   
    func updateUI() {
        
        let  phone_number =   LoginLoader.phoneNumber
        print(phone_number.dropLast())
        print(LoginLoader.phoneNumber)
        msglable.text = "يرجي ادخال رمز التفعيل الذي سيتم ارساله الي رقم هاتفك المحمول " + "\(phone_number.dropFirst())+"
        
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {   //delegate method
        textField.resignFirstResponder()
        return true
    }
    
    // called after user select transporter or client
    @IBAction func submitBtnClicked(_ sender: Any) {
        
      
        
        if VerifiedAcountLoader.VerifiedCode == ""{
            let alert = UIAlertController(title: "", message: DataCount_Message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
            self.present(alert, animated: true)
            
        }else{
            
            VerifiedAcountLoader.VerifiedCode = ArToEnStingConverter()
            
            
            
            let sv = UIViewController.displaySpinner(onView: self.view)
            verifiedAcountLoader.VerifiedAcount {
                
                if VerifiedAcountLoader.VerifiedReult == "Wrong_Code" || VerifiedAcountLoader.VerifiedReult == "ParameterError"{
                    
                    let alert = UIAlertController(title: "", message: VerifiedAcountLoader.VerifiedReult, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                    self.present(alert, animated: true)
                    
                }else{
                   
                    let regstrationStatus = UserDefaults.standard.string(forKey: "ClientFlagRegistration")
                    
                    
                    if regstrationStatus == "ClientPersonalInfo"{
                        
                         self.performSegue(withIdentifier: "RegstrationSegue", sender: nil)
                        
                    }
                    else if regstrationStatus == "ClientBusinessTable"{
                       
                        
                         self.performSegue(withIdentifier: "ClientWorkDetailsSegue", sender: nil)
                    }
                    
                    else{
                        self.performSegue(withIdentifier: "HomePageSegue", sender: nil)
                    }
             
                }
                UIViewController.removeSpinner(spinner: sv)
                
            }
            
        }
    }
    
    
    func ConfigurePinCodeView()  {
        
        pinCodeView.delegate = self
        pinCodeView.initPin(withCount: 4)
        
        pinCodeView.initPinView(withConfirmPIN: false, countSymbol: 4, sizeSimbol: CGSize(width: 45, height: 45), formView: kCircle)
        
        //thickness view line
        pinCodeView.lineDeep = 2.0
        //Color view line
        pinCodeView.lineColor = UIColor.red
        //Background color view in select state
        //  pinCodeView.selectColor = [].withAlphaComponent(0.5)
        
        //Text color UITextField
        pinCodeView.symbolColor =  UIColor.red
        //Font UITextField
        pinCodeView.symbolFont = UIFont.systemFont(ofSize: 14)
        
        //UILabel show only initPinViewWithConfirmPIN:
        //Text color Label
        // pinCodeView.titleColor = []
        //Font Label
        pinCodeView.titleFont = UIFont.systemFont(ofSize: 14)
        //Create Confirm Pin Code
        // pinCodeView.confirm = false
        //Secure Text - Default: YES
        pinCodeView.secure = false
        //Keyboard Type
        pinCodeView.typeKeyboard = UIKeyboardType.numberPad
        
    }
    
    
    func genarateDeviceToken() -> String {
        
        let currentDateTime = Date().timeIntervalSinceReferenceDate
        print(String(currentDateTime))
        let hash = SHA1.hexString(from: String(currentDateTime))
        print(hash!)
        return hash!
    }
    
    func pinDidEnterAllSymbol(_ symbolArray: [Any]!, string pin: String!) {
        
        VerifiedAcountLoader.VerifiedCode = pin
        print(pin)
    }
    
    func ArToEnStingConverter()-> String{
        
        let NumberStr: String = VerifiedAcountLoader.VerifiedCode
        let Formatter = NumberFormatter()
        Formatter.locale = NSLocale(localeIdentifier: "EN") as Locale!
        let final = Formatter.number(from: NumberStr)
        
        return "\(final!)"
        
    }
    
    
    @IBAction func changeMobileNumber(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func resendActivationCode(_ sender: UIButton) {
    }
    
    
    // called when back btn pressed
    @IBAction func backBtnPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "RegstrationSegue"{
            
            _ = segue.destination as?
            ClinetPersonalInfoViewController
        }
        
        
        
    }
}
