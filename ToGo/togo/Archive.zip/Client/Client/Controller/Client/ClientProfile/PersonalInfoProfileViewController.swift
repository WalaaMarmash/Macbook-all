//
//  PersonalInfoProfileViewController.swift
//  Client
//
//  Created by Fratello Software Group on 12/3/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import ReachabilitySwift

class PersonalInfoProfileViewController: UIViewController , UITextFieldDelegate{
    
    //Outlets
    @IBOutlet var uiLable: [UILabel]!
    @IBOutlet var uiTextField: [CustomTextField]!
    
    //TextField
    @IBOutlet weak var nameTextField: CustomTextField!
    @IBOutlet weak var emailTextField: CustomTextField!
    //Loader
    var clientLoader = ClientLoader()
    // Internet Connection
    let reachability = Reachability()!
    static var clientPersonalInfoDetailsModel = [ClientPersonalInfoDetailsModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        GetPersonalInfo()
        self.nameTextField.isEnabled = false
        self.emailTextField.isEnabled = false
    }
    
    func GetPersonalInfo()  {
        
        // Check internet connection
        //when Reachable
        reachability.whenReachable = { reachability in
            DispatchQueue.main.async {
                
                let sv = UIViewController.displaySpinner(onView: self.view)
                
                // Get  list
                self.clientLoader.ClientProfileViewPersonalInfo {
                 
                    UIViewController.removeSpinner(spinner: sv)
                    self.updateUI()
               }
                
            }
        }
        // When UnReachable
        self.reachability.whenUnreachable = { reachability in
            // this is called on a background thread, but UI updates must
            // be on the main thread, like this:
            DispatchQueue.main.async {
                
                //                self.setUpPopupView()
                //               self.DisplayPopup(message: "")
                let alert = UIAlertController(title: ar_error_title, message: ar_error_message, preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                alert.addAction(UIAlertAction(title: ar_no, style: .cancel, handler: nil))
                self.present(alert, animated: true)
            }
            
        }
        
        do {
            try reachability.startNotifier()
        } catch {
            print("Unable to start notifier")
        }
    }
    
    
    func updateUI() {
        
        self.nameTextField.text = PersonalInfoProfileViewController.clientPersonalInfoDetailsModel[0].FullName
       self.emailTextField.text = PersonalInfoProfileViewController.clientPersonalInfoDetailsModel[0].Email
    }
    
   
    
    
    func isValidEmail(testStr:String) -> Bool {
        // print("validate calendar: \(testStr)")
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
    // handel return key for textField
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    // called when back btn pressed
    @IBAction func backBtnPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    // Configure ui Oriantation
    func SetUpOriantation()  {
        
        let lang = UserDefaults.standard.string(forKey: "lang")
        if lang == "ar"{
            for item in uiLable{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
            for item in uiTextField{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
        }else{
            for item in uiLable{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
            for item in uiTextField{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "personalClientSegue"{
            
            let destinationNavigationController = segue.destination as! UINavigationController
            let _ = destinationNavigationController.topViewController as! ClientWorkDetailsViewController
        }
        
    }
    //
    
}
