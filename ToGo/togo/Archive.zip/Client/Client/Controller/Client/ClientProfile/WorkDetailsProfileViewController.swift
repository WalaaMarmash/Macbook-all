//
//  WorkDetailsProfileViewController.swift
//  Client
//
//  Created by Fratello Software Group on 11/28/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import ReachabilitySwift

class WorkDetailsProfileViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    
    
    //Outlets
    @IBOutlet var uiLable: [UILabel]!
    @IBOutlet var uiTextField: [CustomTextField]!
    
    @IBOutlet weak var WorkTypePicker: UIPickerView!
    
    //TextField
    @IBOutlet weak var workPlaceTextField: CustomTextField!
    @IBOutlet weak var workNameTextField: CustomTextField!
    @IBOutlet weak var WorkTypeTextField: CustomTextField!
    @IBOutlet weak var imageTextField: CustomTextField!
    //Loader
    var clientLoader = ClientLoader()
    
    @IBOutlet weak var uploadImage: UIImageView!
    let imagePicker = UIImagePickerController()
    @IBOutlet weak var LoadingView: UIView!
    // ActivityIndicator
    var container: UIView = UIView()
    // var loadingView: UIView = UIView()
    var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
    var refreshControlller = UIRefreshControl()
    // Internet Connection
    let reachability = Reachability()!
    var BusinessTypeResult: String!
    
    //ClientWorkDetailsModel
    static var clientWorkDetailsModel = [ClientWorkDetailsModel]()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        imageTextField.isEnabled = false
        
         GetWorkDetailsInfo()
        
        setUpPickerViewUI()
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        uploadImage.isUserInteractionEnabled = true
        uploadImage.addGestureRecognizer(tapGestureRecognizer)
        imagePicker.delegate = self
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        self.view.endEditing(true)
    }
    
    
    func GetBussnissTypeList()  {
        
        // Check internet connection
        //when Reachable
//        reachability.whenReachable = { reachability in
//            DispatchQueue.main.async {
        
                let sv = UIViewController.displaySpinner(onView: self.view)
                
                // Get  list
                self.clientLoader.GetBusinessType {
                    
                    self.BusinessTypeResult = ClientLoader.GetBusinessTypeResult
                    if self.BusinessTypeResult == "Blocked"{
                        let alert = UIAlertController(title: "", message: Blocked_Message, preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                        self.present(alert, animated: true)
                    }
                    else{
                        //                    self._BusinessTypeList = self.clientLoader.BusinessTypeList
                        UIViewController.removeSpinner(spinner: sv)
                        self.WorkTypePicker.reloadAllComponents()
                    }
                }
                
            //}
//            UserDefaults.standard.set("ar", forKey: "lang")
//
//       // }
//        // When UnReachable
//        self.reachability.whenUnreachable = { reachability in
//            // this is called on a background thread, but UI updates must
//            // be on the main thread, like this:
//            DispatchQueue.main.async {
//
//                //                self.setUpPopupView()
//                //               self.DisplayPopup(message: "")
//                let alert = UIAlertController(title: ar_error_title, message: ar_error_message, preferredStyle: .alert)
//
//                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
//                alert.addAction(UIAlertAction(title: ar_no, style: .cancel, handler: nil))
//                self.present(alert, animated: true)
//            }
//
//        }
//
//        do {
//            try reachability.startNotifier()
//        } catch {
//            print("Unable to start notifier")
//        }
    }
    
    func GetWorkDetailsInfo()  {
        
        // Check internet connection
        //when Reachable
        reachability.whenReachable = { reachability in
            DispatchQueue.main.async {
                
                
                
                // Get  list
                self.clientLoader.ClientProfileGetTypeWork {
                
                    self.updateUI()
                    self.GetBussnissTypeList()
                    
            }
            
            }
        }
        // When UnReachable
        self.reachability.whenUnreachable = { reachability in
            // this is called on a background thread, but UI updates must
            // be on the main thread, like this:
            DispatchQueue.main.async {
                
                //                self.setUpPopupView()
                //               self.DisplayPopup(message: "")
                let alert = UIAlertController(title: ar_error_title, message: ar_error_message, preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                alert.addAction(UIAlertAction(title: ar_no, style: .cancel, handler: nil))
                self.present(alert, animated: true)
            }
            
        }
        
        do {
            try reachability.startNotifier()
        } catch {
            print("Unable to start notifier")
        }
    }
    
    
    func updateUI() {
        
        workNameTextField.placeholder = WorkDetailsProfileViewController.clientWorkDetailsModel[0].BusinessName
        workPlaceTextField.placeholder = WorkDetailsProfileViewController.clientWorkDetailsModel[0].BusinessPlace
       // WorkTypeTextField.placeholder = WorkDetailsProfileViewController.clientWorkDetailsModel[0].BusinessName
    }
    
    
    
    
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        imagePicker.allowsEditing = false
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let selectedImge = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        
        ClientLoader.ImagePath = "image" +  "\(Date().timeIntervalSinceReferenceDate)" + ".jpg"
        
        imageTextField.text =  ClientLoader.ImagePath
        //ImageCode
        let imageData:NSData = UIImagePNGRepresentation(selectedImge)! as NSData
        let strBase64 = imageData.base64EncodedString(options: .lineLength64Characters)
        // print(strBase64)
        ClientLoader.ImageCode = strBase64
        
        
        dismiss(animated: true, completion: nil)
    }
    
    
    
    @IBAction func submitBtnPressed(_ sender: UIButton) {
        
        let workDetailsParameters = WorkDetailsParameters()
        
        if workPlaceTextField.text == "" {
            //%notupdate*‏
            
              workDetailsParameters.WorkPlace = "%notupdate*‏"
        }
        
        if  workNameTextField.text == "" {
            workDetailsParameters.WorkName = "%notupdate*‏"
        }
        
        if WorkTypeTextField.text == ""  {
            workDetailsParameters.WorkTypeId = "%notupdate*‏"
            
        }
         if workPlaceTextField.text != ""{
            workDetailsParameters.WorkPlace = workPlaceTextField.text!
        }
         if workNameTextField.text != ""{
            workDetailsParameters.WorkName = workNameTextField.text!
        }
         if WorkTypeTextField.text != ""{
            workDetailsParameters.WorkTypeId = "%notupdate*‏"
        }
        
        clientLoader.workDetailsParameters = workDetailsParameters
            
            let sv = UIViewController.displaySpinner(onView: self.view)
            
            clientLoader.ClientProfileEditWorkInfo {
                
                UIViewController.removeSpinner(spinner: sv)
          
            }
        
            
        }

   
    
    
    
    
    
    // /////  /////  ///// /// pickerView///// /////  /////  /////  /////
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return  ClientLoader.BusinessIDResult.count
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        self.view.endEditing(true)
        return ClientLoader.BusinessNAmeResult[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        self.WorkTypeTextField.text = ClientLoader.BusinessNAmeResult[row]
      //  ClientLoader.BusinessType = ClientLoader.BusinessIDResult[row]
        WorkTypePicker.isHidden = true
    }
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 60
    }
    
    // /////  /////  ///// /// pickerView///// /////  /////  /////  /////
    
    //textField//
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == WorkTypeTextField{
            WorkTypePicker.isHidden = false
            self.view.endEditing(true)
            
        }
    }
    // handel return key for textField
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.view.endEditing(true)
    }
    
    //textField//
    
    
    func setUpPickerViewUI()  {
        self.WorkTypePicker.layer.borderWidth = 0.5
        self.WorkTypePicker.layer.cornerRadius = 10
        self.WorkTypePicker.layer.borderColor = UIColor(netHex: 0x29A89A).cgColor
        
    }
    // Configure ui Oriantation
    func SetUpOriantation()  {
        
        let lang = UserDefaults.standard.string(forKey: "lang")
        if lang == "ar"{
            for item in uiLable{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
            for item in uiTextField{
                item.semanticContentAttribute = .forceRightToLeft
                item.textAlignment = .right
            }
        }else{
            for item in uiLable{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
            for item in uiTextField{
                item.semanticContentAttribute = .forceLeftToRight
                item.textAlignment = .left
            }
        }
    }
    
    // called when back btn pressed
    @IBAction func backBtnPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "BusnissInfoSegue"{
            
            let destinationNavigationController = segue.destination as! UINavigationController
            let _ = destinationNavigationController.topViewController as! ClientPaymentTypeViewController
        }
        
    }
}

class WorkDetailsParameters{
    
    static let shared = WorkDetailsParameters()
    var WorkTypeId: String = ""
    var WorkPlace: String = ""
    var WorkName: String = ""
    
    init(){}
}
