//
//  sendOrderPageViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 7/29/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit

class sendOrderPageViewController: UIPageViewController, UIPageViewControllerDataSource,UIPageViewControllerDelegate {
    
    
    @IBOutlet weak var saveBtn: UIBarButtonItem!
    
    
    var CurrentIndex: Int = 0
    
    var pagesList = [UIViewController]()
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        for v in view.subviews{
            
            v.backgroundColor = UIColor(netHex: 0x29A89A)
            //            if v is UIScrollView{
            //                v.frame = view.bounds
            //                break
            //            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self.presentationController?.presentedView?.tintColor = UIColor.red
        
        //let vc1 = storyboard?.instantiateViewController(withIdentifier: "vc1")
        let vc2 = storyboard?.instantiateViewController(withIdentifier: "vc2")
        let vc3 = storyboard?.instantiateViewController(withIdentifier: "vc3")
        let vc4 = storyboard?.instantiateViewController(withIdentifier: "vc4")
        
        // pagesList.append(vc1!)
        pagesList.append(vc2!)
        pagesList.append(vc3!)
        pagesList.append(vc4!)
        
        setViewControllers([pagesList[0]], direction: .forward, animated: true, completion: nil)
        dataSource = self
        delegate = self
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        if  let index = pagesList.index(of: viewController) , index > 0 {
            print("index\(index)")
            
            return pagesList[index - 1]
        }
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        if  let index = pagesList.index(of: viewController) , index < pagesList.count - 1{
            print("index\(index)")
            
            return pagesList[index + 1]
        }
        return nil
    }
    
    func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        return 0
    }
    func presentationCount(for pageViewController: UIPageViewController) -> Int {
        return pagesList.count
    }
    
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool)
    {
        if (!completed)
        {
            return
        }
        CurrentIndex = pageViewController.viewControllers!.first!.view.tag //Page Index
        print(CurrentIndex)
    }
    
    
    
    
}
