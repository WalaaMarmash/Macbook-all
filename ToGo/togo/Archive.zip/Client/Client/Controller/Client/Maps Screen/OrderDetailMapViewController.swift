//
//  OrderDetailMapViewController.swift
//  TOGOTransporter
//
//  Created by Fratello Software Group on 9/19/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import GoogleMaps

import GooglePlaces

class OrderDetailMapViewController: UIViewController , GMSMapViewDelegate ,  CLLocationManagerDelegate {
    
    @IBOutlet weak var googleMaps: GMSMapView!
    var locationManager = CLLocationManager()
    
    static var typeOrder: String? = ""
    var clientLoader = ClientLoader()
    var refreshTimer: Timer!
    
    let customMarkerWidth: Int = 50
    let customMarkerHeight: Int = 70
    let Transportermarker = GMSMarker()
    static var ClientTrackTransporterLocationResponse: String? = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        
        
        if OrderDetailMapViewController.typeOrder == "Currentorder"{
            refreshTimer = Timer.scheduledTimer(timeInterval: 15, target: self, selector: #selector(updateTransporterLocation), userInfo: nil, repeats: true)
            
        }
        
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startMonitoringSignificantLocationChanges()
        
        //  //Your map initiation code
        
         clientLoader.ClientTrackTransporterLocation {
        
        
        if  ClientLoader.currentOrderTrackingResult[0].TransporterLatLocation != nil ,
            ClientLoader.currentOrderTrackingResult[0].TransporterLongLoc != nil{
            
            let camera = GMSCameraPosition.camera(withLatitude: ((ClientLoader.currentOrderTrackingResult[0].TransporterLatLocation)?.doubleValue)!, longitude: ((ClientLoader.currentOrderTrackingResult[0].TransporterLongLoc)?.doubleValue)!, zoom: 17.0)
              self.googleMaps.camera = camera
            
            
        }else{
            let camera = GMSCameraPosition.camera(withLatitude:  ((ClientLoader._OrderDetailsResult[0].LatSender)?.doubleValue)!, longitude: ((ClientLoader._OrderDetailsResult[0].LongSender)?.doubleValue)!, zoom: 17.0)
              self.googleMaps.camera = camera
            
        }
        
        }
      
        self.googleMaps.delegate = self
        self.googleMaps?.isMyLocationEnabled = true
        self.googleMaps.settings.myLocationButton = true
        self.googleMaps.settings.compassButton = true
        self.googleMaps.settings.zoomGestures = true
        
        
        
        
        if  ClientLoader._OrderDetailsResult[0].LatSender != nil ,
            ClientLoader._OrderDetailsResult[0].LongSender != nil{
            
            createMarker(titleMarker: "عنوان المرسل", iconMarker: #imageLiteral(resourceName: "icons8-place-marker-48") , latitude: ((ClientLoader._OrderDetailsResult[0].LatSender)?.doubleValue)!, longitude: ((ClientLoader._OrderDetailsResult[0].LongSender)?.doubleValue)!)
        }
        
        if  ClientLoader._OrderDetailsResult[0].LatReciver != nil ,
            ClientLoader._OrderDetailsResult[0].LongReciver != nil{
            createMarker(titleMarker: "عنوان المستقبل", iconMarker: #imageLiteral(resourceName: "icons8-place-marker-48") , latitude: ((ClientLoader._OrderDetailsResult[0].LatReciver)?.doubleValue)!, longitude: ((ClientLoader._OrderDetailsResult[0].LongReciver)?.doubleValue)!)
            
        }
    }
    
    
    @objc func updateTransporterLocation()  {
        //        clientLoader.ClientTrackTransporterLocation {
        //
        //            self.createMarker(titleMarker: "", iconMarker: #imageLiteral(resourceName: "icons8-street-view-64") , latitude: ((ClientLoader.currentOrderTrackingResult[0].TransporterLatLocation)?.doubleValue)!, longitude: ((ClientLoader.currentOrderTrackingResult[0].TransporterLongLoc)?.doubleValue)!)
        //        }
        
        
    }
    
    // MARK: function for create a marker pin on map
    func createMarker(titleMarker: String, iconMarker: UIImage, latitude: CLLocationDegrees, longitude: CLLocationDegrees) {
        let marker = GMSMarker()
        print(latitude)
        print(longitude)
        marker.position = CLLocationCoordinate2DMake(latitude, longitude)
        marker.title = titleMarker
        marker.icon = iconMarker
        
//        if let customMarkerView = marker.iconView as? CustomMarkerView{
//       
//            let img = customMarkerView.img!
//            let customMarker = CustomMarkerView(frame: CGRect(x: 0, y: 0, width: customMarkerWidth, height: customMarkerHeight), image: img, borderColor: UIColor.white, tag: (customMarkerView.tag))
//            marker.iconView = customMarker
//        }
        
        marker.map = googleMaps
    }
    
    
    // MARK: function for create a marker pin on map
    func createTransporterMarker(titleMarker: String, iconMarker: UIImage, latitude: CLLocationDegrees, longitude: CLLocationDegrees) {
        
        print(latitude)
        print(longitude)
        Transportermarker.position = CLLocationCoordinate2DMake(latitude, longitude)
        Transportermarker.title = titleMarker
        Transportermarker.icon = iconMarker
        
        //        if let customMarkerView = marker.iconView as? CustomMarkerView{
        //
        //            let img = customMarkerView.img!
        //            let customMarker = CustomMarkerView(frame: CGRect(x: 0, y: 0, width: customMarkerWidth, height: customMarkerHeight), image: img, borderColor: UIColor.white, tag: (customMarkerView.tag))
        //            marker.iconView = customMarker
        //        }
        
        Transportermarker.map = googleMaps
    }
    
    //MARK: - Location Manager delegates
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error to get location : \(error)")
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
         
        clientLoader.ClientTrackTransporterLocation {
            
            print("orderStatus:\(ClientLoader.currentOrderTrackingResult[0].Orderfinished)")
            
            if ClientLoader.currentOrderTrackingResult[0].Orderfinished == "1" {
                
                self.googleMaps.clear()
                
                 let alert = UIAlertController(title: "", message: finishTrip_Message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                
                self.present(alert, animated: true)
                self.locationManager.stopUpdatingLocation()
                
                
            }
            
            //print(ClientLoader.currentOrderTrackingResult[0].TransporterLatLocation)
            
            if  ClientLoader.currentOrderTrackingResult[0].TransporterLatLocation != nil ,
                ClientLoader.currentOrderTrackingResult[0].TransporterLongLoc != nil , OrderDetailMapViewController.typeOrder == "Currentorder"{
                
              
                
                self.createTransporterMarker(titleMarker: "", iconMarker: #imageLiteral(resourceName: "icons8-street-view-64") , latitude: ((ClientLoader.currentOrderTrackingResult[0].TransporterLatLocation)?.doubleValue)!, longitude: ((ClientLoader.currentOrderTrackingResult[0].TransporterLongLoc)?.doubleValue)!)
 
            }
            else{
                //self.locationManager.stopUpdatingLocation()
            }
        }
    }
    
    
    func lookUpCurrentLocation(completionHandler: @escaping (CLPlacemark?)
        -> Void ) {
        // Use the last reported location.
        if let lastLocation = self.locationManager.location {
            let geocoder = CLGeocoder()
            
            // Look up the location and pass it to the completion handler
            geocoder.reverseGeocodeLocation(lastLocation,
                         completionHandler: { (placemarks, error) in
                             if error == nil {
                  let firstLocation = placemarks?[0]
                             completionHandler(firstLocation)
          }
                   else {
                // An error occurred during geocoding.
             completionHandler(nil)
             }
            })
        }
        else {
            // No location was available.
            completionHandler(nil)
        }
    }
    
    
    
    
    
    
    
    // MARK: - GMSMapViewDelegate
    
    func mapView(_ mapView: GMSMapView, idleAt position: GMSCameraPosition) {
        googleMaps.isMyLocationEnabled = true
    }
    
    func mapView(_ mapView: GMSMapView, willMove gesture: Bool) {
        googleMaps.isMyLocationEnabled = true
        
        if (gesture) {
            mapView.selectedMarker = nil
        }
    }
    
    func mapView(_ mapView: GMSMapView, didTap marker: GMSMarker) -> Bool {
        googleMaps.isMyLocationEnabled = true
        return false
    }
    
    func mapView(_ mapView: GMSMapView, didTapAt coordinate: CLLocationCoordinate2D) {
        print("COORDINATE \(coordinate)") // when you tapped coordinate
    }
    
    func didTapMyLocationButton(for mapView: GMSMapView) -> Bool {
        googleMaps.isMyLocationEnabled = true
        googleMaps.selectedMarker = nil
        return false
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func backBtnPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //OrderDetailMapViewController
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension String {
    var doubleValue: Double {
        return (self as NSString).doubleValue
    }
}
