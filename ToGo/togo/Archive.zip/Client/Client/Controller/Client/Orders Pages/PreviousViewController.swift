//
//  PreviousViewController.swift
//  TOGOClient
//
//  Created by Fratello Software Group on 9/23/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import ReachabilitySwift

class PreviousViewController:  UIViewController {
    
    //Outlets
    @IBOutlet weak var orderTable: UITableView!
    @IBOutlet weak var statusMsg: UILabel!
    @IBOutlet weak var LoadingView: UIView!
    @IBOutlet weak var ratingPopup: RoundedBtn!
    @IBOutlet weak var submitRating: RoundedBtn!
    @IBOutlet var ratingBtn: [UIButton]!
    
    static var orderRatingResult: String = ""
    
    // Internet Connection
    let reachability = Reachability()!
    var clienLoader = ClientLoader()
    
    // Loading indicator
    var container: UIView = UIView()
    // var loadingView: UIView = UIView()
    var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
    var refreshControlller = UIRefreshControl()
    let View = UIView()
    // Order List
    static var Orders = [OrdersModel]()
    static var isPageRefreshing: Bool?
    var RateCount = 0
    static var RateValue = ""
    static var orderId = ""
    
    override func viewDidLoad() {
        
        let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(tapped(gestureRecognizer:)))
        view.addGestureRecognizer(tapRecognizer)
        tapRecognizer.delegate = self
        
        self.submitRating.layer.borderWidth = 0.5
        self.submitRating.layer.cornerRadius = 15
        self.submitRating.layer.borderColor = UIColor.white.cgColor
        
        
        super.viewDidLoad()
        orderTable.tableFooterView = UIView()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        RateCount = 0
        self.statusMsg.isHidden = true
        //Get Orders
        PreviousViewController.Orders = []
        HistoryPageNumber = PreviousViewController.Orders.count + 1
        self.getOrders()
    }
    
    
    // Order Details
    @objc func ShowOrderDetails(sender: UIButton!) {
        
        OrderDetailsOfCurrentOrdersViewController.OrderID = PreviousViewController.Orders[sender.tag].idOrder!
        //        print(sender.tag)
        OrderDetailsOfCurrentOrdersViewController.pushType = "2"
        performSegue(withIdentifier: "ShowOrderDetails", sender: nil)
        
    }
    
    
    func tapped(gestureRecognizer: UITapGestureRecognizer) {
        
        self.ratingPopup.isHidden = true
    }
    
    
    // Cancel Order
    @objc func ratingBtnPressed(sender: UIButton!) {
        
        print(sender.tag)
        
        if PreviousViewController.Orders[sender.tag].IsRate == "1"{
            
            let alert = UIAlertController(title: "", message: "لقد تم التقييم سابقا", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
            self.present(alert, animated: true)
            
            
        }else{
            for item in ratingBtn{
                item.setImage(UIImage(named: "To Go - August icons-4"), for: .normal)
            }
            ratingPopup.isHidden = false
        }
        
        
    }
    
    
    
    @IBAction func rateBtnTapped(_ sender: UIButton) {
        
        
        if sender.imageView?.image == UIImage(named: "To Go - August icons-4"){
            sender.setImage(UIImage(named: "To Go - August icons-5"), for: .normal)
            RateCount = RateCount + 1
            
        }else{
            sender.setImage(UIImage(named: "To Go - August icons-4"), for: .normal)
            RateCount = RateCount - 1
        }
        
    }
    
    
    @IBAction func submitRating(_ sender: UIButton) {
        
        //  let rating = RatingClass()
        
        PreviousViewController.RateValue = "\(RateCount)"
        
        PreviousViewController.orderId = PreviousViewController.Orders[sender.tag].idOrder!
        
        //clienLoader.rating = rating
        
        clienLoader.ClientRateTrip{
            
            if PreviousViewController.orderRatingResult == "TripRateSuccess"{
                
                let alert = UIAlertController(title: "", message: "لقد تم التقييم بنجاح", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: {(action:UIAlertAction!) in
                    
                    self.RateCount = 0
                    self.ratingPopup.isHidden = true
                    // self.orderTable.reloadData()
                    
                }))
                self.present(alert, animated: true)
                
            }else if  PreviousViewController.orderRatingResult ==  "OrderRated"{
                
                
                let alert = UIAlertController(title: "", message: "لقد تم التقييم سابقا", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: {(action:UIAlertAction!) in
                    
                    self.ratingPopup.isHidden = true
                    
                }))
                self.present(alert, animated: true)
            }
                
                
            else{
                
                let alert = UIAlertController(title: "", message: PreviousViewController.orderRatingResult, preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: {(action:UIAlertAction!) in
                    
                    self.ratingPopup.isHidden = true
                    
                }))
                self.present(alert, animated: true)
                
            }
        }
        
        //
    }
    
    
    func SetUpOriantation()  {
        
        let lang = UserDefaults.standard.string(forKey: "lang")
        if lang == "ar"{
            self.orderTable.semanticContentAttribute = .forceLeftToRight
            
            
            
        }else{
            self.orderTable.semanticContentAttribute = .forceRightToLeft
            
            
            
        }
    }
    
    //Delivary Way Name based on id
    func getDelivaryWayNameByID(Id: Int) -> String {
        
        switch Id {
        case 1:
            return "ارسال فقط"
        case 2:
            return "ارسال وقبض المبلغ"
        case 3:
            return "استلام الطلب"
        case 4:
            return "دفع واستلام"
        default:
            return ""
        }
    }
    
    //Get Previous Orders from(ClientHistoryOrder)  API
    func getOrders()  {
        
        let sv = UIViewController.displaySpinner(onView: self.view)
        
        self.clienLoader.ClientHistoryOrder {
            
            
            
            UIViewController.removeSpinner(spinner: sv)
            
            if PreviousViewController.Orders.count == 0{
                self.statusMsg.isHidden = false
                self.orderTable.isHidden = true
                
                
            }else{
                
                self.statusMsg.isHidden = true
                self.orderTable.isHidden = false
                self.orderTable.reloadData()
            }
        }
        
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        if segue.identifier == "ShowOrderDetails"{
            
            _ = segue.destination as?
            OrderDetailsOfCurrentOrdersViewController
        }
    }
    
    
}



////////////////// Previous Orders table//////////////////////////////////////////////
extension PreviousViewController:  UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return PreviousViewController.Orders.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "orderTableCell", for: indexPath) as!PreviousOrdersTableViewCell
        
        cell.OrderNumber.text = "رقم الطلب :\(PreviousViewController.Orders[indexPath.row].idOrder!)"
        cell.date.text = PreviousViewController.Orders[indexPath.row].DateOrder
        
        cell.delivaryWay.text =  getDelivaryWayNameByID(Id: Int(PreviousViewController.Orders[indexPath.row].DeliveryWays!)!)
        
        cell.time.text = PreviousViewController.Orders[indexPath.row].TimeOrder
        
        cell.orderDetails.tag = indexPath.row
        cell.orderDetails.addTarget(self, action: #selector(ShowOrderDetails), for: .touchUpInside)
        
        cell.ratingBtn.tag = indexPath.row
        cell.ratingBtn.addTarget(self, action: #selector(ratingBtnPressed), for: .touchUpInside)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 138
    }
    
    
    
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView){
        
        // pagination
        
        if (orderTable.contentOffset.y >= (self.orderTable.contentSize.height) - (self.orderTable.bounds.size.height)){
            
            
            if PreviousViewController.isPageRefreshing == false{
                
                HistoryPageNumber = PreviousViewController.Orders.count + 1
                PreviousViewController.isPageRefreshing = true
                
                
                getOrders()
                
            }
            
        }
        
        
        
    }
    
    
}


class RatingClass{
    
    static let shared = RatingClass()
    var RateValue: String = ""
    var OrderId: String = ""
    var RatingResult: String = ""
    
    
    init(){}
    
}


extension PreviousViewController : UIGestureRecognizerDelegate {
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if touch.view!.superview!.superclass! .isSubclass(of: UIButton.self) {
            return false
        }
        return true
    }
}
