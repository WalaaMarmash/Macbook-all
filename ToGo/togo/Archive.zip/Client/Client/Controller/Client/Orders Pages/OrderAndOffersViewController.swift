//
//  OrderAndOffersViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 5/28/18.
//  Copyright © 2018 yara. All rights reserved.
//
import ReachabilitySwift
import UIKit
import Foundation




class OrderAndOffersViewController: UIViewController{
    
    // Outlets
    @IBOutlet var uiStack: [UIStackView]!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var delivaryWay: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var LoadingView: UIView!
    @IBOutlet weak var statusMsg: UILabel!
    // Order List
    static var Orders = OrdersModel()
    
    var clienLoader = ClientLoader()
    // Loading indicator
    //    var container: UIView = UIView()
    //    var loadingView: UIView = UIView()
    //    var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
    //    var refreshControlller = UIRefreshControl()
    //    let View = UIView()
    
    // Order Offers List
    static var OrderOffers = [OrderOfferModel]()
    static var OrderDetailModelOffers = [OrderDetailModel]()
    //Transporter ID
    static var TransporterID: String = ""
    
    // refresh timer//
    var refreshTimer: Timer!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpOriantation()
        // self.tableView.separatorStyle = .none
        self.tableView.allowsSelection = false
       // self.tableView.tableFooterView?.isHidden = true
        self.tableView.tableFooterView = UIView()
        // setup timer
        //  refreshTimer = Timer.scheduledTimer(timeInterval: 20, target: self, selector: #selector(getOffers), userInfo: nil, repeats: true)
       // getOffers()
    }
    
    
    
    
    
    // Get Offers for order
    @objc  func getOffers()  {
        
        self.statusMsg.isHidden = true
        let sv = UIViewController.displaySpinner(onView: self.view)
        // Get Offers for order from Api (ClientShowBidRequists)
        clienLoader.ClientShowBidRequists {
            UIViewController.removeSpinner(spinner: sv)
            
            if OrderAndOffersViewController.OrderDetailModelOffers.count == 0{
                
                self.statusMsg.isHidden = false
                self.tableView.isHidden = true
                self.updateUI()
            }else{
                
                self.statusMsg.isHidden = true
                self.tableView.isHidden = false
                self.tableView.reloadData()
                self.updateUI()
            }
        }
        
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        getOffers()
    }
    
    
    func updateUI()  {
        
        self.delivaryWay.text =  getDelivaryWayNameByID(Id: Int(OrderAndOffersViewController.OrderDetailModelOffers[0].DeliveryWay!)!)
        var date =  (OrderAndOffersViewController.OrderDetailModelOffers[0].DateOrder)?.components(separatedBy: " ")
        //  print(date?[0])
        self.date.text = date?[0]
        self.time.text = date?[1]
    }
    
    
    // Accept Offer
    @objc func AcceptOfferBtn(sender: UIButton!) {
        
        OrderAndOffersViewController.TransporterID = OrderAndOffersViewController.OrderOffers[sender.tag].IdTransporterBidRequist!
        
        let sv = UIViewController.displaySpinner(onView: self.view)
        
        
        clienLoader.AcceptClientBidEngie {
            
            UIViewController.removeSpinner(spinner: sv)
            
            if ClientLoader.AcceptClientBidResult.contains("OrderAcceptedSuccessfully"){
                //OrderAcceptedSuccessfully
                
                MasterViewController.segmentedControlIndex = 1
                let alert = UIAlertController(title: "", message: SuccessSendOrder_Message, preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: {(action:UIAlertAction!) in
                    
                    
                    let storyboard = UIStoryboard(name: "Second", bundle: nil)
                    let initialViewController = storyboard.instantiateViewController(withIdentifier: "UITabBarController-bAs-bi-vwu")
                    UIApplication.shared.windows.first?.rootViewController = initialViewController
                    UIApplication.shared.windows.first?.makeKeyAndVisible()
                    
                    //self.dismiss(animated: true, completion: nil)
                }))
                
                self.present(alert, animated: true)
                
            }
                
                
            else if ClientLoader.AcceptClientBidResult.contains("ClientChargeBalanace") ||
                ClientLoader.AcceptClientBidResult.contains("ChargeBalanace")
            {
                
                let alert = UIAlertController(title: balanceWarning_title, message:  balanceWarning_Message , preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                self.present(alert, animated: true)
            }
                
            else{
                let alert = UIAlertController(title: "", message: ClientLoader.AcceptClientBidResult , preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                self.present(alert, animated: true)
            }
            
            
        }
    }
    
    
    func SetUpOriantation()  {
        let lang = UserDefaults.standard.string(forKey: "lang")
        if lang == "ar"{
            for item in uiStack{
                item.semanticContentAttribute = .forceLeftToRight
                
            }
            tableView.semanticContentAttribute = .forceLeftToRight
        }else{
            for item in uiStack{
                item.semanticContentAttribute = .forceRightToLeft
                
                
            }
            tableView.semanticContentAttribute = .forceRightToLeft
        }
    }
    //Delivary Way Name based on id
    func getDelivaryWayNameByID(Id: Int) -> String {
        
        switch Id {
        case 1:
            return "ارسال فقط"
        case 2:
            return "ارسال وقبض المبلغ"
        case 3:
            return "استلام الطلب"
        case 4:
            return "دفع واستلام"
        default:
            return ""
        }
        
    }
    
    @IBAction func backBtnPressed(_ sender: Any) {
        MasterViewController.segmentedControlIndex = 0
        OrderDetailsOfCurrentOrdersViewController.pushType = "0"
        let storyboard = UIStoryboard(name: "Second", bundle: nil)
        let initialViewController = storyboard.instantiateViewController(withIdentifier: "UITabBarController-bAs-bi-vwu")
        UIApplication.shared.windows.first?.rootViewController = initialViewController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        
        // self.dismiss(animated: true, completion: nil)
    }
    
    
}

////////////////// Offers for Order table//////////////////////////////////////////////
extension OrderAndOffersViewController:  UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return OrderAndOffersViewController.OrderOffers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! OrderAndOffersTableViewCell
        cell.transporterName.text = OrderAndOffersViewController.OrderOffers[indexPath.row].TransporterName
        if OrderAndOffersViewController.OrderOffers[indexPath.row].BidCost == ""{
            cell.Price.text = "0"
        }
        else{
            cell.Price.text = OrderAndOffersViewController.OrderOffers[indexPath.row].BidCost

        }
        cell.AcceptBtn.tag = indexPath.row
        cell.AcceptBtn.addTarget(self, action: #selector(AcceptOfferBtn), for: .touchUpInside)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 103
    }
    
}
