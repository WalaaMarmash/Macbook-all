//
//  CurrentOrderViewController.swift
//  TOGOClient
//
//  Created by Fratello Software Group on 9/23/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import ReachabilitySwift

class CurrentOrderViewController: UIViewController {
    
    //Outlets
    @IBOutlet weak var submitBtn: UIButton!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var orderTable: UITableView!
    @IBOutlet weak var statusMsg: UILabel!
    @IBOutlet weak var LoadingView: UIView!
    @IBOutlet weak var deductionWorningPopup: RoundedBtn!
    // Internet Connection
    let reachability = Reachability()!
    var clienLoader = ClientLoader()
    
    // Loading indicator
    var container: UIView = UIView()
   // var loadingView: UIView = UIView()
    var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
    var refreshControlller = UIRefreshControl()
    let View = UIView()
    // Order List
    static var Orders = [OrdersModel]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       // self.orderTable.separatorStyle = .none
        self.orderTable.allowsSelection = false
        orderTable.tableFooterView = UIView()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        
    }
    override func viewDidAppear(_ animated: Bool) {
        self.statusMsg.isHidden = true
        // get orders
        self.getOrders()
        setUpUI()
    }
    
    // Configure UI
    func setUpUI()  {
        self.submitBtn.layer.borderWidth = 0.5
        self.submitBtn.layer.cornerRadius = 15
        self.submitBtn.layer.borderColor = UIColor.white.cgColor
        self.cancelBtn.layer.borderWidth = 0.5
        self.cancelBtn.layer.cornerRadius = 15
        self.cancelBtn.layer.borderColor = UIColor.white.cgColor
    }
    
    
    // Order Details
    @objc func ShowOrderDetails(sender: UIButton!) {
        
        OrderDetailsOfCurrentOrdersViewController.OrderID = CurrentOrderViewController.Orders[sender.tag].idOrder!
        
        OrderDetailsOfCurrentOrdersViewController.indexNum = "\(CurrentOrderViewController.Orders[sender.tag].idOrder!)"
        
        OrderDetailsOfCurrentOrdersViewController.pushType = "1"
        performSegue(withIdentifier: "ShowOrderDetails", sender: nil)
        
    }
    
    
    @IBAction func confirmCancelOrder(_ sender: UIButton) {
        
        cancelOrder(index: sender.tag)
        
    }
    
    @IBAction func removeCancelOrderPopup(_ sender: Any) {
        self.deductionWorningPopup.isHidden = true
    }
    
    
    func cancelOrder(index: Int) {
    
        
        OrdersViewController.CancelOrderId = CurrentOrderViewController.Orders[index].idOrder!
        
        let sv = UIViewController.displaySpinner(onView: self.view)
        
        self.clienLoader.ClientDeleteOrder {
            
            UIViewController.removeSpinner(spinner: sv)
            if ClientLoader.CancelOrderResult.contains("OrderDeletedSuccess"){
                
                CurrentOrderViewController.Orders.remove(at: index)
                self.orderTable.reloadData()
                
                let alert = UIAlertController(title: "", message: SuccessDeleteOrder_Message, preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                self.present(alert, animated: true)
                 self.deductionWorningPopup.isHidden = true
            }else{
                
                let alert = UIAlertController(title: "", message: ClientLoader.CancelOrderResult, preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                self.present(alert, animated: true)
                self.deductionWorningPopup.isHidden = true
            }
            
        }
        
    }
    
    
    
    // Cancel Order
    @objc func CancelOrderBtnPressed(sender: UIButton!) {
        
       self.deductionWorningPopup.isHidden = false
        
    }
    
    
    
    
    func SetUpOriantation()  {
        
        let lang = UserDefaults.standard.string(forKey: "lang")
        if lang == "ar"{
            self.orderTable.semanticContentAttribute = .forceLeftToRight
            
            
            
        }else{
            self.orderTable.semanticContentAttribute = .forceRightToLeft
        }
    }
    
    //Delivary Way Name based on id
    func getDelivaryWayNameByID(Id: Int) -> String {
        
        switch Id {
        case 1:
            return "ارسال فقط"
        case 2:
            return "ارسال وقبض المبلغ"
        case 3:
            return "استلام الطلب"
        case 4:
            return "دفع واستلام"
        default:
            return ""
        }
    }
    
    //Get current Orders from(ShowClientOrder)  API
    func getOrders()  {
        
       let sv = UIViewController.displaySpinner(onView: self.view)
        
        self.clienLoader.ClientShowBidRequistsAccepted {
            
            
            UIViewController.removeSpinner(spinner: sv)
            
            if CurrentOrderViewController.Orders.count == 0{
                self.statusMsg.isHidden = false
                self.orderTable.isHidden = true
                
                
            }else{
                
                self.statusMsg.isHidden = true
                self.orderTable.isHidden = false
                self.orderTable.reloadData()
            }
        }
        
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        if segue.identifier == "ShowOrderDetails"{
            
            _ = segue.destination as?
            OrderDetailsOfCurrentOrdersViewController
        }
    }
    
}

//////////////////// Current Orders table//////////////////////////////////////////////
extension CurrentOrderViewController:  UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return CurrentOrderViewController.Orders.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "orderTableCell", for: indexPath) as!CurrentOrdersTableViewCell
        
        cell.OrderNumber.text = "رقم الطلب :\(CurrentOrderViewController.Orders[indexPath.row].idOrder!)"
        cell.date.text = CurrentOrderViewController.Orders[indexPath.row].DateOrder
        
        cell.delivaryWay.text =  getDelivaryWayNameByID(Id: Int(CurrentOrderViewController.Orders[indexPath.row].DeliveryWays!)!)
        
        cell.time.text = CurrentOrderViewController.Orders[indexPath.row].TimeOrder
        
        cell.orderDetails.tag = indexPath.row
        cell.orderDetails.addTarget(self, action: #selector(ShowOrderDetails), for: .touchUpInside)
        
        cell.cancelOrderBtn.tag = indexPath.row
        cell.cancelOrderBtn.addTarget(self, action: #selector(CancelOrderBtnPressed), for: .touchUpInside)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 138
    }
    
    
    
}
