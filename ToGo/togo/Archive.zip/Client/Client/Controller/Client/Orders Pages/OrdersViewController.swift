//
//  OrdersViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 6/11/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import ReachabilitySwift

class OrdersViewController: UIViewController {
    
    
    // Internet Connection
    let reachability = Reachability()!
    
    //Outlets
    @IBOutlet weak var orderTable: UITableView!
    @IBOutlet weak var statusMsg: UILabel!
    @IBOutlet weak var LoadingView: UIView!
    
    static var getOrderResult = ""
    
    
    // Order List
    static var Orders = [OrdersModel]()
    
    var clienLoader = ClientLoader()
    
    // Loading indicator
    var container: UIView = UIView()
    //var loadingView: UIView = UIView()
    var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
    var refreshControlller = UIRefreshControl()
    let View = UIView()
    
    static var CancelOrderId = ""
    // refresh timer
    var refreshTimer: Timer!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpOriantation()
        self.orderTable.allowsSelection = false
        orderTable.tableFooterView = UIView()

        //self.orderTable.separatorStyle = .none
        // setup timer
      //  refreshTimer = Timer.scheduledTimer(timeInterval: 20, target: self, selector: #selector(getOrders), userInfo: nil, repeats: true)
        
    }
    
    // get orders
    override func viewWillAppear(_ animated: Bool) {
        
       
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.statusMsg.isHidden = true
        //Get available orders
        self.getOrders()
    }
    
    
    //  available  offers
    @objc func ShowOffersOrder(sender: UIButton!) {
        
        OrderAndOffersViewController.Orders = OrdersViewController.Orders[sender.tag]
        print(sender.tag)
        performSegue(withIdentifier: "showOffers", sender: nil)
        
    }
    
    
    // Order Details
    @objc func ShowOrderDetails(sender: UIButton!) {
        
        OrderDetailsViewController.OrderID = OrdersViewController.Orders[sender.tag].idOrder!
        OrderDetailsViewController.indexNum = "\(OrdersViewController.Orders[sender.tag].idOrder!)"
        print(sender.tag)
        performSegue(withIdentifier: "ShowOrderDetails", sender: nil)
        
    }
    
    // Cancel Order
    @objc func CancelOrderBtnPressed(sender: UIButton!) {
        
        OrdersViewController.CancelOrderId = OrdersViewController.Orders[sender.tag].idOrder!
        
         let sv = UIViewController.displaySpinner(onView: self.view)
        
        self.clienLoader.ClientDeleteOrder {
            
            
           UIViewController.removeSpinner(spinner: sv)
            
            if ClientLoader.CancelOrderResult.contains("OrderDeletedSuccess"){
                
                OrdersViewController.Orders.remove(at: sender.tag)
                self.orderTable.reloadData()
                
                let alert = UIAlertController(title: "", message: SuccessDeleteOrder_Message, preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                self.present(alert, animated: true)
            }else{
                
                let alert = UIAlertController(title: "", message: ClientLoader.CancelOrderResult, preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: ar_yes, style: .default, handler: nil))
                self.present(alert, animated: true)
            }
            
        }
        
    }
    
    func SetUpOriantation()  {
        
        let lang = UserDefaults.standard.string(forKey: "lang")
        if lang == "ar"{
            self.orderTable.semanticContentAttribute = .forceLeftToRight
            
            // orderSwitcher.semanticContentAttribute = .forceRightToLeft
            
        }else{
            self.orderTable.semanticContentAttribute = .forceRightToLeft
            
            // orderSwitcher.semanticContentAttribute = .forceLeftToRight
            
        }
    }
    
    
    //Delivary Way Name based on id
    func getDelivaryWayNameByID(Id: Int) -> String {
        
        switch Id {
        case 1:
            return "ارسال فقط"
        case 2:
            return "ارسال وقبض المبلغ"
        case 3:
            return "استلام الطلب"
        case 4:
            return "دفع واستلام"
        default:
            return ""
        }
    }
    
    // Get Orders from (ShowClientOrder) API
    @objc func getOrders()  {
        
        let sv = UIViewController.displaySpinner(onView: self.view)
        
        self.clienLoader.ShowClientOrder{
            
            UIViewController.removeSpinner(spinner: sv)
            
            if OrdersViewController.getOrderResult == "TokenError"{
                
                let alert = UIAlertController(title: "تحذير", message: "لقد تم الدخول لحسابك من جهاز اخر قم بالاغلاق وحاول لاحقا", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "اغلاق", style: .default, handler: {(alert: UIAlertAction!) in
                  
                    UserDefaults.standard.set(false, forKey:  "Client_Status_reg")
                    
                    exit(0)
                 
                }))
                self.present(alert, animated: true)
                
            }
            else{
            if OrdersViewController.Orders.count == 0{
                self.statusMsg.isHidden = false
                self.orderTable.isHidden = true
                // self.LoadingView.isHidden = false
                
            }else{
                
                
                self.statusMsg.isHidden = true
                self.orderTable.isHidden = false
                self.orderTable.reloadData()
            }
        }
        }
        
    }
    
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "showOffers"{
            
            _ = segue.destination as?
            OrderAndOffersViewController
        }
        if segue.identifier == "ShowOrderDetails"{
            
            _ = segue.destination as?
            OrderDetailsViewController
        }
    }
    
}


////////////////// Orders table//////////////////////////////////////////////
extension OrdersViewController:  UITableViewDelegate, UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return OrdersViewController.Orders.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "orderTableCell", for: indexPath) as!ClientOrdersTableViewCell
        
        cell.OrderNumber.text = "رقم الطلب :\(OrdersViewController.Orders[indexPath.row].idOrder!)"
        cell.date.text = OrdersViewController.Orders[indexPath.row].DateOrder
        
        cell.delivaryWay.text =  getDelivaryWayNameByID(Id: Int(OrdersViewController.Orders[indexPath.row].DeliveryWays!)!)
        
        cell.time.text = OrdersViewController.Orders[indexPath.row].TimeOrder
        cell.OffersBtn.tag = indexPath.row
        cell.OffersBtn.addTarget(self, action: #selector(ShowOffersOrder), for: .touchUpInside)
        
        cell.orderDetails.tag = indexPath.row
        cell.orderDetails.addTarget(self, action: #selector(ShowOrderDetails), for: .touchUpInside)
        
        cell.cancelOrderBtn.tag = indexPath.row
        cell.cancelOrderBtn.addTarget(self, action: #selector(CancelOrderBtnPressed), for: .touchUpInside)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 138
    }
}


