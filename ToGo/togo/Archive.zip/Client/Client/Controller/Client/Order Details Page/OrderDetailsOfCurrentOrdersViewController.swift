//
//  OrderDetailsOfCurrentOrdersViewController.swift
//  TOGOClient
//
//  Created by Fratello Software Group on 9/23/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit
import ReachabilitySwift

class OrderDetailsOfCurrentOrdersViewController: UIViewController {
    
   
    static var pushType = ""
    //Outlets
    @IBOutlet weak var ClientName: UILabel!
    @IBOutlet weak var ClientPhoneNum: UILabel!
    
    @IBOutlet weak var TransporterMobileNumber: UIButton!
    @IBOutlet weak var carColor: UILabel!
    @IBOutlet weak var CarNumber: UILabel!
    @IBOutlet weak var carType: UILabel!
    static var OrderID: String = ""
    @IBOutlet weak var DelivaryWay: UILabel!
    @IBOutlet weak var orderDetails: UILabel!
    @IBOutlet weak var OrderSize: UILabel!
    @IBOutlet weak var orderWeight: UILabel!
    @IBOutlet weak var OrderlenghtWidth: UILabel!
    // Source Address
    @IBOutlet weak var SrcFlowrNumber: UILabel!
    @IBOutlet weak var ScrBuilding: UILabel!
    @IBOutlet weak var SrcStreet: UILabel!
    @IBOutlet weak var SrcPlace: UILabel!
    
    // Des Address
    @IBOutlet weak var DesFlowrNumber: UILabel!
    @IBOutlet weak var DesBuilding: UILabel!
    @IBOutlet weak var DesStreet: UILabel!
    @IBOutlet weak var DesPlace: UILabel!
    static var indexNum: String = ""
    
    @IBOutlet weak var OrderNumber: UILabel!
    
    @IBOutlet weak var loadDetailsStack: UIStackView!
    @IBOutlet weak var loadTextlable: UILabel!
    @IBOutlet weak var loadlineView: UIView!
    
    @IBOutlet weak var orderDetailsLable: UILabel!
    let reachability = Reachability()!
    @IBOutlet weak var LoadingView: UIView!
    var clientLoader = ClientLoader()
    var container: UIView = UIView()
   // var loadingView: UIView = UIView()
    var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
    var refreshControlller = UIRefreshControl()
    let View = UIView()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
       let sv = UIViewController.displaySpinner(onView: self.view)
        
        self.clientLoader.ClientShowDetailsOrderCurrent {
            
            
            UIViewController.removeSpinner(spinner: sv)
            self.UpdateUI()
            
        }
        
    }
    
    
    func UpdateUI()  {
        
        if ClientLoader._OrderDetailsResult[0].TypeLoad == "1"{
            loadDetailsStack.isHidden = true
            orderDetailsLable.isHidden = false
            //loadlineView.isHidden = true
           // loadTextlable.isHidden = true
        }else{
            orderDetailsLable.isHidden = true
            loadDetailsStack.isHidden = false
           // loadlineView.isHidden = false
           // loadTextlable.isHidden = false
        }
        
    self.OrderNumber.text = "رقم الطلب :\(OrderDetailsOfCurrentOrdersViewController.indexNum)"

        
        self.ClientName.text = ClientLoader._OrderDetailsResult[0].FullNameCustomer
       // self.ClientPhoneNum.text = ClientLoader._OrderDetailsResult[0].FullNameCustomer
        self.DelivaryWay.text = self.getDelivaryWayNameByID(Id: Int(ClientLoader._OrderDetailsResult[0].deliveryWay!)!)
        self.orderDetails.text = ClientLoader._OrderDetailsResult[0].DetailsLoad
        self.OrderSize.text = ClientLoader._OrderDetailsResult[0].WidthLoad
        self.orderWeight.text = ClientLoader._OrderDetailsResult[0].WeightLoad
        self.OrderlenghtWidth.text = ClientLoader._OrderDetailsResult[0].WidthLoad!  + "," + ClientLoader._OrderDetailsResult[0].LengthLoad!
        
        // Src Address
        
        self.SrcPlace.text = ClientLoader._OrderDetailsResult[0].NameNeighborhood! + ","
        
        self.SrcStreet.text = ClientLoader._OrderDetailsResult[0].NameStreet! + ","
        self.ScrBuilding.text = ClientLoader._OrderDetailsResult[0].NameBuilding! + ","
        self.SrcFlowrNumber.text = ClientLoader._OrderDetailsResult[0].FloorNumbers
        
        
        // Dest
        self.DesPlace.text = ClientLoader._OrderDetailsResult[0].NameNeighborhood! + ","
        
        self.DesStreet.text = ClientLoader._OrderDetailsResult[0].NameStreetDes! + ","
        
        self.DesBuilding.text = ClientLoader._OrderDetailsResult[0].NameBuildingDes! + ","
        
        self.DesFlowrNumber.text = ClientLoader._OrderDetailsResult[0].FloorNumbersDes
        
        self.CarNumber.text = ClientLoader._OrderDetailsResult[0].CarLicenceNum
        self.carType.text = ClientLoader._OrderDetailsResult[0].CarNumType
        
        self.carColor.text = ClientLoader._OrderDetailsResult[0].ColorName
        
    }
    
    
    func getDelivaryWayNameByID(Id: Int) -> String {
        
        switch Id {
        case 0:
            return "ارسال فقط"
        case 1:
            return "ارسال وقبض المبلغ"
        case 2:
            return "استلام الطلب"
        case 3:
            return "دفع واستلام"
        default:
            return ""
        }
    }
    
    @IBAction func backBtnPressed(_ sender: Any) {
        
        if OrderDetailsOfCurrentOrdersViewController.pushType == "1"{
            MasterViewController.segmentedControlIndex = 1
        }
        else{
            MasterViewController.segmentedControlIndex = 2
        }
        
        MasterViewController.segmentedControlIndex = 1
        self.dismiss(animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showMap(_ sender: Any) {
        performSegue(withIdentifier: "showMap", sender: nil)
        
        
    }
    
    @IBAction func callTransporter(_ sender: UIButton) {
        
        if let phoneNumber = sender.titleLabel?.text {
            
        if let url = NSURL(string: "tel://\(phoneNumber)"), UIApplication.shared.canOpenURL(url as URL) {
            UIApplication.shared.openURL(url as URL)
        }
        }
    }
    
    
    //  Hide loading indicator
    func hideActivityIndicator(uiView: UIView) {
        activityIndicator.stopAnimating()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "showMap"{
            
            _ = segue.destination as?
            OrderDetailMapViewController
            OrderDetailMapViewController.typeOrder = "Currentorder"
            
            
        }
        
        
        
    }
}
