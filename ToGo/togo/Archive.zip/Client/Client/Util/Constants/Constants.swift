//
//  Constants.swift
//  Client
//
//  Created by Fratello Software Group on 10/17/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation

//Arabic
let ar_error_title = "خطا في الاتصال"
let ar_error_message = "لا يوجد اتصال بالانترنت الرجاء المحاولة لاحقا"
let ar_yes = "نعم"
let ar_no = "لا"

//English
let en_error_title = "Connection Error"
let en_error_message = "No internet connection, please try again"
let en_yes = "yes"
let en_no = "NO"


let Blocked_Message = "تم حظرك من قبل المسؤول"
let ErrorData_Message = "البيانات المدخلة غير صحيحة"
let DataCount_Message = "عدد الخانات المدخلة غير صحيحة"
let DataWarning_Message = "الرجاء ادخال جميع البيانات"

let balanceWarning_title = "لا يوجد رصيد كافي"
let balanceWarning_Message = "لا يتوفر لديك رصيد كافي لاتمام العملية , قم بشحن رصيدك وحاول لاحقا"
let successSaveOrder_Message = "تم حفظ البيانات بنجاح"
let NoPreviousLocation_Message = "لا يوجد عناوين سابقة"
let finishTrip_Message = "تم انهاء الرحلة"

let LoadDetails_Message = "الرجاء حفظ بيانات تفاصيل الحمولة"
let SenderDetails_Message = "الرجاء حفظ بيانات تفاصيل المرسل"
let ReciverDetails_Message = "الرجاء حفظ بيانات تفاصيل المستقبل"



//Login API Message
let Updated_Message = "تم التعديل بنجاح"
let NotUpdated_Message = "لم يتم التعديل"
let inserted_Message = "تم الاضافة بنجاح"

// VerifiedAcount API Message
let Wrong_Code_Message = "رمز التفعيل المدخل خاطئ"

// SetPersonalInfo API Message
let insertedInfo_Message = "تم الاضافة بنجاح"
let NotinsertedInfo_Message = "لم يتم الاضافة,حاول مجددا"

// SetBusinessInfo API Message
let insertedBusinessInfo_Message = "تم الاضافة بنجاح"
let NotinsertedBusinessInfo_Message = "لم يتم الاضافة,حاول مجددا"
let ImgUpload_Message = "لم يتم تحميل الصورة,حاول مجددا"

//Send Order  API Message
let SuccessDeleteOrder_Message = "تم حذف الطلب بنجاح"
let SuccessSendOrder_Message = "تم ارسال الطلب بنجاح"


var HistoryPageNumber = 0



