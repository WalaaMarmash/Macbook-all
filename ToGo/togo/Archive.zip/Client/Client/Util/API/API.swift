//
//  API.swift
//  Client
//
//  Created by Fratello Software Group on 10/17/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation

// APIs
let Base_URL = "http://46.253.95.83/ToGo/MobileAPi/public/FunctionApis.php"

let image_URL = "http://46.253.95.83/ToGo/public/img/"

typealias DownloadComplete = () -> ()
