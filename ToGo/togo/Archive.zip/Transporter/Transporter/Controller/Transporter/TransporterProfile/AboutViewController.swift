//
//  AboutViewController.swift
//  ToGo
//
//  Created by Fratello Software Group on 6/4/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    
    // called when back btn pressed
    @IBAction func backBtnPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
