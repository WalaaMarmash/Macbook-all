//
//  CarTypeCollectionViewCell.swift
//  ToGo
//
//  Created by Fratello Software Group on 6/24/18.
//  Copyright © 2018 yara. All rights reserved.
//

import UIKit

// Car Types Cell
class CarTypeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var carButton: UIButton!
    @IBOutlet weak var carImage: UIImageView!
}
