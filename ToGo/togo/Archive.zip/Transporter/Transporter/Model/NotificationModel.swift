//
//  NotificationModel.swift
//  Transporter
//
//  Created by Fratello Software Group on 10/25/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation
import UIKit


class NotificationModelResult {
    
    
   
}


