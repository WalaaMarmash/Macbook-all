//
//  API.swift
//  ToGo
//
//  Created by Fratello Software Group on 7/9/18.
//  Copyright © 2018 yara. All rights reserved.
//

import Foundation

// APIs
// let Base_URL = "https://ejarsubadmin.azurewebsites.net/TOGO/MobileAPi/public/FunctionApis.php"

 let Base_URL = "http://46.253.95.83/ToGo/MobileAPi/public/FunctionApis.php"

 let image_URL = "http://46.253.95.83/ToGo/public/img/"


typealias DownloadComplete = () -> ()

